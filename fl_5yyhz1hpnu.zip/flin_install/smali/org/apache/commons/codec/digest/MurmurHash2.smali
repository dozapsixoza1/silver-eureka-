.class public final Lorg/apache/commons/codec/digest/MurmurHash2;
.super Ljava/lang/Object;
.source "MurmurHash2.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static hash32(Ljava/lang/String;)I
    .locals 1

    .line 108
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    .line 109
    array-length v0, p0

    invoke-static {p0, v0}, Lorg/apache/commons/codec/digest/MurmurHash2;->hash32([BI)I

    move-result p0

    return p0
.end method

.method public static hash32(Ljava/lang/String;II)I
    .locals 0

    add-int/2addr p2, p1

    .line 121
    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lorg/apache/commons/codec/digest/MurmurHash2;->hash32(Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static hash32([BI)I
    .locals 1

    const v0, -0x68b84d74

    .line 98
    invoke-static {p0, p1, v0}, Lorg/apache/commons/codec/digest/MurmurHash2;->hash32([BII)I

    move-result p0

    return p0
.end method

.method public static hash32([BII)I
    .locals 7

    xor-int/2addr p2, p1

    .line 59
    div-int/lit8 v0, p1, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x3

    const v3, 0x5bd1e995

    if-ge v1, v0, :cond_0

    mul-int/lit8 v4, v1, 0x4

    add-int/lit8 v5, v4, 0x0

    .line 63
    aget-byte v5, p0, v5

    and-int/lit16 v5, v5, 0xff

    add-int/lit8 v6, v4, 0x1

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    add-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x2

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x10

    add-int/2addr v5, v6

    add-int/2addr v4, v2

    aget-byte v2, p0, v4

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x18

    add-int/2addr v5, v2

    mul-int v5, v5, v3

    ushr-int/lit8 v2, v5, 0x18

    xor-int/2addr v2, v5

    mul-int v2, v2, v3

    mul-int p2, p2, v3

    xor-int/2addr p2, v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 73
    :cond_0
    rem-int/lit8 v0, p1, 0x4

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3

    const/4 v4, 0x2

    if-eq v0, v4, :cond_2

    if-eq v0, v2, :cond_1

    goto :goto_1

    :cond_1
    and-int/lit8 v0, p1, -0x4

    add-int/2addr v0, v4

    .line 75
    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    xor-int/2addr p2, v0

    :cond_2
    and-int/lit8 v0, p1, -0x4

    add-int/2addr v0, v1

    .line 77
    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    xor-int/2addr p2, v0

    :cond_3
    and-int/lit8 p1, p1, -0x4

    .line 79
    aget-byte p0, p0, p1

    and-int/lit16 p0, p0, 0xff

    xor-int/2addr p0, p2

    mul-int p2, p0, v3

    :goto_1
    ushr-int/lit8 p0, p2, 0xd

    xor-int/2addr p0, p2

    mul-int p0, p0, v3

    ushr-int/lit8 p1, p0, 0xf

    xor-int/2addr p0, p1

    return p0
.end method

.method public static hash64(Ljava/lang/String;)J
    .locals 2

    .line 198
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    .line 199
    array-length v0, p0

    invoke-static {p0, v0}, Lorg/apache/commons/codec/digest/MurmurHash2;->hash64([BI)J

    move-result-wide v0

    return-wide v0
.end method

.method public static hash64(Ljava/lang/String;II)J
    .locals 0

    add-int/2addr p2, p1

    .line 211
    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lorg/apache/commons/codec/digest/MurmurHash2;->hash64(Ljava/lang/String;)J

    move-result-wide p0

    return-wide p0
.end method

.method public static hash64([BI)J
    .locals 1

    const v0, -0x1e85eb9b

    .line 188
    invoke-static {p0, p1, v0}, Lorg/apache/commons/codec/digest/MurmurHash2;->hash64([BII)J

    move-result-wide p0

    return-wide p0
.end method

.method public static hash64([BII)J
    .locals 18

    move/from16 v0, p1

    move/from16 v1, p2

    int-to-long v1, v1

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    int-to-long v3, v0

    const-wide v5, -0x395b586ca42e166bL    # -2.0946245025644615E32

    mul-long v3, v3, v5

    xor-long/2addr v1, v3

    .line 138
    div-int/lit8 v3, v0, 0x8

    const/4 v4, 0x0

    :goto_0
    const/16 v7, 0x20

    const/16 v8, 0x18

    const/16 v9, 0x10

    const/16 v11, 0x8

    if-ge v4, v3, :cond_0

    mul-int/lit8 v12, v4, 0x8

    add-int/lit8 v13, v12, 0x0

    .line 142
    aget-byte v13, p0, v13

    int-to-long v13, v13

    const-wide/16 v15, 0xff

    and-long/2addr v13, v15

    add-int/lit8 v17, v12, 0x1

    aget-byte v10, p0, v17

    int-to-long v5, v10

    and-long/2addr v5, v15

    shl-long/2addr v5, v11

    add-long/2addr v13, v5

    add-int/lit8 v5, v12, 0x2

    aget-byte v5, p0, v5

    int-to-long v5, v5

    and-long/2addr v5, v15

    shl-long/2addr v5, v9

    add-long/2addr v13, v5

    add-int/lit8 v5, v12, 0x3

    aget-byte v5, p0, v5

    int-to-long v5, v5

    and-long/2addr v5, v15

    shl-long/2addr v5, v8

    add-long/2addr v13, v5

    add-int/lit8 v5, v12, 0x4

    aget-byte v5, p0, v5

    int-to-long v5, v5

    and-long/2addr v5, v15

    shl-long/2addr v5, v7

    add-long/2addr v13, v5

    add-int/lit8 v5, v12, 0x5

    aget-byte v5, p0, v5

    int-to-long v5, v5

    and-long/2addr v5, v15

    const/16 v7, 0x28

    shl-long/2addr v5, v7

    add-long/2addr v13, v5

    add-int/lit8 v5, v12, 0x6

    aget-byte v5, p0, v5

    int-to-long v5, v5

    and-long/2addr v5, v15

    const/16 v7, 0x30

    shl-long/2addr v5, v7

    add-long/2addr v13, v5

    add-int/lit8 v12, v12, 0x7

    aget-byte v5, p0, v12

    int-to-long v5, v5

    and-long/2addr v5, v15

    const/16 v7, 0x38

    shl-long/2addr v5, v7

    add-long/2addr v13, v5

    const-wide v5, -0x395b586ca42e166bL    # -2.0946245025644615E32

    mul-long v13, v13, v5

    const/16 v7, 0x2f

    ushr-long v7, v13, v7

    xor-long/2addr v7, v13

    mul-long v7, v7, v5

    xor-long/2addr v1, v7

    mul-long v1, v1, v5

    add-int/lit8 v4, v4, 0x1

    const-wide v5, -0x395b586ca42e166bL    # -2.0946245025644615E32

    goto :goto_0

    .line 155
    :cond_0
    rem-int/lit8 v3, v0, 0x8

    packed-switch v3, :pswitch_data_0

    const-wide v3, -0x395b586ca42e166bL    # -2.0946245025644615E32

    :goto_1
    const/16 v0, 0x2f

    goto :goto_2

    :pswitch_0
    and-int/lit8 v3, v0, -0x8

    add-int/lit8 v3, v3, 0x6

    .line 157
    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xff

    int-to-long v3, v3

    const/16 v5, 0x30

    shl-long/2addr v3, v5

    xor-long/2addr v1, v3

    :pswitch_1
    and-int/lit8 v3, v0, -0x8

    add-int/lit8 v3, v3, 0x5

    .line 159
    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xff

    int-to-long v3, v3

    const/16 v5, 0x28

    shl-long/2addr v3, v5

    xor-long/2addr v1, v3

    :pswitch_2
    and-int/lit8 v3, v0, -0x8

    add-int/lit8 v3, v3, 0x4

    .line 161
    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xff

    int-to-long v3, v3

    shl-long/2addr v3, v7

    xor-long/2addr v1, v3

    :pswitch_3
    and-int/lit8 v3, v0, -0x8

    add-int/lit8 v3, v3, 0x3

    .line 163
    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xff

    int-to-long v3, v3

    shl-long/2addr v3, v8

    xor-long/2addr v1, v3

    :pswitch_4
    and-int/lit8 v3, v0, -0x8

    add-int/lit8 v3, v3, 0x2

    .line 165
    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xff

    int-to-long v3, v3

    shl-long/2addr v3, v9

    xor-long/2addr v1, v3

    :pswitch_5
    and-int/lit8 v3, v0, -0x8

    add-int/lit8 v3, v3, 0x1

    .line 167
    aget-byte v3, p0, v3

    and-int/lit16 v3, v3, 0xff

    int-to-long v3, v3

    shl-long/2addr v3, v11

    xor-long/2addr v1, v3

    :pswitch_6
    and-int/lit8 v0, v0, -0x8

    .line 169
    aget-byte v0, p0, v0

    and-int/lit16 v0, v0, 0xff

    int-to-long v3, v0

    xor-long/2addr v1, v3

    const-wide v3, -0x395b586ca42e166bL    # -2.0946245025644615E32

    mul-long v1, v1, v3

    goto :goto_1

    :goto_2
    ushr-long v5, v1, v0

    xor-long/2addr v1, v5

    mul-long v1, v1, v3

    ushr-long v3, v1, v0

    xor-long/2addr v1, v3

    return-wide v1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
