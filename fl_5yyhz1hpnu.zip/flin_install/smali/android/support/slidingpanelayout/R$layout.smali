.class public final Landroid/support/slidingpanelayout/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/slidingpanelayout/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final notification_action:I = 0x7f0a0027

.field public static final notification_action_tombstone:I = 0x7f0a0028

.field public static final notification_template_custom_big:I = 0x7f0a0029

.field public static final notification_template_icon_group:I = 0x7f0a002a

.field public static final notification_template_part_chronometer:I = 0x7f0a002b

.field public static final notification_template_part_time:I = 0x7f0a002c


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 116
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
