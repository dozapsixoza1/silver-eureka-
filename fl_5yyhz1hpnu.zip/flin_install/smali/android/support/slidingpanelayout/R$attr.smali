.class public final Landroid/support/slidingpanelayout/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/slidingpanelayout/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final alpha:I = 0x7f030027

.field public static final font:I = 0x7f03007c

.field public static final fontProviderAuthority:I = 0x7f03007e

.field public static final fontProviderCerts:I = 0x7f03007f

.field public static final fontProviderFetchStrategy:I = 0x7f030080

.field public static final fontProviderFetchTimeout:I = 0x7f030081

.field public static final fontProviderPackage:I = 0x7f030082

.field public static final fontProviderQuery:I = 0x7f030083

.field public static final fontStyle:I = 0x7f030084

.field public static final fontVariationSettings:I = 0x7f030085

.field public static final fontWeight:I = 0x7f030086

.field public static final ttcIndex:I = 0x7f03015e


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
