.class public final Lir/mahdi/mzip/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lir/mahdi/mzip/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final actionBarDivider:I = 0x7f030000

.field public static final actionBarItemBackground:I = 0x7f030001

.field public static final actionBarPopupTheme:I = 0x7f030002

.field public static final actionBarSize:I = 0x7f030003

.field public static final actionBarSplitStyle:I = 0x7f030004

.field public static final actionBarStyle:I = 0x7f030005

.field public static final actionBarTabBarStyle:I = 0x7f030006

.field public static final actionBarTabStyle:I = 0x7f030007

.field public static final actionBarTabTextStyle:I = 0x7f030008

.field public static final actionBarTheme:I = 0x7f030009

.field public static final actionBarWidgetTheme:I = 0x7f03000a

.field public static final actionButtonStyle:I = 0x7f03000b

.field public static final actionDropDownStyle:I = 0x7f03000c

.field public static final actionLayout:I = 0x7f03000d

.field public static final actionMenuTextAppearance:I = 0x7f03000e

.field public static final actionMenuTextColor:I = 0x7f03000f

.field public static final actionModeBackground:I = 0x7f030010

.field public static final actionModeCloseButtonStyle:I = 0x7f030011

.field public static final actionModeCloseDrawable:I = 0x7f030012

.field public static final actionModeCopyDrawable:I = 0x7f030013

.field public static final actionModeCutDrawable:I = 0x7f030014

.field public static final actionModeFindDrawable:I = 0x7f030015

.field public static final actionModePasteDrawable:I = 0x7f030016

.field public static final actionModePopupWindowStyle:I = 0x7f030017

.field public static final actionModeSelectAllDrawable:I = 0x7f030018

.field public static final actionModeShareDrawable:I = 0x7f030019

.field public static final actionModeSplitBackground:I = 0x7f03001a

.field public static final actionModeStyle:I = 0x7f03001b

.field public static final actionModeWebSearchDrawable:I = 0x7f03001c

.field public static final actionOverflowButtonStyle:I = 0x7f03001d

.field public static final actionOverflowMenuStyle:I = 0x7f03001e

.field public static final actionProviderClass:I = 0x7f03001f

.field public static final actionViewClass:I = 0x7f030020

.field public static final activityChooserViewStyle:I = 0x7f030021

.field public static final alertDialogButtonGroupStyle:I = 0x7f030022

.field public static final alertDialogCenterButtons:I = 0x7f030023

.field public static final alertDialogStyle:I = 0x7f030024

.field public static final alertDialogTheme:I = 0x7f030025

.field public static final allowStacking:I = 0x7f030026

.field public static final alpha:I = 0x7f030027

.field public static final arrowHeadLength:I = 0x7f030029

.field public static final arrowShaftLength:I = 0x7f03002a

.field public static final autoCompleteTextViewStyle:I = 0x7f03002b

.field public static final background:I = 0x7f030031

.field public static final backgroundSplit:I = 0x7f030033

.field public static final backgroundStacked:I = 0x7f030034

.field public static final backgroundTint:I = 0x7f030035

.field public static final backgroundTintMode:I = 0x7f030036

.field public static final barLength:I = 0x7f030038

.field public static final borderlessButtonStyle:I = 0x7f03003b

.field public static final buttonBarButtonStyle:I = 0x7f03003c

.field public static final buttonBarNegativeButtonStyle:I = 0x7f03003d

.field public static final buttonBarNeutralButtonStyle:I = 0x7f03003e

.field public static final buttonBarPositiveButtonStyle:I = 0x7f03003f

.field public static final buttonBarStyle:I = 0x7f030040

.field public static final buttonGravity:I = 0x7f030041

.field public static final buttonPanelSideLayout:I = 0x7f030043

.field public static final buttonStyle:I = 0x7f030044

.field public static final buttonStyleSmall:I = 0x7f030045

.field public static final buttonTint:I = 0x7f030046

.field public static final buttonTintMode:I = 0x7f030047

.field public static final checkboxStyle:I = 0x7f030049

.field public static final checkedTextViewStyle:I = 0x7f03004a

.field public static final closeIcon:I = 0x7f03004b

.field public static final closeItemLayout:I = 0x7f03004c

.field public static final collapseContentDescription:I = 0x7f03004d

.field public static final collapseIcon:I = 0x7f03004e

.field public static final color:I = 0x7f03004f

.field public static final colorAccent:I = 0x7f030050

.field public static final colorBackgroundFloating:I = 0x7f030051

.field public static final colorButtonNormal:I = 0x7f030052

.field public static final colorControlActivated:I = 0x7f030053

.field public static final colorControlHighlight:I = 0x7f030054

.field public static final colorControlNormal:I = 0x7f030055

.field public static final colorPrimary:I = 0x7f030057

.field public static final colorPrimaryDark:I = 0x7f030058

.field public static final colorSwitchThumbNormal:I = 0x7f030059

.field public static final commitIcon:I = 0x7f03005a

.field public static final contentDescription:I = 0x7f03005e

.field public static final contentInsetEnd:I = 0x7f03005f

.field public static final contentInsetEndWithActions:I = 0x7f030060

.field public static final contentInsetLeft:I = 0x7f030061

.field public static final contentInsetRight:I = 0x7f030062

.field public static final contentInsetStart:I = 0x7f030063

.field public static final contentInsetStartWithNavigation:I = 0x7f030064

.field public static final controlBackground:I = 0x7f030065

.field public static final customNavigationLayout:I = 0x7f030067

.field public static final defaultQueryHint:I = 0x7f030068

.field public static final dialogPreferredPadding:I = 0x7f03006a

.field public static final dialogTheme:I = 0x7f03006b

.field public static final displayOptions:I = 0x7f03006c

.field public static final divider:I = 0x7f03006d

.field public static final dividerHorizontal:I = 0x7f03006e

.field public static final dividerPadding:I = 0x7f03006f

.field public static final dividerVertical:I = 0x7f030070

.field public static final drawableSize:I = 0x7f030071

.field public static final drawerArrowStyle:I = 0x7f030072

.field public static final dropDownListViewStyle:I = 0x7f030073

.field public static final dropdownListPreferredItemHeight:I = 0x7f030074

.field public static final editTextBackground:I = 0x7f030075

.field public static final editTextColor:I = 0x7f030076

.field public static final editTextStyle:I = 0x7f030077

.field public static final elevation:I = 0x7f030078

.field public static final expandActivityOverflowButtonDrawable:I = 0x7f03007a

.field public static final gapBetweenBars:I = 0x7f030087

.field public static final goIcon:I = 0x7f030088

.field public static final height:I = 0x7f030089

.field public static final hideOnContentScroll:I = 0x7f03008a

.field public static final homeAsUpIndicator:I = 0x7f03008b

.field public static final homeLayout:I = 0x7f03008c

.field public static final icon:I = 0x7f03008d

.field public static final iconifiedByDefault:I = 0x7f030090

.field public static final imageButtonStyle:I = 0x7f030091

.field public static final indeterminateProgressStyle:I = 0x7f030092

.field public static final initialActivityCount:I = 0x7f030093

.field public static final isLightTheme:I = 0x7f030094

.field public static final itemPadding:I = 0x7f030095

.field public static final layout:I = 0x7f030098

.field public static final listChoiceBackgroundIndicator:I = 0x7f0300d2

.field public static final listDividerAlertDialog:I = 0x7f0300d3

.field public static final listItemLayout:I = 0x7f0300d4

.field public static final listLayout:I = 0x7f0300d5

.field public static final listMenuViewStyle:I = 0x7f0300d6

.field public static final listPopupWindowStyle:I = 0x7f0300d7

.field public static final listPreferredItemHeight:I = 0x7f0300d8

.field public static final listPreferredItemHeightLarge:I = 0x7f0300d9

.field public static final listPreferredItemHeightSmall:I = 0x7f0300da

.field public static final listPreferredItemPaddingLeft:I = 0x7f0300db

.field public static final listPreferredItemPaddingRight:I = 0x7f0300dc

.field public static final logo:I = 0x7f0300dd

.field public static final logoDescription:I = 0x7f0300de

.field public static final maxButtonHeight:I = 0x7f0300df

.field public static final measureWithLargestChild:I = 0x7f0300e1

.field public static final multiChoiceItemLayout:I = 0x7f0300e2

.field public static final navigationContentDescription:I = 0x7f0300e3

.field public static final navigationIcon:I = 0x7f0300e4

.field public static final navigationMode:I = 0x7f0300e5

.field public static final overlapAnchor:I = 0x7f0300e7

.field public static final paddingBottomNoButtons:I = 0x7f0300e8

.field public static final paddingEnd:I = 0x7f0300e9

.field public static final paddingStart:I = 0x7f0300ea

.field public static final paddingTopNoTitle:I = 0x7f0300eb

.field public static final panelBackground:I = 0x7f0300ec

.field public static final panelMenuListTheme:I = 0x7f0300ed

.field public static final panelMenuListWidth:I = 0x7f0300ee

.field public static final popupMenuStyle:I = 0x7f0300ef

.field public static final popupTheme:I = 0x7f0300f0

.field public static final popupWindowStyle:I = 0x7f0300f1

.field public static final preserveIconSpacing:I = 0x7f0300f3

.field public static final progressBarPadding:I = 0x7f0300f4

.field public static final progressBarStyle:I = 0x7f0300f5

.field public static final queryBackground:I = 0x7f0300f9

.field public static final queryHint:I = 0x7f0300fa

.field public static final radioButtonStyle:I = 0x7f0300fb

.field public static final ratingBarStyle:I = 0x7f0300fc

.field public static final ratingBarStyleIndicator:I = 0x7f0300fd

.field public static final ratingBarStyleSmall:I = 0x7f0300fe

.field public static final searchHintIcon:I = 0x7f030100

.field public static final searchIcon:I = 0x7f030101

.field public static final searchViewStyle:I = 0x7f030102

.field public static final seekBarStyle:I = 0x7f030103

.field public static final selectableItemBackground:I = 0x7f030104

.field public static final selectableItemBackgroundBorderless:I = 0x7f030105

.field public static final showAsAction:I = 0x7f030106

.field public static final showDividers:I = 0x7f030107

.field public static final showText:I = 0x7f030108

.field public static final showTitle:I = 0x7f030109

.field public static final singleChoiceItemLayout:I = 0x7f03010a

.field public static final spinBars:I = 0x7f030122

.field public static final spinnerDropDownItemStyle:I = 0x7f030123

.field public static final spinnerStyle:I = 0x7f030124

.field public static final splitTrack:I = 0x7f030125

.field public static final srcCompat:I = 0x7f030126

.field public static final state_above_anchor:I = 0x7f030127

.field public static final subMenuArrow:I = 0x7f03012a

.field public static final submitBackground:I = 0x7f03012b

.field public static final subtitle:I = 0x7f03012c

.field public static final subtitleTextAppearance:I = 0x7f03012d

.field public static final subtitleTextColor:I = 0x7f03012e

.field public static final subtitleTextStyle:I = 0x7f03012f

.field public static final suggestionRowLayout:I = 0x7f030131

.field public static final switchMinWidth:I = 0x7f030132

.field public static final switchPadding:I = 0x7f030133

.field public static final switchStyle:I = 0x7f030134

.field public static final switchTextAppearance:I = 0x7f030135

.field public static final textAllCaps:I = 0x7f030136

.field public static final textAppearanceLargePopupMenu:I = 0x7f030137

.field public static final textAppearanceListItem:I = 0x7f030138

.field public static final textAppearanceListItemSmall:I = 0x7f03013a

.field public static final textAppearancePopupMenuHeader:I = 0x7f03013b

.field public static final textAppearanceSearchResultSubtitle:I = 0x7f03013c

.field public static final textAppearanceSearchResultTitle:I = 0x7f03013d

.field public static final textAppearanceSmallPopupMenu:I = 0x7f03013e

.field public static final textColorAlertDialogListItem:I = 0x7f03013f

.field public static final textColorSearchUrl:I = 0x7f030140

.field public static final theme:I = 0x7f030142

.field public static final thickness:I = 0x7f030143

.field public static final thumbTextPadding:I = 0x7f030144

.field public static final thumbTint:I = 0x7f030145

.field public static final thumbTintMode:I = 0x7f030146

.field public static final tickMark:I = 0x7f030147

.field public static final tickMarkTint:I = 0x7f030148

.field public static final tickMarkTintMode:I = 0x7f030149

.field public static final title:I = 0x7f03014c

.field public static final titleMargin:I = 0x7f03014d

.field public static final titleMarginBottom:I = 0x7f03014e

.field public static final titleMarginEnd:I = 0x7f03014f

.field public static final titleMarginStart:I = 0x7f030150

.field public static final titleMarginTop:I = 0x7f030151

.field public static final titleMargins:I = 0x7f030152

.field public static final titleTextAppearance:I = 0x7f030153

.field public static final titleTextColor:I = 0x7f030154

.field public static final titleTextStyle:I = 0x7f030155

.field public static final toolbarNavigationButtonStyle:I = 0x7f030156

.field public static final toolbarStyle:I = 0x7f030157

.field public static final tooltipText:I = 0x7f03015a

.field public static final track:I = 0x7f03015b

.field public static final trackTint:I = 0x7f03015c

.field public static final trackTintMode:I = 0x7f03015d

.field public static final voiceIcon:I = 0x7f030160

.field public static final windowActionBar:I = 0x7f030161

.field public static final windowActionBarOverlay:I = 0x7f030162

.field public static final windowActionModeOverlay:I = 0x7f030163

.field public static final windowFixedHeightMajor:I = 0x7f030164

.field public static final windowFixedHeightMinor:I = 0x7f030165

.field public static final windowFixedWidthMajor:I = 0x7f030166

.field public static final windowFixedWidthMinor:I = 0x7f030167

.field public static final windowMinWidthMajor:I = 0x7f030168

.field public static final windowMinWidthMinor:I = 0x7f030169

.field public static final windowNoTitle:I = 0x7f03016a


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
