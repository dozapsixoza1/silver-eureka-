.class public interface abstract Lir/mahdi/mzip/rar/VolumeManager;
.super Ljava/lang/Object;
.source "VolumeManager.java"


# virtual methods
.method public abstract nextArchive(Lir/mahdi/mzip/rar/Archive;Lir/mahdi/mzip/rar/Volume;)Lir/mahdi/mzip/rar/Volume;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method
