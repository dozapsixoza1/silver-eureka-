.class public Lir/mahdi/mzip/rar/Archive;
.super Ljava/lang/Object;
.source "Archive.java"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field private static logger:Ljava/util/logging/Logger;


# instance fields
.field private currentHeaderIndex:I

.field private final dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

.field private final headers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lir/mahdi/mzip/rar/rarfile/BaseBlock;",
            ">;"
        }
    .end annotation
.end field

.field private markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

.field private newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

.field private rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

.field private totalPackedRead:J

.field private totalPackedSize:J

.field private unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

.field private final unrarCallback:Lir/mahdi/mzip/rar/UnrarCallback;

.field private volume:Lir/mahdi/mzip/rar/Volume;

.field private volumeManager:Lir/mahdi/mzip/rar/VolumeManager;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 57
    const-class v0, Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, Lir/mahdi/mzip/rar/Archive;->logger:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/VolumeManager;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x0

    .line 79
    invoke-direct {p0, p1, v0}, Lir/mahdi/mzip/rar/Archive;-><init>(Lir/mahdi/mzip/rar/VolumeManager;Lir/mahdi/mzip/rar/UnrarCallback;)V

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/VolumeManager;Lir/mahdi/mzip/rar/UnrarCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;,
            Ljava/io/IOException;
        }
    .end annotation

    .line 83
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 60
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    const/4 v0, 0x0

    .line 62
    iput-object v0, p0, Lir/mahdi/mzip/rar/Archive;->markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    .line 64
    iput-object v0, p0, Lir/mahdi/mzip/rar/Archive;->newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

    const-wide/16 v1, 0x0

    .line 70
    iput-wide v1, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedSize:J

    .line 72
    iput-wide v1, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedRead:J

    .line 84
    iput-object p1, p0, Lir/mahdi/mzip/rar/Archive;->volumeManager:Lir/mahdi/mzip/rar/VolumeManager;

    .line 85
    iput-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unrarCallback:Lir/mahdi/mzip/rar/UnrarCallback;

    .line 87
    iget-object p1, p0, Lir/mahdi/mzip/rar/Archive;->volumeManager:Lir/mahdi/mzip/rar/VolumeManager;

    invoke-interface {p1, p0, v0}, Lir/mahdi/mzip/rar/VolumeManager;->nextArchive(Lir/mahdi/mzip/rar/Archive;Lir/mahdi/mzip/rar/Volume;)Lir/mahdi/mzip/rar/Volume;

    move-result-object p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/Archive;->setVolume(Lir/mahdi/mzip/rar/Volume;)V

    .line 88
    new-instance p1, Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-direct {p1, p0}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;-><init>(Lir/mahdi/mzip/rar/Archive;)V

    iput-object p1, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    return-void
.end method

.method public constructor <init>(Ljava/io/File;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;,
            Ljava/io/IOException;
        }
    .end annotation

    .line 92
    new-instance v0, Lir/mahdi/mzip/rar/impl/FileVolumeManager;

    invoke-direct {v0, p1}, Lir/mahdi/mzip/rar/impl/FileVolumeManager;-><init>(Ljava/io/File;)V

    const/4 p1, 0x0

    invoke-direct {p0, v0, p1}, Lir/mahdi/mzip/rar/Archive;-><init>(Lir/mahdi/mzip/rar/VolumeManager;Lir/mahdi/mzip/rar/UnrarCallback;)V

    return-void
.end method

.method public constructor <init>(Ljava/io/File;Lir/mahdi/mzip/rar/UnrarCallback;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;,
            Ljava/io/IOException;
        }
    .end annotation

    .line 97
    new-instance v0, Lir/mahdi/mzip/rar/impl/FileVolumeManager;

    invoke-direct {v0, p1}, Lir/mahdi/mzip/rar/impl/FileVolumeManager;-><init>(Ljava/io/File;)V

    invoke-direct {p0, v0, p2}, Lir/mahdi/mzip/rar/Archive;-><init>(Lir/mahdi/mzip/rar/VolumeManager;Lir/mahdi/mzip/rar/UnrarCallback;)V

    return-void
.end method

.method private doExtractFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/OutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;,
            Ljava/io/IOException;
        }
    .end annotation

    .line 434
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {v0, p2}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->init(Ljava/io/OutputStream;)V

    .line 435
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {p2, p1}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->init(Lir/mahdi/mzip/rar/rarfile/FileHeader;)V

    .line 436
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/Archive;->isOldFormat()Z

    move-result v0

    const-wide/16 v1, -0x1

    if-eqz v0, :cond_0

    const-wide/16 v3, 0x0

    goto :goto_0

    :cond_0
    move-wide v3, v1

    :goto_0
    invoke-virtual {p2, v3, v4}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->setUnpFileCRC(J)V

    .line 437
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    if-nez p2, :cond_1

    .line 438
    new-instance p2, Lir/mahdi/mzip/rar/unpack/Unpack;

    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-direct {p2, v0}, Lir/mahdi/mzip/rar/unpack/Unpack;-><init>(Lir/mahdi/mzip/rar/unpack/ComprDataIO;)V

    iput-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    .line 440
    :cond_1
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSolid()Z

    move-result p2

    if-nez p2, :cond_2

    .line 441
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Lir/mahdi/mzip/rar/unpack/Unpack;->init([B)V

    .line 443
    :cond_2
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFullUnpackSize()J

    move-result-wide v3

    invoke-virtual {p2, v3, v4}, Lir/mahdi/mzip/rar/unpack/Unpack;->setDestSize(J)V

    .line 445
    :try_start_0
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpVersion()B

    move-result v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSolid()Z

    move-result p1

    invoke-virtual {p2, v0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->doUnpack(IZ)V

    .line 447
    iget-object p1, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->getSubHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object p1

    .line 448
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSplitAfter()Z

    move-result p2

    if-eqz p2, :cond_3

    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->getPackedCRC()J

    move-result-wide v3

    :goto_1
    xor-long/2addr v1, v3

    goto :goto_2

    :cond_3
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->dataIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    .line 449
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->getUnpFileCRC()J

    move-result-wide v3

    goto :goto_1

    .line 450
    :goto_2
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileCRC()I

    move-result p1

    int-to-long p1, p1

    cmp-long v0, v1, p1

    if-nez v0, :cond_4

    return-void

    .line 452
    :cond_4
    new-instance p1, Lir/mahdi/mzip/rar/exception/RarException;

    sget-object p2, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->crcError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-direct {p1, p2}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p1

    .line 461
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/Unpack;->cleanUp()V

    .line 462
    instance-of p2, p1, Lir/mahdi/mzip/rar/exception/RarException;

    if-eqz p2, :cond_5

    .line 464
    check-cast p1, Lir/mahdi/mzip/rar/exception/RarException;

    throw p1

    .line 466
    :cond_5
    new-instance p2, Lir/mahdi/mzip/rar/exception/RarException;

    invoke-direct {p2, p1}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Ljava/lang/Exception;)V

    goto :goto_4

    :goto_3
    throw p2

    :goto_4
    goto :goto_3
.end method

.method private readHeaders(J)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    const/4 v0, 0x0

    .line 183
    iput-object v0, p0, Lir/mahdi/mzip/rar/Archive;->markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    .line 184
    iput-object v0, p0, Lir/mahdi/mzip/rar/Archive;->newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

    .line 185
    iget-object v1, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    const/4 v1, 0x0

    .line 186
    iput v1, p0, Lir/mahdi/mzip/rar/Archive;->currentHeaderIndex:I

    :goto_0
    :pswitch_0
    const/4 v2, 0x7

    .line 192
    new-array v3, v2, [B

    .line 194
    iget-object v4, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v4}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->getPosition()J

    move-result-wide v4

    cmp-long v6, v4, p1

    if-ltz v6, :cond_0

    goto :goto_1

    .line 202
    :cond_0
    iget-object v6, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v6, v3, v2}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    move-result v6

    if-nez v6, :cond_1

    :goto_1
    return-void

    .line 206
    :cond_1
    new-instance v6, Lir/mahdi/mzip/rar/rarfile/BaseBlock;

    invoke-direct {v6, v3}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>([B)V

    .line 208
    invoke-virtual {v6, v4, v5}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->setPositionInFile(J)V

    .line 210
    sget-object v3, Lir/mahdi/mzip/rar/Archive$2;->$SwitchMap$ir$mahdi$mzip$rar$rarfile$UnrarHeadertype:[I

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->ordinal()I

    move-result v4

    aget v3, v3, v4

    const/4 v4, 0x6

    const/16 v5, 0x8

    const/4 v7, 0x4

    packed-switch v3, :pswitch_data_0

    .line 294
    new-array v3, v7, [B

    .line 295
    iget-object v4, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v4, v3, v7}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 296
    new-instance v4, Lir/mahdi/mzip/rar/rarfile/BlockHeader;

    invoke-direct {v4, v6, v3}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    .line 299
    sget-object v3, Lir/mahdi/mzip/rar/Archive$2;->$SwitchMap$ir$mahdi$mzip$rar$rarfile$UnrarHeadertype:[I

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v6

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->ordinal()I

    move-result v6

    aget v3, v3, v6

    goto/16 :goto_4

    .line 272
    :pswitch_1
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->hasArchiveDataCRC()Z

    move-result p1

    if-eqz p1, :cond_2

    const/4 v1, 0x4

    .line 275
    :cond_2
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->hasVolumeNumber()Z

    move-result p1

    if-eqz p1, :cond_3

    add-int/lit8 v1, v1, 0x2

    :cond_3
    if-lez v1, :cond_4

    .line 280
    new-array p1, v1, [B

    .line 281
    iget-object p2, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {p2, p1, v1}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 282
    new-instance p2, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;

    invoke-direct {p2, v6, p1}, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    goto :goto_2

    .line 287
    :cond_4
    new-instance p2, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;

    invoke-direct {p2, v6, v0}, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    .line 289
    :goto_2
    iget-object p1, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {p1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void

    .line 258
    :pswitch_2
    new-array v2, v4, [B

    .line 259
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v3, v2, v4}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 260
    new-instance v3, Lir/mahdi/mzip/rar/rarfile/CommentHeader;

    invoke-direct {v3, v6, v2}, Lir/mahdi/mzip/rar/rarfile/CommentHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    .line 261
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 264
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->getPositionInFile()J

    move-result-wide v4

    .line 265
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->getHeaderSize()S

    move-result v2

    int-to-long v2, v2

    add-long/2addr v4, v2

    .line 266
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v2, v4, v5}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->setPosition(J)V

    goto/16 :goto_0

    .line 249
    :pswitch_3
    new-array v3, v2, [B

    .line 250
    iget-object v4, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v4, v3, v2}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 251
    new-instance v2, Lir/mahdi/mzip/rar/rarfile/AVHeader;

    invoke-direct {v2, v6, v3}, Lir/mahdi/mzip/rar/rarfile/AVHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    .line 252
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 239
    :pswitch_4
    new-array v2, v5, [B

    .line 240
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v3, v2, v5}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 241
    new-instance v3, Lir/mahdi/mzip/rar/rarfile/SignHeader;

    invoke-direct {v3, v6, v2}, Lir/mahdi/mzip/rar/rarfile/SignHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    .line 242
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 223
    :pswitch_5
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->hasEncryptVersion()Z

    move-result v3

    if-eqz v3, :cond_5

    goto :goto_3

    :cond_5
    const/4 v2, 0x6

    .line 225
    :goto_3
    new-array v3, v2, [B

    .line 226
    iget-object v4, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v4, v3, v2}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 227
    new-instance v2, Lir/mahdi/mzip/rar/rarfile/MainHeader;

    invoke-direct {v2, v6, v3}, Lir/mahdi/mzip/rar/rarfile/MainHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V

    .line 228
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 229
    iput-object v2, p0, Lir/mahdi/mzip/rar/Archive;->newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

    .line 230
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/rarfile/MainHeader;->isEncrypted()Z

    move-result v2

    if-nez v2, :cond_6

    goto/16 :goto_0

    .line 231
    :cond_6
    new-instance p1, Lir/mahdi/mzip/rar/exception/RarException;

    sget-object p2, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->rarEncryptedException:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-direct {p1, p2}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V

    throw p1

    .line 213
    :pswitch_6
    new-instance v2, Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    invoke-direct {v2, v6}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    iput-object v2, p0, Lir/mahdi/mzip/rar/Archive;->markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    .line 214
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->isSignature()Z

    move-result v2

    if-eqz v2, :cond_7

    .line 218
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 215
    :cond_7
    new-instance p1, Lir/mahdi/mzip/rar/exception/RarException;

    sget-object p2, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->badRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-direct {p1, p2}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V

    throw p1

    :goto_4
    const/4 v6, 0x1

    if-eq v3, v6, :cond_a

    const/4 v6, 0x2

    if-eq v3, v6, :cond_a

    const/4 v6, 0x3

    if-eq v3, v6, :cond_9

    if-ne v3, v7, :cond_8

    .line 330
    new-array v2, v6, [B

    .line 331
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v3, v2, v6}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 333
    new-instance v3, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;

    invoke-direct {v3, v4, v2}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;[B)V

    .line 335
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->print()V

    .line 336
    sget-object v2, Lir/mahdi/mzip/rar/Archive$2;->$SwitchMap$ir$mahdi$mzip$rar$rarfile$SubBlockHeaderType:[I

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->getSubType()Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->ordinal()I

    move-result v4

    aget v2, v2, v4

    packed-switch v2, :pswitch_data_1

    goto/16 :goto_0

    .line 366
    :pswitch_7
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->getHeaderSize()S

    move-result v2

    add-int/lit8 v2, v2, -0x7

    add-int/lit8 v2, v2, -0x4

    add-int/lit8 v2, v2, -0x3

    .line 370
    new-array v4, v2, [B

    .line 371
    iget-object v5, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v5, v4, v2}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 372
    new-instance v2, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;

    invoke-direct {v2, v3, v4}, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;[B)V

    .line 374
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->print()V

    .line 375
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_8
    const/16 v2, 0xa

    .line 352
    new-array v4, v2, [B

    .line 353
    iget-object v5, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v5, v4, v2}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 354
    new-instance v2, Lir/mahdi/mzip/rar/rarfile/EAHeader;

    invoke-direct {v2, v3, v4}, Lir/mahdi/mzip/rar/rarfile/EAHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;[B)V

    .line 356
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/rarfile/EAHeader;->print()V

    .line 357
    iget-object v3, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 338
    :pswitch_9
    new-array v2, v5, [B

    .line 339
    iget-object v4, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v4, v2, v5}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 341
    new-instance v4, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;

    invoke-direct {v4, v3, v2}, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;[B)V

    .line 343
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->print()V

    .line 344
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    .line 384
    :cond_8
    sget-object p1, Lir/mahdi/mzip/rar/Archive;->logger:Ljava/util/logging/Logger;

    const-string p2, "Unknown Header"

    invoke-virtual {p1, p2}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    .line 385
    new-instance p1, Lir/mahdi/mzip/rar/exception/RarException;

    sget-object p2, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->notRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-direct {p1, p2}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V

    throw p1

    .line 316
    :cond_9
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getHeaderSize()S

    move-result v3

    sub-int/2addr v3, v2

    sub-int/2addr v3, v7

    .line 319
    new-array v2, v3, [B

    .line 320
    iget-object v5, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v5, v2, v3}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 321
    new-instance v3, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;

    invoke-direct {v3, v4, v2}, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;[B)V

    .line 324
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->getPositionInFile()J

    move-result-wide v4

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->getHeaderSize()S

    move-result v2

    int-to-long v6, v2

    add-long/2addr v4, v6

    .line 325
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->getDataSize()I

    move-result v2

    int-to-long v2, v2

    add-long/2addr v4, v2

    .line 326
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v2, v4, v5}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->setPosition(J)V

    goto/16 :goto_0

    .line 302
    :cond_a
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getHeaderSize()S

    move-result v3

    sub-int/2addr v3, v2

    sub-int/2addr v3, v7

    .line 305
    new-array v2, v3, [B

    .line 306
    iget-object v5, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v5, v2, v3}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->readFully([BI)I

    .line 308
    new-instance v3, Lir/mahdi/mzip/rar/rarfile/FileHeader;

    invoke-direct {v3, v4, v2}, Lir/mahdi/mzip/rar/rarfile/FileHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;[B)V

    .line 309
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 310
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getPositionInFile()J

    move-result-wide v4

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getHeaderSize()S

    move-result v2

    int-to-long v6, v2

    add-long/2addr v4, v6

    .line 311
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFullPackSize()J

    move-result-wide v2

    add-long/2addr v4, v2

    .line 312
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    invoke-interface {v2, v4, v5}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->setPosition(J)V

    goto/16 :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x5
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_0
        :pswitch_0
        :pswitch_7
    .end packed-switch
.end method

.method private setFile(Lir/mahdi/mzip/rar/io/IReadOnlyAccess;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-wide/16 v0, 0x0

    .line 110
    iput-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedSize:J

    .line 111
    iput-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedRead:J

    .line 112
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/Archive;->close()V

    .line 113
    iput-object p1, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    .line 115
    :try_start_0
    invoke-direct {p0, p2, p3}, Lir/mahdi/mzip/rar/Archive;->readHeaders(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 117
    sget-object p2, Lir/mahdi/mzip/rar/Archive;->logger:Ljava/util/logging/Logger;

    sget-object p3, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const-string v0, "exception in archive constructor maybe file is encrypted or currupt"

    invoke-virtual {p2, p3, v0, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 124
    :goto_0
    iget-object p1, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lir/mahdi/mzip/rar/rarfile/BaseBlock;

    .line 125
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object p3

    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    if-ne p3, v0, :cond_0

    .line 126
    iget-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedSize:J

    check-cast p2, Lir/mahdi/mzip/rar/rarfile/FileHeader;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFullPackSize()J

    move-result-wide p2

    add-long/2addr v0, p2

    iput-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedSize:J

    goto :goto_1

    .line 129
    :cond_1
    iget-object p1, p0, Lir/mahdi/mzip/rar/Archive;->unrarCallback:Lir/mahdi/mzip/rar/UnrarCallback;

    if-eqz p1, :cond_2

    .line 130
    iget-wide p2, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedRead:J

    iget-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedSize:J

    invoke-interface {p1, p2, p3, v0, v1}, Lir/mahdi/mzip/rar/UnrarCallback;->volumeProgressChanged(JJ)V

    :cond_2
    return-void
.end method


# virtual methods
.method public bytesReadRead(I)V
    .locals 4

    if-lez p1, :cond_0

    .line 137
    iget-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedRead:J

    int-to-long v2, p1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedRead:J

    .line 138
    iget-object p1, p0, Lir/mahdi/mzip/rar/Archive;->unrarCallback:Lir/mahdi/mzip/rar/UnrarCallback;

    if-eqz p1, :cond_0

    .line 139
    iget-wide v0, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedRead:J

    iget-wide v2, p0, Lir/mahdi/mzip/rar/Archive;->totalPackedSize:J

    invoke-interface {p1, v0, v1, v2, v3}, Lir/mahdi/mzip/rar/UnrarCallback;->volumeProgressChanged(JJ)V

    :cond_0
    return-void
.end method

.method public close()V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 480
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    if-eqz v0, :cond_0

    .line 481
    invoke-interface {v0}, Lir/mahdi/mzip/rar/io/IReadOnlyAccess;->close()V

    const/4 v0, 0x0

    .line 482
    iput-object v0, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    .line 484
    :cond_0
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->unpack:Lir/mahdi/mzip/rar/unpack/Unpack;

    if-eqz v0, :cond_1

    .line 485
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/Unpack;->cleanUp()V

    :cond_1
    return-void
.end method

.method public extractFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/OutputStream;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 394
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 398
    :try_start_0
    invoke-direct {p0, p1, p2}, Lir/mahdi/mzip/rar/Archive;->doExtractFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 400
    instance-of p2, p1, Lir/mahdi/mzip/rar/exception/RarException;

    if-eqz p2, :cond_0

    .line 401
    check-cast p1, Lir/mahdi/mzip/rar/exception/RarException;

    throw p1

    .line 403
    :cond_0
    new-instance p2, Lir/mahdi/mzip/rar/exception/RarException;

    invoke-direct {p2, p1}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Ljava/lang/Exception;)V

    throw p2

    .line 395
    :cond_1
    new-instance p1, Lir/mahdi/mzip/rar/exception/RarException;

    sget-object p2, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->headerNotInArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-direct {p1, p2}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V

    throw p1
.end method

.method public getFileHeaders()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lir/mahdi/mzip/rar/rarfile/FileHeader;",
            ">;"
        }
    .end annotation

    .line 150
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 151
    iget-object v1, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lir/mahdi/mzip/rar/rarfile/BaseBlock;

    .line 152
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v3

    sget-object v4, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 153
    check-cast v2, Lir/mahdi/mzip/rar/rarfile/FileHeader;

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public getInputStream(Lir/mahdi/mzip/rar/rarfile/FileHeader;)Ljava/io/InputStream;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lir/mahdi/mzip/rar/exception/RarException;,
            Ljava/io/IOException;
        }
    .end annotation

    .line 410
    new-instance v0, Ljava/io/PipedInputStream;

    const v1, 0x8000

    invoke-direct {v0, v1}, Ljava/io/PipedInputStream;-><init>(I)V

    .line 411
    new-instance v1, Ljava/io/PipedOutputStream;

    invoke-direct {v1, v0}, Ljava/io/PipedOutputStream;-><init>(Ljava/io/PipedInputStream;)V

    .line 415
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lir/mahdi/mzip/rar/Archive$1;

    invoke-direct {v3, p0, p1, v1}, Lir/mahdi/mzip/rar/Archive$1;-><init>(Lir/mahdi/mzip/rar/Archive;Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/PipedOutputStream;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 427
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    return-object v0
.end method

.method public getMainHeader()Lir/mahdi/mzip/rar/rarfile/MainHeader;
    .locals 1

    .line 472
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

    return-object v0
.end method

.method public getRof()Lir/mahdi/mzip/rar/io/IReadOnlyAccess;
    .locals 1

    .line 146
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->rof:Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    return-object v0
.end method

.method public getUnrarCallback()Lir/mahdi/mzip/rar/UnrarCallback;
    .locals 1

    .line 171
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->unrarCallback:Lir/mahdi/mzip/rar/UnrarCallback;

    return-object v0
.end method

.method public getVolume()Lir/mahdi/mzip/rar/Volume;
    .locals 1

    .line 498
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->volume:Lir/mahdi/mzip/rar/Volume;

    return-object v0
.end method

.method public getVolumeManager()Lir/mahdi/mzip/rar/VolumeManager;
    .locals 1

    .line 490
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->volumeManager:Lir/mahdi/mzip/rar/VolumeManager;

    return-object v0
.end method

.method public isEncrypted()Z
    .locals 2

    .line 175
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->newMhd:Lir/mahdi/mzip/rar/rarfile/MainHeader;

    if-eqz v0, :cond_0

    .line 176
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/rarfile/MainHeader;->isEncrypted()Z

    move-result v0

    return v0

    .line 178
    :cond_0
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "mainheader is null"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public isOldFormat()Z
    .locals 1

    .line 476
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->markHead:Lir/mahdi/mzip/rar/rarfile/MarkHeader;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->isOldFormat()Z

    move-result v0

    return v0
.end method

.method public nextFileHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;
    .locals 4

    .line 160
    iget-object v0, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 161
    :cond_0
    iget v1, p0, Lir/mahdi/mzip/rar/Archive;->currentHeaderIndex:I

    if-ge v1, v0, :cond_1

    .line 162
    iget-object v2, p0, Lir/mahdi/mzip/rar/Archive;->headers:Ljava/util/List;

    add-int/lit8 v3, v1, 0x1

    iput v3, p0, Lir/mahdi/mzip/rar/Archive;->currentHeaderIndex:I

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lir/mahdi/mzip/rar/rarfile/BaseBlock;

    .line 163
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v2

    sget-object v3, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    if-ne v2, v3, :cond_0

    .line 164
    check-cast v1, Lir/mahdi/mzip/rar/rarfile/FileHeader;

    return-object v1

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public setVolume(Lir/mahdi/mzip/rar/Volume;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 502
    iput-object p1, p0, Lir/mahdi/mzip/rar/Archive;->volume:Lir/mahdi/mzip/rar/Volume;

    .line 503
    invoke-interface {p1}, Lir/mahdi/mzip/rar/Volume;->getReadOnlyAccess()Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    move-result-object v0

    invoke-interface {p1}, Lir/mahdi/mzip/rar/Volume;->getLength()J

    move-result-wide v1

    invoke-direct {p0, v0, v1, v2}, Lir/mahdi/mzip/rar/Archive;->setFile(Lir/mahdi/mzip/rar/io/IReadOnlyAccess;J)V

    return-void
.end method

.method public setVolumeManager(Lir/mahdi/mzip/rar/VolumeManager;)V
    .locals 0

    .line 494
    iput-object p1, p0, Lir/mahdi/mzip/rar/Archive;->volumeManager:Lir/mahdi/mzip/rar/VolumeManager;

    return-void
.end method
