.class public Lir/mahdi/mzip/rar/RarArchive;
.super Ljava/lang/Object;
.source "RarArchive.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static createDirectory(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/File;)V
    .locals 2

    .line 116
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isUnicode()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 117
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameW()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 118
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_1

    .line 119
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameW()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Lir/mahdi/mzip/rar/RarArchive;->makeDirectory(Ljava/io/File;Ljava/lang/String;)V

    goto :goto_0

    .line 121
    :cond_0
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isUnicode()Z

    move-result v0

    if-nez v0, :cond_1

    .line 122
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 123
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_1

    .line 124
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Lir/mahdi/mzip/rar/RarArchive;->makeDirectory(Ljava/io/File;Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method private static createFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/File;)Ljava/io/File;
    .locals 2

    .line 76
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isFileHeader()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isUnicode()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 77
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameW()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    .line 79
    :cond_0
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameString()Ljava/lang/String;

    move-result-object p0

    .line 81
    :goto_0
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 82
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_1

    .line 84
    :try_start_0
    invoke-static {p1, p0}, Lir/mahdi/mzip/rar/RarArchive;->makeFile(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    return-object v0
.end method

.method public static extractArchive(Ljava/io/File;Ljava/io/File;)V
    .locals 3

    .line 35
    :try_start_0
    new-instance v0, Lir/mahdi/mzip/rar/Archive;

    invoke-direct {v0, p0}, Lir/mahdi/mzip/rar/Archive;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Lir/mahdi/mzip/rar/exception/RarException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_4

    .line 40
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/Archive;->isEncrypted()Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    .line 46
    :cond_0
    :goto_1
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/Archive;->nextFileHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object p0

    if-nez p0, :cond_1

    goto :goto_2

    .line 50
    :cond_1
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isEncrypted()Z

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_1

    .line 57
    :cond_2
    :try_start_1
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_3

    .line 58
    invoke-static {p0, p1}, Lir/mahdi/mzip/rar/RarArchive;->createDirectory(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/File;)V

    goto :goto_1

    .line 60
    :cond_3
    invoke-static {p0, p1}, Lir/mahdi/mzip/rar/RarArchive;->createFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/File;)Ljava/io/File;

    move-result-object v1

    .line 61
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 62
    invoke-virtual {v0, p0, v2}, Lir/mahdi/mzip/rar/Archive;->extractFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/OutputStream;)V

    .line 63
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lir/mahdi/mzip/rar/exception/RarException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    nop

    goto :goto_1

    :cond_4
    :goto_2
    return-void
.end method

.method public static extractArchive(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    if-eqz p0, :cond_2

    if-eqz p1, :cond_2

    .line 20
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 21
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 24
    new-instance p0, Ljava/io/File;

    invoke-direct {p0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 30
    invoke-static {v0, p0}, Lir/mahdi/mzip/rar/RarArchive;->extractArchive(Ljava/io/File;Ljava/io/File;)V

    return-void

    .line 26
    :cond_0
    new-instance p0, Ljava/lang/RuntimeException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "the destination must exist and point to a directory: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 22
    :cond_1
    new-instance p1, Ljava/lang/RuntimeException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "the archive does not exit: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 18
    :cond_2
    new-instance p0, Ljava/lang/RuntimeException;

    const-string p1, "archive and destination must me set"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private static makeDirectory(Ljava/io/File;Ljava/lang/String;)V
    .locals 5

    const-string v0, "\\\\"

    .line 129
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    .line 134
    :cond_0
    array-length v0, p1

    const/4 v1, 0x0

    const-string v2, ""

    :goto_0
    if-ge v1, v0, :cond_1

    aget-object v3, p1, v1

    .line 135
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 136
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, p0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->mkdir()Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private static makeFile(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v0, "\\\\"

    .line 93
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    .line 98
    :cond_0
    array-length v2, v0

    const/4 v3, 0x1

    if-ne v2, v3, :cond_1

    .line 100
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0

    :cond_1
    if-le v2, v3, :cond_3

    const/4 p1, 0x0

    const-string v1, ""

    .line 102
    :goto_0
    array-length v2, v0

    sub-int/2addr v2, v3

    if-ge p1, v2, :cond_2

    .line 103
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v1, v0, p1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 104
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->mkdir()Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    .line 106
    :cond_2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v1, v0

    sub-int/2addr v1, v3

    aget-object v0, v0, v1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 107
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 108
    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    return-object v0

    :cond_3
    return-object v1
.end method
