.class public Lir/mahdi/mzip/rar/impl/FileVolumeManager;
.super Ljava/lang/Object;
.source "FileVolumeManager.java"

# interfaces
.implements Lir/mahdi/mzip/rar/VolumeManager;


# instance fields
.field private final firstVolume:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;)V
    .locals 0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    iput-object p1, p0, Lir/mahdi/mzip/rar/impl/FileVolumeManager;->firstVolume:Ljava/io/File;

    return-void
.end method


# virtual methods
.method public nextArchive(Lir/mahdi/mzip/rar/Archive;Lir/mahdi/mzip/rar/Volume;)Lir/mahdi/mzip/rar/Volume;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    if-nez p2, :cond_0

    .line 39
    new-instance p2, Lir/mahdi/mzip/rar/impl/FileVolume;

    iget-object v0, p0, Lir/mahdi/mzip/rar/impl/FileVolumeManager;->firstVolume:Ljava/io/File;

    invoke-direct {p2, p1, v0}, Lir/mahdi/mzip/rar/impl/FileVolume;-><init>(Lir/mahdi/mzip/rar/Archive;Ljava/io/File;)V

    return-object p2

    .line 41
    :cond_0
    check-cast p2, Lir/mahdi/mzip/rar/impl/FileVolume;

    .line 42
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/Archive;->getMainHeader()Lir/mahdi/mzip/rar/rarfile/MainHeader;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/rarfile/MainHeader;->isNewNumbering()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 43
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/Archive;->isOldFormat()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v0, 0x1

    .line 44
    :goto_1
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/impl/FileVolume;->getFile()Ljava/io/File;

    move-result-object p2

    .line 45
    invoke-virtual {p2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p2

    .line 44
    invoke-static {p2, v0}, Lir/mahdi/mzip/rar/util/VolumeHelper;->nextVolumeName(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p2

    .line 46
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 48
    new-instance p2, Lir/mahdi/mzip/rar/impl/FileVolume;

    invoke-direct {p2, p1, v0}, Lir/mahdi/mzip/rar/impl/FileVolume;-><init>(Lir/mahdi/mzip/rar/Archive;Ljava/io/File;)V

    return-object p2
.end method
