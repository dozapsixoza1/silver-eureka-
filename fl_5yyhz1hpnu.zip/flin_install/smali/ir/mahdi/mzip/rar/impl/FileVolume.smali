.class public Lir/mahdi/mzip/rar/impl/FileVolume;
.super Ljava/lang/Object;
.source "FileVolume.java"

# interfaces
.implements Lir/mahdi/mzip/rar/Volume;


# instance fields
.field private final archive:Lir/mahdi/mzip/rar/Archive;

.field private final file:Ljava/io/File;


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/Archive;Ljava/io/File;)V
    .locals 0

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object p1, p0, Lir/mahdi/mzip/rar/impl/FileVolume;->archive:Lir/mahdi/mzip/rar/Archive;

    .line 34
    iput-object p2, p0, Lir/mahdi/mzip/rar/impl/FileVolume;->file:Ljava/io/File;

    return-void
.end method


# virtual methods
.method public getArchive()Lir/mahdi/mzip/rar/Archive;
    .locals 1

    .line 49
    iget-object v0, p0, Lir/mahdi/mzip/rar/impl/FileVolume;->archive:Lir/mahdi/mzip/rar/Archive;

    return-object v0
.end method

.method public getFile()Ljava/io/File;
    .locals 1

    .line 53
    iget-object v0, p0, Lir/mahdi/mzip/rar/impl/FileVolume;->file:Ljava/io/File;

    return-object v0
.end method

.method public getLength()J
    .locals 2

    .line 44
    iget-object v0, p0, Lir/mahdi/mzip/rar/impl/FileVolume;->file:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v0

    return-wide v0
.end method

.method public getReadOnlyAccess()Lir/mahdi/mzip/rar/io/IReadOnlyAccess;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 39
    new-instance v0, Lir/mahdi/mzip/rar/io/ReadOnlyAccessFile;

    iget-object v1, p0, Lir/mahdi/mzip/rar/impl/FileVolume;->file:Ljava/io/File;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/io/ReadOnlyAccessFile;-><init>(Ljava/io/File;)V

    return-object v0
.end method
