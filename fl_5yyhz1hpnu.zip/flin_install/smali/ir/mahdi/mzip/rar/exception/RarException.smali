.class public Lir/mahdi/mzip/rar/exception/RarException;
.super Ljava/lang/Exception;
.source "RarException.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private type:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V
    .locals 1

    .line 36
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->name()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 37
    iput-object p1, p0, Lir/mahdi/mzip/rar/exception/RarException;->type:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/exception/RarException;)V
    .locals 1

    .line 31
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/exception/RarException;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 32
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/exception/RarException;->getType()Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    move-result-object p1

    iput-object p1, p0, Lir/mahdi/mzip/rar/exception/RarException;->type:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Exception;)V
    .locals 1

    .line 25
    sget-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->unkownError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->name()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 26
    sget-object p1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->unkownError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    iput-object p1, p0, Lir/mahdi/mzip/rar/exception/RarException;->type:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-void
.end method


# virtual methods
.method public getType()Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;
    .locals 1

    .line 41
    iget-object v0, p0, Lir/mahdi/mzip/rar/exception/RarException;->type:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-object v0
.end method

.method public setType(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V
    .locals 0

    .line 45
    iput-object p1, p0, Lir/mahdi/mzip/rar/exception/RarException;->type:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-void
.end method
