.class public final enum Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;
.super Ljava/lang/Enum;
.source "RarException.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lir/mahdi/mzip/rar/exception/RarException;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "RarExceptionType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum badRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum crcError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum headerNotInArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum ioError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum notImplementedYet:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum notRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum rarEncryptedException:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum unkownError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

.field public static final enum wrongHeaderType:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    .line 49
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v1, 0x0

    const-string v2, "notImplementedYet"

    invoke-direct {v0, v2, v1}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->notImplementedYet:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 50
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v2, 0x1

    const-string v3, "crcError"

    invoke-direct {v0, v3, v2}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->crcError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 51
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v3, 0x2

    const-string v4, "notRarArchive"

    invoke-direct {v0, v4, v3}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->notRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 52
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v4, 0x3

    const-string v5, "badRarArchive"

    invoke-direct {v0, v5, v4}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->badRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 53
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v5, 0x4

    const-string v6, "unkownError"

    invoke-direct {v0, v6, v5}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->unkownError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 54
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v6, 0x5

    const-string v7, "headerNotInArchive"

    invoke-direct {v0, v7, v6}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->headerNotInArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 55
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v7, 0x6

    const-string v8, "wrongHeaderType"

    invoke-direct {v0, v8, v7}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->wrongHeaderType:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 56
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/4 v8, 0x7

    const-string v9, "ioError"

    invoke-direct {v0, v9, v8}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->ioError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    .line 57
    new-instance v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/16 v9, 0x8

    const-string v10, "rarEncryptedException"

    invoke-direct {v0, v10, v9}, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->rarEncryptedException:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    const/16 v0, 0x9

    .line 48
    new-array v0, v0, [Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    sget-object v10, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->notImplementedYet:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v10, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->crcError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->notRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->badRarArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->unkownError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->headerNotInArchive:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v6

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->wrongHeaderType:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v7

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->ioError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v8

    sget-object v1, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->rarEncryptedException:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    aput-object v1, v0, v9

    sput-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->$VALUES:[Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 48
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;
    .locals 1

    .line 48
    const-class v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;
    .locals 1

    .line 48
    sget-object v0, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->$VALUES:[Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    return-object v0
.end method
