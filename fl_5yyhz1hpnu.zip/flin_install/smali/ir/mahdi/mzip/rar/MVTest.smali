.class public Lir/mahdi/mzip/rar/MVTest;
.super Ljava/lang/Object;
.source "MVTest.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static main([Ljava/lang/String;)V
    .locals 4

    .line 17
    new-instance p0, Ljava/io/File;

    const-string v0, "/home/rogiel/fs/home/ae721273-eade-45e7-8112-d14115ebae56/Village People - Y.M.C.A.mp3.part1.rar"

    invoke-direct {p0, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 20
    :try_start_0
    new-instance v0, Lir/mahdi/mzip/rar/Archive;

    new-instance v1, Lir/mahdi/mzip/rar/impl/FileVolumeManager;

    invoke-direct {v1, p0}, Lir/mahdi/mzip/rar/impl/FileVolumeManager;-><init>(Ljava/io/File;)V

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/Archive;-><init>(Lir/mahdi/mzip/rar/VolumeManager;)V
    :try_end_0
    .catch Lir/mahdi/mzip/rar/exception/RarException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p0

    .line 26
    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0

    :catch_1
    move-exception p0

    .line 23
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/exception/RarException;->printStackTrace()V

    :goto_0
    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_0

    .line 29
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/Archive;->getMainHeader()Lir/mahdi/mzip/rar/rarfile/MainHeader;

    move-result-object p0

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/MainHeader;->print()V

    .line 30
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/Archive;->nextFileHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object p0

    :goto_2
    if-eqz p0, :cond_0

    .line 33
    :try_start_1
    new-instance v1, Ljava/io/File;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/home/rogiel/fs/test/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 35
    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 36
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 37
    invoke-virtual {v0, p0, v2}, Lir/mahdi/mzip/rar/Archive;->extractFile(Lir/mahdi/mzip/rar/rarfile/FileHeader;Ljava/io/OutputStream;)V

    .line 38
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Lir/mahdi/mzip/rar/exception/RarException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2

    goto :goto_3

    :catch_2
    move-exception p0

    .line 47
    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_3

    :catch_3
    move-exception p0

    .line 44
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/exception/RarException;->printStackTrace()V

    goto :goto_3

    :catch_4
    move-exception p0

    .line 41
    invoke-virtual {p0}, Ljava/io/FileNotFoundException;->printStackTrace()V

    .line 49
    :goto_3
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/Archive;->nextFileHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object p0

    goto :goto_2

    :cond_0
    return-void
.end method
