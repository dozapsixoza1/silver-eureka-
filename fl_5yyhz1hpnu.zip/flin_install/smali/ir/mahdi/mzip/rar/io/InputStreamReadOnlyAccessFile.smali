.class public Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;
.super Ljava/lang/Object;
.source "InputStreamReadOnlyAccessFile.java"

# interfaces
.implements Lir/mahdi/mzip/rar/io/IReadOnlyAccess;


# instance fields
.field private is:Lir/mahdi/mzip/rar/io/RandomAccessStream;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 2

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    new-instance v0, Lir/mahdi/mzip/rar/io/RandomAccessStream;

    new-instance v1, Ljava/io/BufferedInputStream;

    invoke-direct {v1, p1}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/io/RandomAccessStream;-><init>(Ljava/io/InputStream;)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    return-void
.end method


# virtual methods
.method public close()V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 43
    iget-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/io/RandomAccessStream;->close()V

    return-void
.end method

.method public getPosition()J
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 17
    iget-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/io/RandomAccessStream;->getLongFilePointer()J

    move-result-wide v0

    return-wide v0
.end method

.method public read()I
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 27
    iget-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/io/RandomAccessStream;->read()I

    move-result v0

    return v0
.end method

.method public read([BII)I
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 32
    iget-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    invoke-virtual {v0, p1, p2, p3}, Lir/mahdi/mzip/rar/io/RandomAccessStream;->read([BII)I

    move-result p1

    return p1
.end method

.method public readFully([BI)I
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 37
    iget-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    invoke-virtual {v0, p1, p2}, Lir/mahdi/mzip/rar/io/RandomAccessStream;->readFully([BI)V

    return p2
.end method

.method public setPosition(J)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 22
    iget-object v0, p0, Lir/mahdi/mzip/rar/io/InputStreamReadOnlyAccessFile;->is:Lir/mahdi/mzip/rar/io/RandomAccessStream;

    invoke-virtual {v0, p1, p2}, Lir/mahdi/mzip/rar/io/RandomAccessStream;->seek(J)V

    return-void
.end method
