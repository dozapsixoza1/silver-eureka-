.class public Lir/mahdi/mzip/rar/unsigned/UnsignedByte;
.super Ljava/lang/Object;
.source "UnsignedByte.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static add(BB)S
    .locals 0

    add-int/2addr p0, p1

    int-to-short p0, p0

    return p0
.end method

.method public static intToByte(I)B
    .locals 0

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    return p0
.end method

.method public static longToByte(J)B
    .locals 2

    const-wide/16 v0, 0xff

    and-long/2addr p0, v0

    long-to-int p1, p0

    int-to-byte p0, p1

    return p0
.end method

.method public static main([Ljava/lang/String;)V
    .locals 4

    .line 49
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/4 v0, -0x2

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->add(BB)S

    move-result v2

    invoke-virtual {p0, v2}, Ljava/io/PrintStream;->println(I)V

    .line 50
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/4 v2, -0x1

    invoke-static {v2, v1}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->add(BB)S

    move-result v3

    invoke-virtual {p0, v3}, Ljava/io/PrintStream;->println(I)V

    .line 51
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/16 v3, 0x7f

    invoke-static {v3, v1}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->add(BB)S

    move-result v3

    invoke-virtual {p0, v3}, Ljava/io/PrintStream;->println(I)V

    .line 52
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-static {v2, v2}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->add(BB)S

    move-result v2

    invoke-virtual {p0, v2}, Ljava/io/PrintStream;->println(I)V

    .line 55
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->sub(BB)S

    move-result v0

    invoke-virtual {p0, v0}, Ljava/io/PrintStream;->println(I)V

    .line 56
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/4 v0, 0x0

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->sub(BB)S

    move-result v0

    invoke-virtual {p0, v0}, Ljava/io/PrintStream;->println(I)V

    .line 57
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/16 v0, -0x80

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/unsigned/UnsignedByte;->sub(BB)S

    move-result v0

    invoke-virtual {p0, v0}, Ljava/io/PrintStream;->println(I)V

    .line 59
    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {p0, v1}, Ljava/io/PrintStream;->println(I)V

    return-void
.end method

.method public static shortToByte(S)B
    .locals 0

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    return p0
.end method

.method public static sub(BB)S
    .locals 0

    sub-int/2addr p0, p1

    int-to-short p0, p0

    return p0
.end method
