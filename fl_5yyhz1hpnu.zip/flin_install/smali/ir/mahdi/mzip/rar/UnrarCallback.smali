.class public interface abstract Lir/mahdi/mzip/rar/UnrarCallback;
.super Ljava/lang/Object;
.source "UnrarCallback.java"


# virtual methods
.method public abstract isNextVolumeReady(Lir/mahdi/mzip/rar/Volume;)Z
.end method

.method public abstract volumeProgressChanged(JJ)V
.end method
