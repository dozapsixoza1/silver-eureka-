.class public interface abstract Lir/mahdi/mzip/rar/Volume;
.super Ljava/lang/Object;
.source "Volume.java"


# virtual methods
.method public abstract getArchive()Lir/mahdi/mzip/rar/Archive;
.end method

.method public abstract getLength()J
.end method

.method public abstract getReadOnlyAccess()Lir/mahdi/mzip/rar/io/IReadOnlyAccess;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method
