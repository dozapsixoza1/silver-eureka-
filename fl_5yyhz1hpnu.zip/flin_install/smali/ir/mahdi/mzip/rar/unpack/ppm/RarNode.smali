.class public Lir/mahdi/mzip/rar/unpack/ppm/RarNode;
.super Lir/mahdi/mzip/rar/unpack/ppm/Pointer;
.source "RarNode.java"


# static fields
.field public static final size:I = 0x4


# instance fields
.field private next:I


# direct methods
.method public constructor <init>([B)V
    .locals 0

    .line 28
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;-><init>([B)V

    return-void
.end method


# virtual methods
.method public getNext()I
    .locals 2

    .line 32
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->mem:[B

    if-eqz v0, :cond_0

    .line 33
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->pos:I

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v0

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->next:I

    .line 35
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->next:I

    return v0
.end method

.method public setNext(I)V
    .locals 2

    .line 39
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->next:I

    .line 40
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->mem:[B

    if-eqz v0, :cond_0

    .line 41
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->pos:I

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    :cond_0
    return-void
.end method

.method public setNext(Lir/mahdi/mzip/rar/unpack/ppm/RarNode;)V
    .locals 0

    .line 46
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setNext(I)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 50
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "State["

    .line 51
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  pos="

    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->pos:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  size="

    .line 54
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  next="

    .line 56
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 58
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
