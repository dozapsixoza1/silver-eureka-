.class public Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;
.super Ljava/lang/Object;
.source "VMStandardFilterSignature.java"


# instance fields
.field private CRC:I

.field private length:I

.field private type:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;


# direct methods
.method public constructor <init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V
    .locals 0

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->length:I

    .line 30
    iput p2, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->CRC:I

    .line 31
    iput-object p3, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->type:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-void
.end method


# virtual methods
.method public getCRC()I
    .locals 1

    .line 35
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->CRC:I

    return v0
.end method

.method public getLength()I
    .locals 1

    .line 43
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->length:I

    return v0
.end method

.method public getType()Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;
    .locals 1

    .line 51
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->type:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object v0
.end method

.method public setCRC(I)V
    .locals 0

    .line 39
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->CRC:I

    return-void
.end method

.method public setLength(I)V
    .locals 0

    .line 47
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->length:I

    return-void
.end method

.method public setType(Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V
    .locals 0

    .line 55
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->type:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-void
.end method
