.class public Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;
.super Lir/mahdi/mzip/rar/unpack/ppm/Pointer;
.source "PPMContext.java"


# static fields
.field public static final ExpEscape:[I

.field public static final size:I

.field private static final unionSize:I


# instance fields
.field private final freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

.field private numStats:I

.field private final oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final ps:[I

.field private suffix:I

.field private tempPPMContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private final tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState2:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState3:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState4:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState5:Lir/mahdi/mzip/rar/unpack/ppm/State;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x10

    .line 24
    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ExpEscape:[I

    const/4 v0, 0x6

    .line 26
    invoke-static {v0, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    sput v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->unionSize:I

    .line 27
    sget v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->unionSize:I

    add-int/lit8 v0, v0, 0x2

    add-int/lit8 v0, v0, 0x4

    sput v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->size:I

    return-void

    nop

    :array_0
    .array-data 4
        0x19
        0xe
        0x9
        0x7
        0x5
        0x5
        0x4
        0x4
        0x4
        0x3
        0x3
        0x3
        0x2
        0x2
        0x2
        0x2
    .end array-data
.end method

.method public constructor <init>([B)V
    .locals 2

    .line 47
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;-><init>([B)V

    .line 35
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 36
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState2:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 37
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState3:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 38
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState4:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 39
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState5:Lir/mahdi/mzip/rar/unpack/ppm/State;

    const/16 v0, 0x100

    .line 40
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ps:[I

    .line 44
    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempPPMContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 48
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 49
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-direct {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    return-void
.end method

.method private getArrayIndex(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;Lir/mahdi/mzip/rar/unpack/ppm/State;)I
    .locals 3

    .line 211
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeap()[B

    move-result-object v0

    invoke-direct {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getTempPPMContext([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v0

    .line 212
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 214
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getPrevSuccess()I

    move-result v1

    add-int/lit8 v1, v1, 0x0

    .line 215
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getNS2BSIndx()[I

    move-result-object v2

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    aget v0, v2, v0

    add-int/2addr v1, v0

    .line 216
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHiBitsFlag()I

    move-result v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHB2Flag()[I

    move-result-object v2

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p2

    aget p2, v2, p2

    mul-int/lit8 p2, p2, 0x2

    add-int/2addr v0, p2

    add-int/2addr v1, v0

    .line 217
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getRunLength()I

    move-result p1

    ushr-int/lit8 p1, p1, 0x1a

    and-int/lit8 p1, p1, 0x20

    add-int/2addr v1, p1

    return v1
.end method

.method private getTempPPMContext([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;
    .locals 2

    .line 117
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempPPMContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    if-nez v0, :cond_0

    .line 118
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempPPMContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 120
    :cond_0
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempPPMContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object p1

    return-object p1
.end method

.method private makeEscFreq2(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;I)Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;
    .locals 6

    .line 351
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    const/16 v1, 0x100

    if-eq v0, v1, :cond_3

    .line 353
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v1

    invoke-direct {p0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getTempPPMContext([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v1

    .line 354
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 355
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getNS2Indx()[I

    move-result-object v2

    add-int/lit8 v3, p2, -0x1

    aget v2, v2, v3

    .line 357
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v1

    sub-int/2addr v1, v0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ge p2, v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    add-int/2addr v1, v3

    .line 358
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v5

    mul-int/lit8 v0, v0, 0xb

    if-ge v5, v0, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    mul-int/lit8 v0, v0, 0x2

    add-int/2addr v1, v0

    .line 359
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getNumMasked()I

    move-result v0

    if-le v0, p2, :cond_2

    const/4 v3, 0x1

    :cond_2
    mul-int/lit8 v3, v3, 0x4

    add-int/2addr v1, v3

    .line 360
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHiBitsFlag()I

    move-result p2

    add-int/2addr v1, p2

    .line 361
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSEE2Cont()[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    move-result-object p2

    aget-object p2, p2, v2

    aget-object p2, p2, v1

    .line 362
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object p1

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->getMean()I

    move-result v0

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setScale(J)V

    goto :goto_2

    .line 364
    :cond_3
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getDummySEE2Cont()Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    move-result-object p2

    .line 365
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object p1

    const-wide/16 v0, 0x1

    invoke-virtual {p1, v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setScale(J)V

    :goto_2
    return-object p2
.end method


# virtual methods
.method public createChild(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;Lir/mahdi/mzip/rar/unpack/ppm/State;Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)I
    .locals 1

    .line 125
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeap()[B

    move-result-object v0

    invoke-direct {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getTempPPMContext([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v0

    .line 126
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocContext()I

    move-result p1

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    .line 128
    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setNumStats(I)V

    .line 129
    invoke-virtual {v0, p3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setOneState(Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)V

    .line 130
    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setSuffix(Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;)V

    .line 131
    invoke-virtual {p2, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;)V

    .line 133
    :cond_0
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    return p1
.end method

.method public decodeBinSymbol(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)V
    .locals 14

    .line 226
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v0

    .line 227
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 228
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHB2Flag()[I

    move-result-object v1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v2

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v2

    aget v1, v1, v2

    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setHiBitsFlag(I)V

    .line 229
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    .line 230
    invoke-direct {p0, p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getArrayIndex(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;Lir/mahdi/mzip/rar/unpack/ppm/State;)I

    move-result v3

    .line 231
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getBinSumm()[[I

    move-result-object v4

    aget-object v4, v4, v1

    aget v4, v4, v3

    .line 232
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v5

    const/16 v6, 0xe

    invoke-virtual {v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getCurrentShiftCount(I)J

    move-result-wide v5

    int-to-long v7, v4

    const v9, 0xffff

    const/4 v10, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    cmp-long v13, v5, v7

    if-gez v13, :cond_1

    .line 233
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v5

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v6

    invoke-virtual {v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 234
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v5

    const/16 v6, 0x80

    if-ge v5, v6, :cond_0

    const/4 v12, 0x1

    :cond_0
    invoke-virtual {v0, v12}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    .line 235
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    const-wide/16 v5, 0x0

    invoke-virtual {v0, v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    .line 236
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v0, v7, v8}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    add-int/lit16 v0, v4, 0x80

    .line 237
    invoke-virtual {p0, v4, v11, v10}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getMean(III)I

    move-result v4

    sub-int/2addr v0, v4

    and-int/2addr v0, v9

    .line 238
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getBinSumm()[[I

    move-result-object v4

    aget-object v1, v4, v1

    aput v0, v1, v3

    .line 239
    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setPrevSuccess(I)V

    .line 240
    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->incRunLength(I)V

    goto :goto_0

    .line 242
    :cond_1
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v5

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v5

    invoke-virtual {v5, v7, v8}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    .line 243
    invoke-virtual {p0, v4, v11, v10}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getMean(III)I

    move-result v5

    sub-int/2addr v4, v5

    and-int/2addr v4, v9

    .line 244
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getBinSumm()[[I

    move-result-object v5

    aget-object v1, v5, v1

    aput v4, v1, v3

    .line 245
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v1

    const-wide/16 v5, 0x4000

    invoke-virtual {v1, v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    .line 246
    sget-object v1, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ExpEscape:[I

    ushr-int/lit8 v3, v4, 0xa

    aget v1, v1, v3

    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setInitEsc(I)V

    .line 247
    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setNumMasked(I)V

    .line 248
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCharMask()[I

    move-result-object v1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getEscCount()I

    move-result v2

    aput v2, v1, v0

    .line 249
    invoke-virtual {p1, v12}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setPrevSuccess(I)V

    .line 250
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p1

    invoke-virtual {p1, v12}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    :goto_0
    return-void
.end method

.method public decodeSymbol1(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)Z
    .locals 13

    .line 372
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v0

    .line 373
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v1

    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v2

    int-to-long v2, v2

    invoke-virtual {v1, v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setScale(J)V

    .line 374
    new-instance v1, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v2

    invoke-direct {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 375
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 377
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getCurrentCount()I

    move-result v2

    int-to-long v2, v2

    .line 378
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->getScale()J

    move-result-wide v4

    const/4 v6, 0x0

    cmp-long v7, v2, v4

    if-ltz v7, :cond_0

    return v6

    .line 381
    :cond_0
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v4

    int-to-long v7, v4

    const/4 v5, 0x1

    cmp-long v9, v2, v7

    if-gez v9, :cond_3

    .line 382
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v2

    invoke-virtual {v2, v7, v8}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    mul-int/lit8 v2, v4, 0x2

    int-to-long v2, v2

    .line 383
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v7

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->getScale()J

    move-result-wide v7

    cmp-long v9, v2, v7

    if-lez v9, :cond_1

    const/4 v6, 0x1

    :cond_1
    invoke-virtual {p1, v6}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setPrevSuccess(I)V

    .line 384
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getPrevSuccess()I

    move-result v2

    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->incRunLength(I)V

    const/4 v2, 0x4

    add-int/2addr v4, v2

    .line 386
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v3

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v1

    invoke-virtual {v3, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 387
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v1

    invoke-virtual {v1, v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    .line 388
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    const/16 v1, 0x7c

    if-le v4, v1, :cond_2

    .line 390
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->rescale(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)V

    .line 392
    :cond_2
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object p1

    const-wide/16 v0, 0x0

    invoke-virtual {p1, v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    return v5

    .line 395
    :cond_3
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v7

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v7

    if-nez v7, :cond_4

    return v6

    .line 399
    :cond_4
    invoke-virtual {p1, v6}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setPrevSuccess(I)V

    .line 400
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v7

    add-int/lit8 v8, v7, -0x1

    move v9, v8

    .line 402
    :cond_5
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v10

    invoke-virtual {v10}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v10

    add-int/2addr v4, v10

    int-to-long v10, v4

    cmp-long v12, v10, v2

    if-gtz v12, :cond_7

    add-int/lit8 v9, v9, -0x1

    if-nez v9, :cond_5

    .line 404
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHB2Flag()[I

    move-result-object v2

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v3

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v3

    aget v2, v2, v3

    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setHiBitsFlag(I)V

    .line 405
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v2

    invoke-virtual {v2, v10, v11}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    .line 406
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCharMask()[I

    move-result-object v2

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v3

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getEscCount()I

    move-result v4

    aput v4, v2, v3

    .line 407
    invoke-virtual {p1, v7}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setNumMasked(I)V

    .line 409
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v2

    invoke-virtual {v2, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 411
    :cond_6
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCharMask()[I

    move-result-object v2

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->decAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v3

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v3

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getEscCount()I

    move-result v4

    aput v4, v2, v3

    add-int/lit8 v8, v8, -0x1

    if-nez v8, :cond_6

    .line 413
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object p1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->getScale()J

    move-result-wide v0

    invoke-virtual {p1, v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    return v5

    .line 417
    :cond_7
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v2

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v3

    sub-int/2addr v4, v3

    int-to-long v3, v4

    invoke-virtual {v2, v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    .line 418
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v0, v10, v11}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    .line 419
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->update1(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;I)V

    return v5
.end method

.method public decodeSymbol2(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)Z
    .locals 11

    .line 288
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getNumMasked()I

    move-result v1

    sub-int/2addr v0, v1

    .line 289
    invoke-direct {p0, p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->makeEscFreq2(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;I)Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    move-result-object v1

    .line 290
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    move-result-object v2

    .line 292
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v4

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v3

    .line 293
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState2:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v5

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v4

    .line 294
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v5

    add-int/lit8 v5, v5, -0x6

    invoke-virtual {v3, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    const/4 v5, 0x0

    move v7, v0

    const/4 v0, 0x0

    const/4 v6, 0x0

    .line 300
    :cond_0
    :goto_0
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 301
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCharMask()[I

    move-result-object v8

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v9

    aget v8, v8, v9

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getEscCount()I

    move-result v9

    if-eq v8, v9, :cond_0

    .line 302
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v8

    add-int/2addr v0, v8

    .line 303
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ps:[I

    add-int/lit8 v9, v6, 0x1

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v10

    aput v10, v8, v6

    add-int/lit8 v7, v7, -0x1

    if-nez v7, :cond_5

    .line 305
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v6

    invoke-virtual {v6, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->incScale(I)V

    .line 306
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getCurrentCount()I

    move-result v6

    int-to-long v6, v6

    .line 307
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v8

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->getScale()J

    move-result-wide v8

    cmp-long v10, v6, v8

    if-ltz v10, :cond_1

    return v5

    .line 311
    :cond_1
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ps:[I

    aget v8, v8, v5

    invoke-virtual {v3, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    int-to-long v8, v0

    const/4 v10, 0x1

    cmp-long v0, v6, v8

    if-gez v0, :cond_3

    const/4 v0, 0x0

    .line 314
    :goto_1
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v4

    add-int/2addr v5, v4

    int-to-long v8, v5

    cmp-long v4, v8, v6

    if-gtz v4, :cond_2

    .line 315
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ps:[I

    add-int/2addr v0, v10

    aget v4, v4, v0

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    goto :goto_1

    .line 317
    :cond_2
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v0, v8, v9}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    .line 318
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v2

    sub-int/2addr v5, v2

    int-to-long v4, v5

    invoke-virtual {v0, v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    .line 319
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->update()V

    .line 320
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->update2(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;I)V

    goto :goto_2

    .line 322
    :cond_3
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v0, v8, v9}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setLowCount(J)V

    .line 323
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v3

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->getScale()J

    move-result-wide v5

    invoke-virtual {v0, v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->setHighCount(J)V

    .line 324
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getNumMasked()I

    move-result v3

    sub-int/2addr v0, v3

    const/4 v6, -0x1

    move v3, v0

    const/4 v0, -0x1

    .line 327
    :cond_4
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->ps:[I

    add-int/2addr v0, v10

    aget v5, v5, v0

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 328
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getCharMask()[I

    move-result-object v5

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v7

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getEscCount()I

    move-result v8

    aput v8, v5, v7

    add-int/2addr v3, v6

    if-nez v3, :cond_4

    .line 330
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->getSubRange()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder$SubRange;->getScale()J

    move-result-wide v2

    long-to-int v0, v2

    invoke-virtual {v1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->incSumm(I)V

    .line 331
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    invoke-virtual {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setNumMasked(I)V

    :goto_2
    return v10

    :cond_5
    move v6, v9

    goto/16 :goto_0
.end method

.method public getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;
    .locals 1

    .line 61
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    return-object v0
.end method

.method public getMean(III)I
    .locals 1

    sub-int p3, p2, p3

    const/4 v0, 0x1

    shl-int p3, v0, p3

    add-int/2addr p1, p3

    ushr-int/2addr p1, p2

    return p1
.end method

.method public final getNumStats()I
    .locals 2

    .line 70
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    if-eqz v0, :cond_0

    .line 71
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->pos:I

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    const v1, 0xffff

    and-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->numStats:I

    .line 73
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->numStats:I

    return v0
.end method

.method public getOneState()Lir/mahdi/mzip/rar/unpack/ppm/State;
    .locals 1

    .line 84
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    return-object v0
.end method

.method public getSuffix()I
    .locals 2

    .line 92
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    if-eqz v0, :cond_0

    .line 93
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->pos:I

    add-int/lit8 v1, v1, 0x8

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v0

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->suffix:I

    .line 95
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->suffix:I

    return v0
.end method

.method public init([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;
    .locals 1

    .line 53
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    const/4 v0, 0x0

    .line 54
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->pos:I

    .line 55
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 56
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    return-object p0
.end method

.method public rescale(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)V
    .locals 13

    .line 137
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    .line 139
    new-instance v3, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v4

    invoke-direct {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 140
    new-instance v4, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v5

    invoke-direct {v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 141
    new-instance v5, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v6

    invoke-direct {v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 143
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v6

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v6

    invoke-virtual {v4, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 144
    :goto_0
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v6

    iget-object v7, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v7

    if-eq v6, v7, :cond_0

    .line 146
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v6

    add-int/lit8 v6, v6, -0x6

    invoke-virtual {v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 147
    invoke-static {v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->ppmdSwap(Lir/mahdi/mzip/rar/unpack/ppm/State;Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 145
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->decAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    goto :goto_0

    .line 149
    :cond_0
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v6

    invoke-virtual {v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    const/4 v6, 0x4

    .line 150
    invoke-virtual {v5, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    .line 151
    iget-object v7, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v7, v6}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    .line 152
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v6

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v7

    sub-int/2addr v6, v7

    .line 153
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getOrderFall()I

    move-result v7

    if-eqz v7, :cond_1

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x0

    .line 154
    :goto_1
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v8

    add-int/2addr v8, v7

    ushr-int/2addr v8, v2

    invoke-virtual {v4, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    .line 155
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v9

    invoke-virtual {v8, v9}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setSummFreq(I)V

    .line 157
    :cond_2
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 158
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v8

    sub-int/2addr v6, v8

    .line 159
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v8

    add-int/2addr v8, v7

    ushr-int/2addr v8, v2

    invoke-virtual {v4, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    .line 160
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v9

    invoke-virtual {v8, v9}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    .line 161
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v8

    add-int/lit8 v8, v8, -0x6

    invoke-virtual {v5, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 162
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v8

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v9

    if-le v8, v9, :cond_5

    .line 163
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v8

    invoke-virtual {v3, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 164
    new-instance v8, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    invoke-direct {v8}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;-><init>()V

    .line 165
    invoke-virtual {v8, v3}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 166
    new-instance v9, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v10

    invoke-direct {v9, v10}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 167
    new-instance v10, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v11

    invoke-direct {v10, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 170
    :cond_3
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v11

    add-int/lit8 v11, v11, -0x6

    invoke-virtual {v9, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 171
    invoke-virtual {v3, v9}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 172
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->decAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 173
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v11

    add-int/lit8 v11, v11, -0x6

    invoke-virtual {v10, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 174
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v11

    iget-object v12, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v12}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v12

    if-eq v11, v12, :cond_4

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getFreq()I

    move-result v11

    invoke-virtual {v10}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v12

    if-gt v11, v12, :cond_3

    .line 175
    :cond_4
    invoke-virtual {v3, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)V

    :cond_5
    add-int/lit8 v1, v1, -0x1

    if-nez v1, :cond_2

    .line 178
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v3

    if-nez v3, :cond_8

    :cond_6
    add-int/2addr v1, v2

    .line 181
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->decAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 182
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v3

    if-eqz v3, :cond_6

    add-int/2addr v6, v1

    .line 184
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v3

    sub-int/2addr v3, v1

    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setNumStats(I)V

    .line 185
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v1

    if-ne v1, v2, :cond_8

    .line 186
    new-instance v1, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    invoke-direct {v1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;-><init>()V

    .line 187
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v3

    invoke-virtual {v5, v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 188
    invoke-virtual {v1, v5}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 192
    :cond_7
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getFreq()I

    move-result v3

    ushr-int/2addr v3, v2

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->decFreq(I)V

    ushr-int/2addr v6, v2

    if-gt v6, v2, :cond_7

    .line 195
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    move-result-object v3

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v4

    add-int/2addr v0, v2

    ushr-int/2addr v0, v2

    invoke-virtual {v3, v4, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeUnits(II)V

    .line 196
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)V

    .line 197
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p1

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v0

    invoke-virtual {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    return-void

    :cond_8
    ushr-int/lit8 v1, v6, 0x1

    sub-int/2addr v6, v1

    .line 202
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v1, v6}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    add-int/2addr v0, v2

    ushr-int/2addr v0, v2

    .line 203
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v1

    add-int/2addr v1, v2

    ushr-int/2addr v1, v2

    if-eq v0, v1, :cond_9

    .line 205
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    move-result-object v3

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v4

    invoke-virtual {v3, v4, v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->shrinkUnits(III)I

    move-result v0

    invoke-virtual {v2, v0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setStats(I)V

    .line 207
    :cond_9
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p1

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v0

    invoke-virtual {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    return-void
.end method

.method public setAddress(I)V
    .locals 1

    .line 111
    invoke-super {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;->setAddress(I)V

    .line 112
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    add-int/lit8 p1, p1, 0x2

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 113
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setAddress(I)V

    return-void
.end method

.method public setFreqData(Lir/mahdi/mzip/rar/unpack/ppm/FreqData;)V
    .locals 2

    .line 65
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setSummFreq(I)V

    .line 66
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result p1

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setStats(I)V

    return-void
.end method

.method public final setNumStats(I)V
    .locals 2

    const v0, 0xffff

    and-int/2addr v0, p1

    .line 77
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->numStats:I

    .line 78
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    if-eqz v0, :cond_0

    .line 79
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->pos:I

    int-to-short p1, p1

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    :cond_0
    return-void
.end method

.method public setOneState(Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)V
    .locals 1

    .line 88
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)V

    return-void
.end method

.method public setSuffix(I)V
    .locals 2

    .line 99
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->suffix:I

    .line 100
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    if-eqz v0, :cond_0

    .line 101
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->pos:I

    add-int/lit8 v1, v1, 0x8

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    :cond_0
    return-void
.end method

.method public setSuffix(Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;)V
    .locals 0

    .line 106
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setSuffix(I)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 424
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "PPMContext["

    .line 425
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  pos="

    .line 426
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 427
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->pos:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  size="

    .line 428
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 429
    sget v1, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->size:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  numStats="

    .line 430
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 431
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  Suffix="

    .line 432
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 433
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  freqData="

    .line 434
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 435
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\n  oneState="

    .line 436
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 437
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->oneState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 438
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 439
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public update1(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;I)V
    .locals 3

    .line 271
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v0

    invoke-virtual {v0, p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 272
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v0

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    .line 273
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    .line 274
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState3:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v0

    .line 275
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState4:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v1

    .line 276
    invoke-virtual {v0, p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    add-int/lit8 p2, p2, -0x6

    .line 277
    invoke-virtual {v1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 278
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result p2

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v2

    if-le p2, v2, :cond_0

    .line 279
    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->ppmdSwap(Lir/mahdi/mzip/rar/unpack/ppm/State;Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 280
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p2

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v0

    invoke-virtual {p2, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 281
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result p2

    const/16 v0, 0x7c

    if-le p2, v0, :cond_0

    .line 282
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->rescale(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)V

    :cond_0
    return-void
.end method

.method public update2(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;I)V
    .locals 2

    .line 337
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->tempState5:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v0

    .line 338
    invoke-virtual {v0, p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 339
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v1

    invoke-virtual {v1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 340
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p2

    const/4 v1, 0x4

    invoke-virtual {p2, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    .line 341
    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->freqData:Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    invoke-virtual {p2, v1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    .line 342
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result p2

    const/16 v0, 0x7c

    if-le p2, v0, :cond_0

    .line 343
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->rescale(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)V

    :cond_0
    const/4 p2, 0x1

    .line 345
    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->incEscCount(I)V

    .line 346
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getInitRL()I

    move-result p2

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setRunLength(I)V

    return-void
.end method
