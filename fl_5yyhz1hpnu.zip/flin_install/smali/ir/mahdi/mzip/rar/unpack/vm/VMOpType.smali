.class public final enum Lir/mahdi/mzip/rar/unpack/vm/VMOpType;
.super Ljava/lang/Enum;
.source "VMOpType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/vm/VMOpType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

.field public static final enum VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

.field public static final enum VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

.field public static final enum VM_OPREG:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

.field public static final enum VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;


# instance fields
.field private opType:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 21
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    const/4 v1, 0x0

    const-string v2, "VM_OPREG"

    invoke-direct {v0, v2, v1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREG:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    const/4 v2, 0x1

    const-string v3, "VM_OPINT"

    invoke-direct {v0, v3, v2, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    const/4 v3, 0x2

    const-string v4, "VM_OPREGMEM"

    invoke-direct {v0, v4, v3, v3}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    const/4 v4, 0x3

    const-string v5, "VM_OPNONE"

    invoke-direct {v0, v5, v4, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    const/4 v0, 0x4

    .line 20
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREG:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    aput-object v5, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    aput-object v1, v0, v4

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 28
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 29
    iput p3, p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->opType:I

    return-void
.end method

.method public static findOpType(I)Lir/mahdi/mzip/rar/unpack/vm/VMOpType;
    .locals 1

    .line 34
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREG:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 35
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREG:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object p0

    .line 39
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 40
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object p0

    .line 43
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 44
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object p0

    .line 47
    :cond_2
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->equals(I)Z

    move-result p0

    if-eqz p0, :cond_3

    .line 48
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object p0

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/vm/VMOpType;
    .locals 1

    .line 20
    const-class v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/vm/VMOpType;
    .locals 1

    .line 20
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object v0
.end method


# virtual methods
.method public equals(I)Z
    .locals 1

    .line 58
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->opType:I

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getOpType()I
    .locals 1

    .line 54
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->opType:I

    return v0
.end method
