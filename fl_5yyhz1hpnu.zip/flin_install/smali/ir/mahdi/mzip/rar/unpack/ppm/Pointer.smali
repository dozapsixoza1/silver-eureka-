.class public abstract Lir/mahdi/mzip/rar/unpack/ppm/Pointer;
.super Ljava/lang/Object;
.source "Pointer.java"


# static fields
.field static final synthetic $assertionsDisabled:Z


# instance fields
.field protected mem:[B

.field protected pos:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>([B)V
    .locals 0

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;->mem:[B

    return-void
.end method


# virtual methods
.method public getAddress()I
    .locals 1

    .line 30
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;->pos:I

    return v0
.end method

.method public setAddress(I)V
    .locals 0

    .line 36
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;->pos:I

    return-void
.end method
