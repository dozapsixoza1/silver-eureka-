.class public final enum Lir/mahdi/mzip/rar/unpack/decode/FilterType;
.super Ljava/lang/Enum;
.source "FilterType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/decode/FilterType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_AUDIO:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_DELTA:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_E8:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_E8E9:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_E8E9V2:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_ITANIUM:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_NONE:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_PPM:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_RGB:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

.field public static final enum FILTER_UPCASETOLOW:Lir/mahdi/mzip/rar/unpack/decode/FilterType;


# direct methods
.method static constructor <clinit>()V
    .locals 12

    .line 21
    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v1, 0x0

    const-string v2, "FILTER_NONE"

    invoke-direct {v0, v2, v1}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_NONE:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v2, 0x1

    const-string v3, "FILTER_PPM"

    invoke-direct {v0, v3, v2}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_PPM:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v3, 0x2

    const-string v4, "FILTER_E8"

    invoke-direct {v0, v4, v3}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_E8:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v4, 0x3

    const-string v5, "FILTER_E8E9"

    invoke-direct {v0, v5, v4}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_E8E9:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v5, 0x4

    const-string v6, "FILTER_UPCASETOLOW"

    invoke-direct {v0, v6, v5}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_UPCASETOLOW:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v6, 0x5

    const-string v7, "FILTER_AUDIO"

    invoke-direct {v0, v7, v6}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_AUDIO:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v7, 0x6

    const-string v8, "FILTER_RGB"

    invoke-direct {v0, v8, v7}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_RGB:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/4 v8, 0x7

    const-string v9, "FILTER_DELTA"

    invoke-direct {v0, v9, v8}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_DELTA:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/16 v9, 0x8

    const-string v10, "FILTER_ITANIUM"

    invoke-direct {v0, v10, v9}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_ITANIUM:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/16 v10, 0x9

    const-string v11, "FILTER_E8E9V2"

    invoke-direct {v0, v11, v10}, Lir/mahdi/mzip/rar/unpack/decode/FilterType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_E8E9V2:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    const/16 v0, 0xa

    .line 20
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    sget-object v11, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_NONE:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v11, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_PPM:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_E8:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_E8E9:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_UPCASETOLOW:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_AUDIO:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v6

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_RGB:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v7

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_DELTA:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v8

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_ITANIUM:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v9

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->FILTER_E8E9V2:Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    aput-object v1, v0, v10

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->$VALUES:[Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 20
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/decode/FilterType;
    .locals 1

    .line 20
    const-class v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/decode/FilterType;
    .locals 1

    .line 20
    sget-object v0, Lir/mahdi/mzip/rar/unpack/decode/FilterType;->$VALUES:[Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/decode/FilterType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/decode/FilterType;

    return-object v0
.end method
