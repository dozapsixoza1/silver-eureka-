.class public Lir/mahdi/mzip/rar/unpack/vm/RarVM;
.super Lir/mahdi/mzip/rar/unpack/vm/BitInput;
.source "RarVM.java"


# static fields
.field private static final UINT_MASK:J = -0x1L

.field public static final VM_FIXEDGLOBALSIZE:I = 0x40

.field public static final VM_GLOBALMEMADDR:I = 0x3c000

.field public static final VM_GLOBALMEMSIZE:I = 0x2000

.field public static final VM_MEMMASK:I = 0x3ffff

.field public static final VM_MEMSIZE:I = 0x40000

.field private static final regCount:I = 0x8


# instance fields
.field private IP:I

.field private R:[I

.field private codeSize:I

.field private flags:I

.field private maxOpCount:I

.field private mem:[B


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 55
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;-><init>()V

    const/16 v0, 0x8

    .line 45
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    const v0, 0x17d7840

    .line 49
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->maxOpCount:I

    const/4 v0, 0x0

    .line 56
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    return-void
.end method

.method private ExecuteCode(Ljava/util/List;I)Z
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;",
            ">;I)Z"
        }
    .end annotation

    move-object/from16 v0, p0

    const v1, 0x17d7840

    .line 252
    iput v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->maxOpCount:I

    move/from16 v1, p2

    .line 253
    iput v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->codeSize:I

    const/4 v1, 0x0

    .line 254
    iput v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IP:I

    .line 257
    :goto_0
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IP:I

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    .line 258
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    invoke-direct {v0, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getOperand(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;)I

    move-result v4

    .line 259
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp2()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v5

    invoke-direct {v0, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getOperand(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;)I

    move-result v5

    .line 260
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/RarVM$1;->$SwitchMap$ir$mahdi$mzip$rar$unpack$vm$VMCommands:[I

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v7

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->ordinal()I

    move-result v7

    aget v6, v6, v7

    const/16 v7, 0x8

    const-wide/16 v8, -0x2

    const v12, 0x3ffff

    const/4 v13, 0x7

    const-wide/16 v14, -0x1

    const/4 v10, 0x1

    packed-switch v6, :pswitch_data_0

    goto/16 :goto_1d

    .line 648
    :pswitch_0
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v2

    .line 649
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getData()I

    move-result v2

    .line 648
    invoke-static {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->findFilter(I)Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    move-result-object v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ExecuteStandardFilter(Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    goto/16 :goto_1d

    .line 640
    :pswitch_1
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v2, v13

    const/high16 v5, 0x40000

    if-lt v4, v5, :cond_0

    return v10

    .line 643
    :cond_0
    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    aget v2, v2, v13

    and-int/2addr v2, v12

    invoke-direct {v0, v1, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    .line 644
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v2, v13

    add-int/lit8 v4, v4, 0x4

    aput v4, v2, v13

    goto :goto_0

    .line 624
    :pswitch_2
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 625
    iget v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    and-int/2addr v7, v8

    int-to-long v8, v6

    .line 627
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v11

    iget-object v12, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v11, v12, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v11, v5

    sub-long v11, v14, v11

    and-long/2addr v8, v11

    int-to-long v11, v7

    sub-long v11, v14, v11

    and-long/2addr v8, v11

    and-long/2addr v8, v14

    long-to-int v5, v8

    .line 629
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v8

    if-eqz v8, :cond_1

    and-int/lit16 v5, v5, 0xff

    :cond_1
    if-gt v5, v6, :cond_4

    if-ne v5, v6, :cond_2

    if-eqz v7, :cond_2

    goto :goto_2

    :cond_2
    if-nez v5, :cond_3

    .line 632
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 633
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_1

    :cond_3
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 634
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    :goto_1
    or-int/2addr v6, v1

    goto :goto_3

    :cond_4
    :goto_2
    const/4 v6, 0x1

    :goto_3
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 635
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 608
    :pswitch_3
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 609
    iget v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    and-int/2addr v7, v8

    int-to-long v8, v6

    .line 611
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v11

    iget-object v12, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v11, v12, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v11, v5

    add-long/2addr v11, v14

    and-long/2addr v8, v11

    int-to-long v11, v7

    add-long/2addr v11, v14

    and-long/2addr v8, v11

    and-long/2addr v8, v14

    long-to-int v5, v8

    .line 613
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v8

    if-eqz v8, :cond_5

    and-int/lit16 v5, v5, 0xff

    :cond_5
    if-lt v5, v6, :cond_8

    if-ne v5, v6, :cond_6

    if-eqz v7, :cond_6

    goto :goto_5

    :cond_6
    if-nez v5, :cond_7

    .line 617
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 618
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_4

    :cond_7
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 619
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    :goto_4
    or-int/2addr v6, v1

    goto :goto_6

    :cond_8
    :goto_5
    const/4 v6, 0x1

    :goto_6
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 620
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 600
    :pswitch_4
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    if-eqz v5, :cond_24

    .line 602
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    div-int/2addr v6, v5

    .line 603
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v5, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 593
    :pswitch_5
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v6, v6

    .line 595
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v8

    iget-object v9, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v8, v9, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v8, v5

    mul-long v8, v8, v14

    and-long/2addr v6, v8

    and-long/2addr v6, v14

    and-long/2addr v6, v14

    long-to-int v5, v6

    .line 596
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 586
    :pswitch_6
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 587
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v9

    iget-object v11, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v9, v11, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v9

    invoke-direct {v0, v7, v8, v4, v9}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    .line 589
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v4, v5, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 583
    :pswitch_7
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v10, v2, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-byte v5, v5

    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 580
    :pswitch_8
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v10, v2, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 576
    :pswitch_9
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v4, v13

    and-int/2addr v4, v12

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 577
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v2, v13

    add-int/lit8 v4, v4, 0x4

    aput v4, v2, v13

    goto/16 :goto_1d

    .line 572
    :pswitch_a
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v2, v13

    add-int/lit8 v4, v4, -0x4

    aput v4, v2, v13

    .line 573
    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    aget v2, v2, v13

    and-int/2addr v2, v12

    iget v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    invoke-direct {v0, v1, v4, v2, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 567
    :pswitch_b
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v2, v2, v13

    move v4, v2

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v7, :cond_24

    .line 568
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    rsub-int/lit8 v6, v2, 0x7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    and-int v9, v4, v12

    invoke-direct {v0, v1, v8, v9}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v8

    aput v8, v5, v6

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v4, v4, 0x4

    goto :goto_7

    .line 560
    :pswitch_c
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v2, v2, v13

    add-int/lit8 v2, v2, -0x4

    move v4, v2

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v7, :cond_9

    .line 561
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    and-int v6, v4, v12

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v8, v8, v2

    invoke-direct {v0, v1, v5, v6, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v4, v4, -0x4

    goto :goto_8

    .line 563
    :cond_9
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v2, v13

    add-int/lit8 v4, v4, -0x20

    aput v4, v2, v13

    goto/16 :goto_1d

    .line 557
    :pswitch_d
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    neg-int v5, v5

    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 554
    :pswitch_e
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v10, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    neg-int v5, v5

    invoke-direct {v0, v10, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 545
    :pswitch_f
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v5

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v5, v6, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    neg-int v5, v5

    if-nez v5, :cond_a

    .line 546
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_9

    :cond_a
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 547
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    sget-object v7, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 548
    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v7

    and-int/2addr v7, v5

    or-int/2addr v6, v7

    :goto_9
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 549
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 535
    :pswitch_10
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 536
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v7, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    shr-int v7, v6, v5

    if-nez v7, :cond_b

    .line 538
    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    goto :goto_a

    :cond_b
    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 539
    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    and-int/2addr v8, v7

    :goto_a
    add-int/lit8 v5, v5, -0x1

    shr-int v5, v6, v5

    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 540
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v5, v6

    or-int/2addr v5, v8

    iput v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 541
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v5, v4, v7}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 525
    :pswitch_11
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 526
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v7, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    ushr-int v7, v6, v5

    if-nez v7, :cond_c

    .line 528
    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    goto :goto_b

    :cond_c
    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 529
    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    and-int/2addr v8, v7

    :goto_b
    add-int/lit8 v5, v5, -0x1

    ushr-int v5, v6, v5

    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 530
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v5, v6

    or-int/2addr v5, v8

    iput v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 531
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v5, v4, v7}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 513
    :pswitch_12
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 514
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v7, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    shl-int v7, v6, v5

    if-nez v7, :cond_d

    .line 516
    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    goto :goto_c

    :cond_d
    sget-object v8, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 517
    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v8

    and-int/2addr v8, v7

    :goto_c
    add-int/lit8 v5, v5, -0x1

    shl-int v5, v6, v5

    const/high16 v6, -0x80000000

    and-int/2addr v5, v6

    if-eqz v5, :cond_e

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 519
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    goto :goto_d

    :cond_e
    const/4 v5, 0x0

    :goto_d
    or-int/2addr v5, v8

    iput v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 521
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v5, v4, v7}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 509
    :pswitch_13
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v5

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 510
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 509
    invoke-direct {v0, v2, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    xor-int/lit8 v2, v2, -0x1

    invoke-direct {v0, v5, v6, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 504
    :pswitch_14
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v5, v2, v13

    add-int/lit8 v5, v5, -0x4

    aput v5, v2, v13

    .line 505
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    aget v2, v2, v13

    and-int/2addr v2, v12

    iget v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IP:I

    add-int/2addr v6, v10

    invoke-direct {v0, v1, v5, v2, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    .line 506
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 499
    :pswitch_15
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v5, v5, v13

    and-int/2addr v5, v12

    invoke-direct {v0, v1, v2, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    .line 501
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v4, v2, v13

    add-int/lit8 v4, v4, 0x4

    aput v4, v2, v13

    goto/16 :goto_1d

    .line 494
    :pswitch_16
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v5, v2, v13

    add-int/lit8 v5, v5, -0x4

    aput v5, v2, v13

    .line 495
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    aget v2, v2, v13

    and-int/2addr v2, v12

    invoke-direct {v0, v1, v5, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v4

    invoke-direct {v0, v1, v5, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 488
    :pswitch_17
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    and-int/2addr v2, v5

    if-nez v2, :cond_24

    .line 489
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 482
    :pswitch_18
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    or-int/2addr v5, v6

    and-int/2addr v2, v5

    if-nez v2, :cond_24

    .line 483
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 476
    :pswitch_19
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    or-int/2addr v5, v6

    and-int/2addr v2, v5

    if-eqz v2, :cond_24

    .line 477
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 470
    :pswitch_1a
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    and-int/2addr v2, v5

    if-eqz v2, :cond_24

    .line 471
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 464
    :pswitch_1b
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    and-int/2addr v2, v5

    if-nez v2, :cond_24

    .line 465
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 458
    :pswitch_1c
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    and-int/2addr v2, v5

    if-eqz v2, :cond_24

    .line 459
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 451
    :pswitch_1d
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v4

    .line 452
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    and-int/2addr v2, v4

    if-nez v2, :cond_f

    .line 453
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    goto :goto_e

    :cond_f
    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 454
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v4

    and-int/2addr v2, v4

    :goto_e
    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto/16 :goto_1d

    .line 443
    :pswitch_1e
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 444
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v7, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    or-int/2addr v5, v6

    if-nez v5, :cond_10

    .line 445
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_f

    :cond_10
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 446
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    :goto_f
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 447
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 435
    :pswitch_1f
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 436
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v7, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    and-int/2addr v5, v6

    if-nez v5, :cond_11

    .line 437
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_10

    :cond_11
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 438
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    :goto_10
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 439
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 427
    :pswitch_20
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    .line 428
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v7, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    xor-int/2addr v5, v6

    if-nez v5, :cond_12

    .line 429
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_11

    :cond_12
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 430
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    :goto_11
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 431
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 424
    :pswitch_21
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 419
    :pswitch_22
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v5, v5

    and-long/2addr v5, v8

    long-to-int v6, v5

    invoke-direct {v0, v1, v2, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 412
    :pswitch_23
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 416
    invoke-direct {v0, v10, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v5, v5

    and-long/2addr v5, v8

    long-to-int v6, v5

    .line 412
    invoke-direct {v0, v10, v2, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 404
    :pswitch_24
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v5

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v5, v6, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v5, v5

    and-long/2addr v5, v8

    long-to-int v6, v5

    .line 405
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v5, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    if-nez v6, :cond_13

    .line 406
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    goto :goto_12

    :cond_13
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 407
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    and-int/2addr v2, v6

    :goto_12
    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto/16 :goto_1d

    .line 399
    :pswitch_25
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v5, v5

    const-wide/16 v7, 0x0

    and-long/2addr v5, v7

    long-to-int v6, v5

    invoke-direct {v0, v1, v2, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    :pswitch_26
    const-wide/16 v7, 0x0

    .line 392
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 396
    invoke-direct {v0, v10, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v5, v5

    and-long/2addr v5, v7

    long-to-int v6, v5

    .line 392
    invoke-direct {v0, v10, v2, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    :pswitch_27
    const-wide/16 v7, 0x0

    .line 380
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v5

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v5, v6, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v5, v5

    and-long/2addr v5, v7

    long-to-int v6, v5

    .line 381
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v5

    if-eqz v5, :cond_14

    and-int/lit16 v6, v6, 0xff

    .line 385
    :cond_14
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v5, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    if-nez v6, :cond_15

    .line 386
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    goto :goto_13

    :cond_15
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 387
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    and-int/2addr v2, v6

    :goto_13
    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto/16 :goto_1d

    .line 374
    :pswitch_28
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    and-int/2addr v2, v5

    if-nez v2, :cond_24

    .line 375
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 368
    :pswitch_29
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v5

    and-int/2addr v2, v5

    if-eqz v2, :cond_24

    .line 369
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setIP(I)Z

    goto/16 :goto_0

    .line 359
    :pswitch_2a
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 363
    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v6, v6

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 364
    invoke-direct {v0, v1, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v8, v5

    sub-long v8, v14, v8

    and-long/2addr v6, v8

    and-long/2addr v6, v14

    long-to-int v5, v6

    .line 359
    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 354
    :pswitch_2b
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 355
    invoke-direct {v0, v10, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v6, v6

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 356
    invoke-direct {v0, v10, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v8, v5

    sub-long v8, v14, v8

    and-long/2addr v6, v8

    and-long/2addr v6, v14

    long-to-int v5, v6

    .line 354
    invoke-direct {v0, v10, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 343
    :pswitch_2c
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v7, v6

    .line 345
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v9

    iget-object v11, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v9, v11, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v11, v5

    sub-long v11, v14, v11

    and-long/2addr v7, v11

    and-long/2addr v7, v14

    long-to-int v5, v7

    if-nez v5, :cond_16

    .line 346
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_14

    :cond_16
    if-le v5, v6, :cond_17

    const/4 v6, 0x1

    goto :goto_14

    :cond_17
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 348
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    or-int/2addr v6, v1

    :goto_14
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 349
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 334
    :pswitch_2d
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 338
    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v6, v6

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 339
    invoke-direct {v0, v1, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v8, v5

    add-long/2addr v8, v14

    and-long/2addr v6, v8

    and-long/2addr v6, v14

    long-to-int v5, v6

    .line 334
    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 329
    :pswitch_2e
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 330
    invoke-direct {v0, v10, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v6, v6

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 331
    invoke-direct {v0, v10, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v8, v5

    add-long/2addr v8, v14

    and-long/2addr v6, v8

    and-long/2addr v6, v14

    long-to-int v5, v6

    .line 329
    invoke-direct {v0, v10, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 309
    :pswitch_2f
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v7, v6

    .line 311
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v9

    iget-object v11, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    .line 310
    invoke-direct {v0, v9, v11, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    int-to-long v11, v5

    add-long/2addr v7, v11

    and-long/2addr v7, v14

    long-to-int v5, v7

    .line 312
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v7

    if-eqz v7, :cond_1b

    and-int/lit16 v5, v5, 0xff

    if-ge v5, v6, :cond_18

    const/4 v6, 0x1

    goto :goto_16

    :cond_18
    if-nez v5, :cond_19

    .line 314
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 315
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_15

    :cond_19
    and-int/lit16 v6, v5, 0x80

    if-eqz v6, :cond_1a

    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 317
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_15

    :cond_1a
    const/4 v6, 0x0

    :goto_15
    or-int/2addr v6, v1

    :goto_16
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto :goto_19

    :cond_1b
    if-ge v5, v6, :cond_1c

    const/4 v6, 0x1

    goto :goto_18

    :cond_1c
    if-nez v5, :cond_1d

    .line 321
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 322
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    goto :goto_17

    :cond_1d
    sget-object v6, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 323
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v6

    and-int/2addr v6, v5

    :goto_17
    or-int/2addr v6, v1

    :goto_18
    iput v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 324
    :goto_19
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_1d

    .line 297
    :pswitch_30
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    .line 298
    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v4

    sub-int v4, v2, v4

    if-nez v4, :cond_1e

    .line 300
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto/16 :goto_1d

    :cond_1e
    if-le v4, v2, :cond_1f

    const/4 v2, 0x1

    goto :goto_1a

    .line 302
    :cond_1f
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 303
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    and-int/2addr v2, v4

    or-int/2addr v2, v1

    :goto_1a
    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto/16 :goto_1d

    .line 286
    :pswitch_31
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v10, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    .line 287
    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v10, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v4

    sub-int v4, v2, v4

    if-nez v4, :cond_20

    .line 289
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto :goto_1d

    :cond_20
    if-le v4, v2, :cond_21

    const/4 v2, 0x1

    goto :goto_1b

    .line 291
    :cond_21
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 292
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    and-int/2addr v2, v4

    or-int/2addr v2, v1

    :goto_1b
    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto :goto_1d

    .line 273
    :pswitch_32
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v6, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v4

    .line 274
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v6, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    sub-int v2, v4, v2

    if-nez v2, :cond_22

    .line 277
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v2

    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto :goto_1d

    :cond_22
    if-le v2, v4, :cond_23

    const/4 v2, 0x1

    goto :goto_1c

    .line 279
    :cond_23
    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 280
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->getFlag()I

    move-result v4

    and-int/2addr v2, v4

    or-int/2addr v2, v1

    :goto_1c
    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    goto :goto_1d

    .line 269
    :pswitch_33
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v1, v2, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    invoke-direct {v0, v1, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto :goto_1d

    .line 266
    :pswitch_34
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v10, v2, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v5

    invoke-direct {v0, v10, v2, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto :goto_1d

    .line 262
    :pswitch_35
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v2, v8, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v2

    invoke-direct {v0, v6, v7, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    .line 654
    :cond_24
    :goto_1d
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IP:I

    add-int/2addr v2, v10

    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IP:I

    .line 655
    iget v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->maxOpCount:I

    sub-int/2addr v2, v10

    iput v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->maxOpCount:I

    goto/16 :goto_0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_35
        :pswitch_34
        :pswitch_33
        :pswitch_32
        :pswitch_31
        :pswitch_30
        :pswitch_2f
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private ExecuteStandardFilter(Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V
    .locals 35

    move-object/from16 v0, p0

    .line 911
    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/RarVM$1;->$SwitchMap$ir$mahdi$mzip$rar$unpack$vm$VMStandardFilters:[I

    invoke-virtual/range {p1 .. p1}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->ordinal()I

    move-result v2

    aget v1, v1, v2

    const v6, 0x1e000

    const v7, 0x3c020

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v13, 0x4

    const/4 v15, 0x0

    packed-switch v1, :pswitch_data_0

    goto/16 :goto_14

    .line 1133
    :pswitch_0
    iget-object v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v1, v1, v13

    if-lt v1, v6, :cond_0

    goto/16 :goto_14

    :cond_0
    move v3, v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_3

    .line 1138
    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v5, v2, 0x1

    aget-byte v2, v4, v2

    if-ne v2, v9, :cond_1

    add-int/lit8 v2, v5, 0x1

    .line 1139
    aget-byte v4, v4, v5

    if-eq v4, v9, :cond_2

    add-int/lit8 v4, v4, -0x20

    int-to-byte v4, v4

    goto :goto_1

    :cond_1
    move v4, v2

    move v2, v5

    .line 1142
    :cond_2
    :goto_1
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v6, v3, 0x1

    aput-byte v4, v5, v3

    move v3, v6

    goto :goto_0

    .line 1144
    :cond_3
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    const v4, 0x3c01c

    sub-int/2addr v3, v1

    invoke-direct {v0, v15, v2, v4, v3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    .line 1145
    iget-object v2, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v15, v2, v7, v1}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    goto/16 :goto_14

    .line 1057
    :pswitch_1
    iget-object v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    aget v8, v1, v13

    aget v1, v1, v15

    .line 1061
    iget-object v11, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v15, v11, v7, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    if-lt v8, v6, :cond_4

    goto/16 :goto_14

    :cond_4
    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_2
    if-ge v6, v1, :cond_9

    const/4 v11, 0x7

    .line 1068
    new-array v11, v11, [J

    move/from16 v24, v7

    const-wide/16 v2, 0x0

    const/4 v9, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v21, 0x0

    const-wide/16 v22, 0x0

    const/16 v25, 0x0

    move v7, v6

    :goto_3
    if-ge v7, v8, :cond_8

    long-to-int v3, v2

    sub-int v2, v3, v21

    const-wide/16 v26, 0x8

    mul-long v26, v26, v22

    mul-int v15, v13, v3

    int-to-long v4, v15

    add-long v26, v26, v4

    mul-int v4, v9, v2

    int-to-long v4, v4

    add-long v26, v26, v4

    mul-int v4, v14, v12

    int-to-long v4, v4

    add-long v26, v26, v4

    ushr-long v4, v26, v10

    const-wide/16 v26, 0xff

    and-long v4, v4, v26

    .line 1080
    iget-object v15, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v26, v24, 0x1

    aget-byte v10, v15, v24

    and-int/lit16 v10, v10, 0xff

    move/from16 p1, v1

    int-to-long v0, v10

    sub-long/2addr v4, v0

    const-wide/16 v28, -0x1

    and-long v4, v4, v28

    add-int v10, v8, v7

    move/from16 v28, v8

    long-to-int v8, v4

    int-to-byte v8, v8

    .line 1083
    aput-byte v8, v15, v10

    move v8, v6

    move v10, v7

    sub-long v6, v4, v22

    long-to-int v7, v6

    int-to-byte v6, v7

    int-to-long v6, v6

    long-to-int v1, v0

    int-to-byte v0, v1

    const/4 v1, 0x3

    shl-int/2addr v0, v1

    const/4 v1, 0x0

    .line 1089
    aget-wide v21, v11, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v15

    move-wide/from16 v29, v4

    int-to-long v4, v15

    add-long v21, v21, v4

    aput-wide v21, v11, v1

    const/4 v1, 0x1

    .line 1090
    aget-wide v4, v11, v1

    sub-int v15, v0, v3

    invoke-static {v15}, Ljava/lang/Math;->abs(I)I

    move-result v15

    move-wide/from16 v22, v6

    int-to-long v6, v15

    add-long/2addr v4, v6

    aput-wide v4, v11, v1

    const/4 v1, 0x2

    .line 1091
    aget-wide v4, v11, v1

    add-int v6, v0, v3

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    int-to-long v6, v6

    add-long/2addr v4, v6

    aput-wide v4, v11, v1

    const/4 v1, 0x3

    .line 1092
    aget-wide v4, v11, v1

    sub-int v6, v0, v2

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    int-to-long v6, v6

    add-long/2addr v4, v6

    aput-wide v4, v11, v1

    const/4 v1, 0x4

    .line 1093
    aget-wide v4, v11, v1

    add-int v6, v0, v2

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    int-to-long v6, v6

    add-long/2addr v4, v6

    aput-wide v4, v11, v1

    const/4 v1, 0x5

    .line 1094
    aget-wide v4, v11, v1

    sub-int v6, v0, v12

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    int-to-long v6, v6

    add-long/2addr v4, v6

    aput-wide v4, v11, v1

    const/4 v1, 0x6

    .line 1095
    aget-wide v4, v11, v1

    add-int/2addr v0, v12

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-long v6, v0

    add-long/2addr v4, v6

    aput-wide v4, v11, v1

    and-int/lit8 v0, v25, 0x1f

    if-nez v0, :cond_7

    const/4 v0, 0x0

    .line 1098
    aget-wide v4, v11, v0

    const-wide/16 v17, 0x0

    aput-wide v17, v11, v0

    move-wide v6, v4

    move-wide/from16 v4, v17

    const/4 v0, 0x1

    .line 1100
    :goto_4
    array-length v1, v11

    if-ge v0, v1, :cond_6

    .line 1101
    aget-wide v31, v11, v0

    cmp-long v1, v31, v6

    if-gez v1, :cond_5

    .line 1102
    aget-wide v4, v11, v0

    int-to-long v6, v0

    move-wide/from16 v33, v4

    move-wide v4, v6

    move-wide/from16 v6, v33

    .line 1105
    :cond_5
    aput-wide v17, v11, v0

    add-int/lit8 v0, v0, 0x1

    const-wide/16 v17, 0x0

    goto :goto_4

    :cond_6
    long-to-int v0, v4

    packed-switch v0, :pswitch_data_1

    goto :goto_5

    :pswitch_2
    const/16 v0, 0x10

    if-ge v14, v0, :cond_7

    add-int/lit8 v14, v14, 0x1

    goto :goto_5

    :pswitch_3
    const/16 v0, 0x10

    const/16 v1, -0x10

    if-lt v14, v1, :cond_7

    add-int/lit8 v14, v14, -0x1

    goto :goto_5

    :pswitch_4
    const/16 v0, 0x10

    if-ge v9, v0, :cond_7

    add-int/lit8 v9, v9, 0x1

    goto :goto_5

    :pswitch_5
    const/16 v0, 0x10

    const/16 v1, -0x10

    if-lt v9, v1, :cond_7

    add-int/lit8 v9, v9, -0x1

    goto :goto_5

    :pswitch_6
    const/16 v0, 0x10

    if-ge v13, v0, :cond_7

    add-int/lit8 v13, v13, 0x1

    goto :goto_5

    :pswitch_7
    const/16 v0, -0x10

    if-lt v13, v0, :cond_7

    add-int/lit8 v13, v13, -0x1

    :cond_7
    :goto_5
    add-int v7, v10, p1

    add-int/lit8 v25, v25, 0x1

    move-object/from16 v0, p0

    move/from16 v1, p1

    move v12, v2

    move/from16 v21, v3

    move v6, v8

    move-wide/from16 v2, v22

    move/from16 v24, v26

    move/from16 v8, v28

    move-wide/from16 v22, v29

    const/4 v10, 0x3

    const/4 v15, 0x0

    goto/16 :goto_3

    :cond_8
    move/from16 p1, v1

    move/from16 v28, v8

    move v8, v6

    add-int/lit8 v6, v8, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v13, 0x4

    const/4 v15, 0x0

    move-object/from16 v0, p0

    move/from16 v7, v24

    move/from16 v8, v28

    goto/16 :goto_2

    :cond_9
    move-object/from16 v0, p0

    goto/16 :goto_14

    .line 1009
    :pswitch_8
    iget-object v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    const/4 v2, 0x4

    aget v2, v1, v2

    const/4 v3, 0x0

    aget v4, v1, v3

    const/4 v5, 0x3

    sub-int/2addr v4, v5

    const/4 v8, 0x1

    aget v1, v1, v8

    .line 1013
    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v3, v8, v7, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    if-ge v2, v6, :cond_1e

    if-gez v1, :cond_a

    goto/16 :goto_14

    :cond_a
    const/4 v3, 0x0

    const/16 v21, 0x0

    :goto_6
    if-ge v3, v5, :cond_f

    move v6, v3

    const-wide/16 v7, 0x0

    :goto_7
    if-ge v6, v2, :cond_e

    sub-int v9, v6, v4

    if-lt v9, v5, :cond_d

    add-int/2addr v9, v2

    .line 1025
    iget-object v10, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    aget-byte v11, v10, v9

    and-int/lit16 v11, v11, 0xff

    sub-int/2addr v9, v5

    .line 1026
    aget-byte v9, v10, v9

    and-int/lit16 v9, v9, 0xff

    int-to-long v10, v11

    add-long v12, v7, v10

    int-to-long v14, v9

    sub-long/2addr v12, v14

    move v9, v6

    sub-long v5, v12, v7

    long-to-int v6, v5

    .line 1028
    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v5

    move-wide/from16 v19, v7

    sub-long v6, v12, v10

    long-to-int v7, v6

    .line 1029
    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v6

    sub-long/2addr v12, v14

    long-to-int v7, v12

    .line 1030
    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v7

    if-gt v5, v6, :cond_b

    if-gt v5, v7, :cond_b

    move-wide/from16 v7, v19

    goto :goto_8

    :cond_b
    if-gt v6, v7, :cond_c

    move-wide v7, v10

    goto :goto_8

    :cond_c
    move-wide v7, v14

    goto :goto_8

    :cond_d
    move v9, v6

    :goto_8
    move-wide/from16 v19, v7

    .line 1044
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v6, v21, 0x1

    aget-byte v7, v5, v21

    int-to-long v7, v7

    sub-long v19, v19, v7

    const-wide/16 v7, 0xff

    and-long v10, v19, v7

    and-long/2addr v10, v7

    add-int v12, v2, v9

    and-long v13, v10, v7

    long-to-int v14, v13

    int-to-byte v13, v14

    .line 1045
    aput-byte v13, v5, v12

    add-int/lit8 v5, v9, 0x3

    move/from16 v21, v6

    move-wide v7, v10

    move v6, v5

    const/4 v5, 0x3

    goto :goto_7

    :cond_e
    const-wide/16 v7, 0xff

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x3

    goto :goto_6

    :cond_f
    add-int/lit8 v3, v2, -0x2

    :goto_9
    if-ge v1, v3, :cond_1e

    .line 1050
    iget-object v4, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int v5, v2, v1

    add-int/lit8 v6, v5, 0x1

    aget-byte v6, v4, v6

    .line 1051
    aget-byte v7, v4, v5

    add-int/2addr v7, v6

    int-to-byte v7, v7

    aput-byte v7, v4, v5

    const/4 v7, 0x2

    add-int/2addr v5, v7

    .line 1052
    aget-byte v7, v4, v5

    add-int/2addr v7, v6

    int-to-byte v6, v7

    aput-byte v6, v4, v5

    add-int/lit8 v1, v1, 0x3

    goto :goto_9

    .line 987
    :pswitch_9
    iget-object v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    const/4 v2, 0x4

    aget v2, v1, v2

    and-int/lit8 v2, v2, -0x1

    const/4 v3, 0x0

    .line 988
    aget v1, v1, v3

    and-int/lit8 v1, v1, -0x1

    mul-int/lit8 v4, v2, 0x2

    and-int/lit8 v4, v4, -0x1

    .line 991
    iget-object v5, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-direct {v0, v3, v5, v7, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    if-lt v2, v6, :cond_10

    goto/16 :goto_14

    :cond_10
    const/4 v3, 0x0

    const/4 v5, 0x0

    :goto_a
    if-ge v3, v1, :cond_1e

    add-int v6, v2, v3

    move v7, v5

    const/4 v5, 0x0

    :goto_b
    if-ge v6, v4, :cond_11

    .line 1001
    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v9, v7, 0x1

    aget-byte v7, v8, v7

    sub-int/2addr v5, v7

    int-to-byte v5, v5

    aput-byte v5, v8, v6

    add-int/2addr v6, v1

    move v7, v9

    goto :goto_b

    :cond_11
    add-int/lit8 v3, v3, 0x1

    move v5, v7

    goto :goto_a

    .line 955
    :pswitch_a
    iget-object v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    const/4 v2, 0x4

    aget v3, v1, v2

    const/4 v4, 0x6

    .line 956
    aget v1, v1, v4

    and-int/lit8 v1, v1, -0x1

    int-to-long v4, v1

    const v1, 0x3c000

    if-lt v3, v1, :cond_12

    goto/16 :goto_14

    :cond_12
    const/16 v1, 0x10

    .line 962
    new-array v6, v1, [B

    fill-array-data v6, :array_0

    ushr-long/2addr v4, v2

    const/4 v2, 0x0

    :goto_c
    add-int/lit8 v7, v3, -0x15

    if-ge v2, v7, :cond_1e

    .line 966
    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    aget-byte v7, v7, v2

    and-int/lit8 v7, v7, 0x1f

    sub-int/2addr v7, v1

    if-ltz v7, :cond_15

    .line 969
    aget-byte v7, v6, v7

    if-eqz v7, :cond_15

    const/4 v8, 0x0

    const/4 v9, 0x2

    :goto_d
    if-gt v8, v9, :cond_16

    const/4 v10, 0x1

    shl-int v11, v10, v8

    and-int/2addr v11, v7

    if-eqz v11, :cond_13

    mul-int/lit8 v11, v8, 0x29

    const/4 v12, 0x5

    add-int/2addr v11, v12

    add-int/lit8 v13, v11, 0x25

    const/4 v14, 0x4

    .line 974
    invoke-direct {v0, v2, v13, v14}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->filterItanium_GetBits(III)I

    move-result v13

    if-ne v13, v12, :cond_14

    add-int/lit8 v11, v11, 0xd

    const/16 v13, 0x14

    .line 976
    invoke-direct {v0, v2, v11, v13}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->filterItanium_GetBits(III)I

    move-result v13

    int-to-long v13, v13

    sub-long/2addr v13, v4

    long-to-int v14, v13

    const v13, 0xfffff

    and-int/2addr v13, v14

    const/16 v14, 0x14

    .line 977
    invoke-direct {v0, v2, v13, v11, v14}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->filterItanium_SetBits(IIII)V

    goto :goto_e

    :cond_13
    const/4 v12, 0x5

    :cond_14
    :goto_e
    add-int/lit8 v8, v8, 0x1

    goto :goto_d

    :cond_15
    const/4 v9, 0x2

    :cond_16
    const/4 v10, 0x1

    const/4 v12, 0x5

    add-int/lit8 v2, v2, 0x10

    const-wide/16 v7, 0x1

    add-long/2addr v4, v7

    goto :goto_c

    .line 914
    :pswitch_b
    iget-object v1, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    const/4 v2, 0x4

    aget v3, v1, v2

    const/4 v2, 0x6

    .line 915
    aget v1, v1, v2

    and-int/lit8 v1, v1, -0x1

    int-to-long v1, v1

    const v4, 0x3c000

    if-lt v3, v4, :cond_17

    goto :goto_14

    :cond_17
    const/high16 v4, 0x1000000

    .line 921
    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    move-object/from16 v6, p1

    if-ne v6, v5, :cond_18

    const/16 v5, 0xe9

    goto :goto_f

    :cond_18
    const/16 v5, 0xe8

    :goto_f
    int-to-byte v5, v5

    const/4 v6, 0x0

    :goto_10
    const/4 v7, 0x4

    add-int/lit8 v8, v3, -0x4

    if-ge v6, v8, :cond_1e

    .line 923
    iget-object v8, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v9, v6, 0x1

    aget-byte v6, v8, v6

    const/16 v8, 0xe8

    if-eq v6, v8, :cond_1a

    if-ne v6, v5, :cond_19

    goto :goto_11

    :cond_19
    const/4 v6, 0x0

    const-wide/16 v16, 0x0

    goto :goto_13

    :cond_1a
    :goto_11
    int-to-long v10, v9

    add-long/2addr v10, v1

    .line 938
    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    const/4 v8, 0x0

    invoke-direct {v0, v8, v6, v9}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v6

    int-to-long v12, v6

    const-wide/32 v14, -0x80000000

    and-long v19, v12, v14

    const-wide/16 v16, 0x0

    cmp-long v6, v19, v16

    if-eqz v6, :cond_1c

    add-long/2addr v10, v12

    and-long/2addr v10, v14

    cmp-long v6, v10, v16

    if-nez v6, :cond_1b

    .line 941
    iget-object v6, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    long-to-int v8, v12

    add-int/2addr v8, v4

    const/4 v10, 0x0

    invoke-direct {v0, v10, v6, v9, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    :cond_1b
    const/4 v6, 0x0

    goto :goto_12

    :cond_1c
    const/4 v6, 0x0

    int-to-long v7, v4

    sub-long v7, v12, v7

    and-long/2addr v7, v14

    cmp-long v14, v7, v16

    if-eqz v14, :cond_1d

    .line 944
    iget-object v7, v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    sub-long/2addr v12, v10

    long-to-int v8, v12

    invoke-direct {v0, v6, v7, v9, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setValue(Z[BII)V

    :cond_1d
    :goto_12
    add-int/lit8 v9, v9, 0x4

    :goto_13
    move v6, v9

    goto :goto_10

    :cond_1e
    :goto_14
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_b
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
    .end packed-switch

    :array_0
    .array-data 1
        0x4t
        0x4t
        0x6t
        0x6t
        0x0t
        0x0t
        0x7t
        0x7t
        0x4t
        0x4t
        0x0t
        0x0t
        0x4t
        0x4t
        0x0t
        0x0t
    .end array-data
.end method

.method private IsStandardFilter([BI)Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;
    .locals 5

    const/4 p2, 0x7

    .line 891
    new-array p2, p2, [Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v2, 0x35

    const v3, -0x52a89779

    invoke-direct {v0, v2, v3, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v1, 0x0

    aput-object v0, p2, v1

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v3, 0x39

    const v4, 0x3cd7e57e

    invoke-direct {v0, v3, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v2, 0x1

    aput-object v0, p2, v2

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_ITANIUM:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v3, 0x78

    const v4, 0x3769893f

    invoke-direct {v0, v3, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v2, 0x2

    aput-object v0, p2, v2

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_DELTA:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v3, 0x1d

    const v4, 0xe06077d

    invoke-direct {v0, v3, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v2, 0x3

    aput-object v0, p2, v2

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_RGB:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v3, 0x95

    const v4, 0x1c2c5dc8

    invoke-direct {v0, v3, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v2, 0x4

    aput-object v0, p2, v2

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_AUDIO:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v3, 0xd8

    const v4, -0x437a18ff

    invoke-direct {v0, v3, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v2, 0x5

    aput-object v0, p2, v2

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_UPCASE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v3, 0x28

    const v4, 0x46b9c560    # 23778.688f

    invoke-direct {v0, v3, v4, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;-><init>(IILir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;)V

    const/4 v2, 0x6

    aput-object v0, p2, v2

    .line 900
    array-length v0, p1

    const/4 v2, -0x1

    invoke-static {v2, p1, v1, v0}, Lir/mahdi/mzip/rar/crc/RarCRC;->checkCrc(I[BII)I

    move-result v0

    xor-int/2addr v0, v2

    .line 901
    :goto_0
    array-length v2, p2

    if-ge v1, v2, :cond_1

    .line 902
    aget-object v2, p2, v1

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->getCRC()I

    move-result v2

    if-ne v2, v0, :cond_0

    aget-object v2, p2, v1

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->getLength()I

    move-result v2

    array-length v3, p1

    if-ne v2, v3, :cond_0

    .line 903
    aget-object p1, p2, v1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilterSignature;->getType()Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    move-result-object p1

    return-object p1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 907
    :cond_1
    sget-object p1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p1
.end method

.method public static ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I
    .locals 6

    .line 60
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result v0

    const v1, 0xc000

    and-int/2addr v1, v0

    const/16 v2, 0xa

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/16 v4, 0x4000

    const/4 v5, 0x2

    if-eq v1, v4, :cond_1

    const v0, 0x8000

    const/16 v2, 0x10

    if-eq v1, v0, :cond_0

    .line 80
    invoke-virtual {p0, v5}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    .line 81
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result v0

    shl-int/2addr v0, v2

    .line 82
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    .line 83
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result v1

    or-int/2addr v0, v1

    .line 84
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    return v0

    .line 75
    :cond_0
    invoke-virtual {p0, v5}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    .line 76
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result v0

    .line 77
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    return v0

    :cond_1
    and-int/lit16 v1, v0, 0x3c00

    if-nez v1, :cond_2

    shr-int/2addr v0, v5

    and-int/lit16 v0, v0, 0xff

    or-int/lit16 v0, v0, -0x100

    const/16 v1, 0xe

    .line 68
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    goto :goto_0

    :cond_2
    shr-int/2addr v0, v3

    and-int/lit16 v0, v0, 0xff

    .line 71
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    :goto_0
    return v0

    .line 63
    :cond_3
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    shr-int/lit8 p0, v0, 0xa

    and-int/lit8 p0, p0, 0xf

    return p0
.end method

.method private decodeArg(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;Z)V
    .locals 6

    .line 792
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->fgetbits()I

    move-result v0

    const v1, 0x8000

    and-int/2addr v1, v0

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    .line 794
    sget-object p2, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREG:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    shr-int/lit8 p2, v0, 0xc

    and-int/2addr p2, v3

    .line 795
    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 796
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getData()I

    move-result p2

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setOffset(I)V

    .line 797
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    goto :goto_1

    :cond_0
    const v1, 0xc000

    and-int/2addr v1, v0

    const/4 v4, 0x6

    const/16 v5, 0xa

    if-nez v1, :cond_2

    .line 800
    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    if-eqz p2, :cond_1

    shr-int/lit8 p2, v0, 0x6

    and-int/lit16 p2, p2, 0xff

    .line 802
    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 803
    invoke-virtual {p0, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    goto :goto_1

    :cond_1
    const/4 p2, 0x2

    .line 805
    invoke-virtual {p0, p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    .line 806
    invoke-static {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result p2

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    goto :goto_1

    .line 809
    :cond_2
    sget-object p2, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    and-int/lit16 p2, v0, 0x2000

    const/4 v1, 0x0

    if-nez p2, :cond_3

    shr-int/lit8 p2, v0, 0xa

    and-int/2addr p2, v3

    .line 811
    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 812
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getData()I

    move-result p2

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setOffset(I)V

    .line 813
    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setBase(I)V

    .line 814
    invoke-virtual {p0, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    goto :goto_1

    :cond_3
    and-int/lit16 p2, v0, 0x1000

    if-nez p2, :cond_4

    shr-int/lit8 p2, v0, 0x9

    and-int/2addr p2, v3

    .line 817
    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 818
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getData()I

    move-result p2

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setOffset(I)V

    .line 819
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    goto :goto_0

    .line 821
    :cond_4
    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 822
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    .line 824
    :goto_0
    invoke-static {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result p2

    invoke-virtual {p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setBase(I)V

    :goto_1
    return-void
.end method

.method private filterItanium_GetBits(III)I
    .locals 4

    .line 1170
    div-int/lit8 v0, p2, 0x8

    and-int/lit8 p2, p2, 0x7

    .line 1172
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int/lit8 v2, v0, 0x1

    add-int/2addr v0, p1

    aget-byte v0, v1, v0

    and-int/lit16 v0, v0, 0xff

    add-int/lit8 v3, v2, 0x1

    add-int/2addr v2, p1

    .line 1173
    aget-byte v2, v1, v2

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v0, v2

    add-int/lit8 v2, v3, 0x1

    add-int/2addr v3, p1

    .line 1174
    aget-byte v3, v1, v3

    and-int/lit16 v3, v3, 0xff

    shl-int/lit8 v3, v3, 0x10

    or-int/2addr v0, v3

    add-int/2addr p1, v2

    .line 1175
    aget-byte p1, v1, p1

    and-int/lit16 p1, p1, 0xff

    shl-int/lit8 p1, p1, 0x18

    or-int/2addr p1, v0

    ushr-int/2addr p1, p2

    rsub-int/lit8 p2, p3, 0x20

    const/4 p3, -0x1

    ushr-int p2, p3, p2

    and-int/2addr p1, p2

    return p1
.end method

.method private filterItanium_SetBits(IIII)V
    .locals 4

    .line 1153
    div-int/lit8 v0, p3, 0x8

    and-int/lit8 p3, p3, 0x7

    rsub-int/lit8 p4, p4, 0x20

    const/4 v1, -0x1

    ushr-int p4, v1, p4

    shl-int/2addr p4, p3

    xor-int/2addr p4, v1

    shl-int/2addr p2, p3

    const/4 p3, 0x0

    :goto_0
    const/4 v1, 0x4

    if-ge p3, v1, :cond_0

    .line 1161
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int v2, p1, v0

    add-int/2addr v2, p3

    aget-byte v3, v1, v2

    and-int/2addr v3, p4

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    .line 1162
    aget-byte v3, v1, v2

    or-int/2addr v3, p2

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    ushr-int/lit8 p4, p4, 0x8

    const/high16 v1, -0x1000000

    or-int/2addr p4, v1

    ushr-int/lit8 p2, p2, 0x8

    add-int/lit8 p3, p3, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private getOperand(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;)I
    .locals 2

    .line 160
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getType()Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    move-result-object v0

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPREGMEM:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    if-ne v0, v1, :cond_0

    .line 161
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getOffset()I

    move-result v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getBase()I

    move-result p1

    add-int/2addr v0, p1

    const p1, 0x3ffff

    and-int/2addr p1, v0

    .line 162
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-static {v0, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    goto :goto_0

    .line 164
    :cond_0
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getOffset()I

    move-result p1

    .line 165
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    invoke-static {v0, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    :goto_0
    return p1
.end method

.method private getValue(Z[BI)I
    .locals 0

    if-eqz p1, :cond_1

    .line 101
    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->isVMMem([B)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 102
    aget-byte p1, p2, p3

    return p1

    .line 104
    :cond_0
    aget-byte p1, p2, p3

    and-int/lit16 p1, p1, 0xff

    return p1

    .line 107
    :cond_1
    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->isVMMem([B)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 109
    invoke-static {p2, p3}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    return p1

    .line 112
    :cond_2
    invoke-static {p2, p3}, Lir/mahdi/mzip/rar/io/Raw;->readIntBigEndian([BI)I

    move-result p1

    return p1
.end method

.method private isVMMem([B)Z
    .locals 1

    .line 96
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method private optimize(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V
    .locals 7

    .line 832
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmd()Ljava/util/List;

    move-result-object p1

    .line 834
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_13

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    .line 835
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/RarVM$1;->$SwitchMap$ir$mahdi$mzip$rar$unpack$vm$VMCommands:[I

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v3

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->ordinal()I

    move-result v3

    aget v2, v2, v3

    const/4 v3, 0x1

    if-eq v2, v3, :cond_11

    const/4 v4, 0x4

    if-eq v2, v4, :cond_f

    .line 845
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCmdFlags;->VM_CmdFlags:[B

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->getVMCommand()I

    move-result v4

    aget-byte v2, v2, v4

    and-int/lit8 v2, v2, 0x40

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    .line 850
    invoke-interface {p1, v1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v4

    add-int/2addr v4, v3

    :goto_1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_3

    .line 851
    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMCmdFlags;->VM_CmdFlags:[B

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v6

    .line 852
    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->getVMCommand()I

    move-result v6

    aget-byte v5, v5, v6

    and-int/lit8 v6, v5, 0x38

    if-eqz v6, :cond_1

    const/4 v2, 0x1

    goto :goto_2

    :cond_1
    and-int/lit8 v5, v5, 0x40

    if-eqz v5, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    :goto_2
    if-eqz v2, :cond_4

    goto :goto_0

    .line 864
    :cond_4
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/RarVM$1;->$SwitchMap$ir$mahdi$mzip$rar$unpack$vm$VMCommands:[I

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v3

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->ordinal()I

    move-result v3

    aget v2, v2, v3

    const/4 v3, 0x7

    if-eq v2, v3, :cond_d

    const/16 v3, 0xa

    if-eq v2, v3, :cond_b

    const/16 v3, 0xf

    if-eq v2, v3, :cond_9

    const/16 v3, 0x12

    if-eq v2, v3, :cond_7

    const/16 v3, 0x27

    if-eq v2, v3, :cond_5

    goto :goto_0

    .line 882
    :cond_5
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_6

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_3

    :cond_6
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_3
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    .line 878
    :cond_7
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_8

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_4

    :cond_8
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_4
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    .line 874
    :cond_9
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_a

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_5

    :cond_a
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_5
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    .line 870
    :cond_b
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_c

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_6

    :cond_c
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_6
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    .line 866
    :cond_d
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_e

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_7

    :cond_e
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_7
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    .line 841
    :cond_f
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_10

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_8

    :cond_10
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_8
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    .line 837
    :cond_11
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v2

    if-eqz v2, :cond_12

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    goto :goto_9

    :cond_12
    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    :goto_9
    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    goto/16 :goto_0

    :cond_13
    return-void
.end method

.method private setIP(I)Z
    .locals 2

    .line 237
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->codeSize:I

    const/4 v1, 0x1

    if-lt p1, v0, :cond_0

    return v1

    .line 241
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->maxOpCount:I

    sub-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->maxOpCount:I

    if-gtz v0, :cond_1

    const/4 p1, 0x0

    return p1

    .line 245
    :cond_1
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IP:I

    return v1
.end method

.method private setValue(Z[BII)V
    .locals 0

    if-eqz p1, :cond_1

    .line 118
    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->isVMMem([B)Z

    move-result p1

    if-eqz p1, :cond_0

    int-to-byte p1, p4

    .line 119
    aput-byte p1, p2, p3

    goto :goto_0

    .line 121
    :cond_0
    aget-byte p1, p2, p3

    and-int/lit8 p1, p1, 0x0

    and-int/lit16 p4, p4, 0xff

    int-to-byte p4, p4

    or-int/2addr p1, p4

    int-to-byte p1, p1

    aput-byte p1, p2, p3

    goto :goto_0

    .line 124
    :cond_1
    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->isVMMem([B)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 125
    invoke-static {p2, p3, p4}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    goto :goto_0

    .line 131
    :cond_2
    invoke-static {p2, p3, p4}, Lir/mahdi/mzip/rar/io/Raw;->writeIntBigEndian([BII)V

    :goto_0
    return-void
.end method


# virtual methods
.method public execute(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V
    .locals 10

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 171
    :goto_0
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object v2

    array-length v2, v2

    if-ge v1, v2, :cond_0

    .line 173
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object v3

    aget v3, v3, v1

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 177
    :cond_0
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    const/16 v2, 0x2000

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    and-int/lit8 v1, v1, -0x1

    int-to-long v1, v1

    const-wide/16 v3, 0x0

    const v5, 0x3c000

    cmp-long v6, v1, v3

    if-eqz v6, :cond_1

    const/4 v6, 0x0

    :goto_1
    int-to-long v7, v6

    cmp-long v9, v7, v1

    if-gez v9, :cond_1

    .line 181
    iget-object v7, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int v8, v6, v5

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Byte;

    invoke-virtual {v9}, Ljava/lang/Byte;->byteValue()B

    move-result v9

    aput-byte v9, v7, v8

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    .line 185
    :cond_1
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getStaticData()Ljava/util/Vector;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/Vector;->size()I

    move-result v6

    int-to-long v6, v6

    const-wide/16 v8, 0x2000

    sub-long/2addr v8, v1

    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v6

    const-wide/16 v8, -0x1

    and-long/2addr v6, v8

    cmp-long v8, v6, v3

    if-eqz v8, :cond_2

    const/4 v3, 0x0

    :goto_2
    int-to-long v8, v3

    cmp-long v4, v8, v6

    if-gez v4, :cond_2

    .line 190
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    long-to-int v8, v1

    add-int/2addr v8, v5

    add-int/2addr v8, v3

    .line 191
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getStaticData()Ljava/util/Vector;

    move-result-object v9

    invoke-virtual {v9, v3}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Byte;

    invoke-virtual {v9}, Ljava/lang/Byte;->byteValue()B

    move-result v9

    aput-byte v9, v4, v8

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 195
    :cond_2
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->R:[I

    const/4 v2, 0x7

    const/high16 v3, 0x40000

    aput v3, v1, v2

    .line 196
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->flags:I

    .line 198
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getAltCmd()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-eqz v1, :cond_3

    .line 199
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getAltCmd()Ljava/util/List;

    move-result-object v1

    goto :goto_3

    .line 200
    :cond_3
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmd()Ljava/util/List;

    move-result-object v1

    .line 202
    :goto_3
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmdCount()I

    move-result v2

    invoke-direct {p0, v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ExecuteCode(Ljava/util/List;I)Z

    move-result v2

    if-nez v2, :cond_4

    .line 203
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    .line 205
    :cond_4
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    const v2, 0x3c020

    invoke-direct {p0, v0, v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v1

    const v2, 0x3ffff

    and-int/2addr v1, v2

    .line 207
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    const v6, 0x3c01c

    invoke-direct {p0, v0, v4, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v4

    and-int/2addr v2, v4

    add-int v4, v1, v2

    if-lt v4, v3, :cond_5

    const/4 v1, 0x0

    const/4 v2, 0x0

    .line 214
    :cond_5
    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setFilteredDataOffset(I)V

    .line 215
    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setFilteredDataSize(I)V

    .line 217
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Vector;->clear()V

    .line 219
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    const v2, 0x3c030

    invoke-direct {p0, v0, v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getValue(Z[BI)I

    move-result v1

    const/16 v2, 0x1fc0

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    if-eqz v1, :cond_6

    .line 222
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v2

    add-int/lit8 v1, v1, 0x40

    invoke-virtual {v2, v1}, Ljava/util/Vector;->setSize(I)V

    :goto_4
    if-ge v0, v1, :cond_6

    .line 227
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v2

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int v4, v0, v5

    aget-byte v3, v3, v4

    invoke-static {v3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_6
    return-void
.end method

.method public getMem()[B
    .locals 1

    .line 233
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    return-object v0
.end method

.method public init()V
    .locals 1

    .line 90
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    if-nez v0, :cond_0

    const v0, 0x40004

    .line 91
    new-array v0, v0, [B

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    :cond_0
    return-void
.end method

.method public prepare([BILir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V
    .locals 9

    .line 660
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->InitBitInput()V

    const v0, 0x8000

    .line 661
    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_0

    .line 664
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->inBuf:[B

    aget-byte v5, v4, v3

    aget-byte v6, p1, v3

    or-int/2addr v5, v6

    int-to-byte v5, v5

    aput-byte v5, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    :goto_1
    if-ge v3, p2, :cond_1

    .line 669
    aget-byte v5, p1, v3

    xor-int/2addr v4, v5

    int-to-byte v4, v4

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    const/16 v3, 0x8

    .line 672
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    .line 674
    invoke-virtual {p3, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setCmdCount(I)V

    .line 675
    aget-byte v5, p1, v2

    if-ne v4, v5, :cond_d

    .line 676
    invoke-direct {p0, p1, p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->IsStandardFilter([BI)Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    move-result-object p1

    .line 677
    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    if-eq p1, v4, :cond_2

    .line 679
    new-instance p2, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    invoke-direct {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;-><init>()V

    .line 680
    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_STANDARD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {p2, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    .line 681
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->getFilter()I

    move-result p1

    invoke-virtual {v4, p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 682
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object p1

    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {p1, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    .line 683
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp2()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object p1

    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {p1, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    .line 685
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmd()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 686
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmdCount()I

    move-result p1

    add-int/2addr p1, v1

    invoke-virtual {p3, p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setCmdCount(I)V

    const/4 p2, 0x0

    .line 695
    :cond_2
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->fgetbits()I

    move-result p1

    .line 696
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    and-int/2addr p1, v0

    if-eqz p1, :cond_3

    .line 703
    invoke-static {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result p1

    int-to-long v4, p1

    const-wide/16 v6, 0x0

    and-long/2addr v4, v6

    const/4 p1, 0x0

    .line 704
    :goto_2
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->inAddr:I

    if-ge v6, p2, :cond_3

    int-to-long v6, p1

    cmp-long v8, v6, v4

    if-gez v8, :cond_3

    .line 705
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getStaticData()Ljava/util/Vector;

    move-result-object v6

    .line 706
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->fgetbits()I

    move-result v7

    shr-int/2addr v7, v3

    int-to-byte v7, v7

    invoke-static {v7}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v7

    .line 705
    invoke-virtual {v6, v7}, Ljava/util/Vector;->add(Ljava/lang/Object;)Z

    .line 707
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    .line 711
    :cond_3
    :goto_3
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->inAddr:I

    if-ge p1, p2, :cond_d

    .line 712
    new-instance p1, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    invoke-direct {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;-><init>()V

    .line 713
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->fgetbits()I

    move-result v4

    and-int v5, v4, v0

    const/4 v6, 0x4

    if-nez v5, :cond_4

    shr-int/lit8 v4, v4, 0xc

    .line 715
    invoke-static {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->findVMCommand(I)Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v4

    invoke-virtual {p1, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    .line 716
    invoke-virtual {p0, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    goto :goto_4

    :cond_4
    shr-int/lit8 v4, v4, 0xa

    add-int/lit8 v4, v4, -0x18

    .line 719
    invoke-static {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->findVMCommand(I)Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v4

    .line 718
    invoke-virtual {p1, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    const/4 v4, 0x6

    .line 720
    invoke-virtual {p0, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    .line 722
    :goto_4
    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMCmdFlags;->VM_CmdFlags:[B

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v5

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->getVMCommand()I

    move-result v5

    aget-byte v4, v4, v5

    and-int/2addr v4, v6

    if-eqz v4, :cond_6

    .line 723
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->fgetbits()I

    move-result v4

    shr-int/lit8 v4, v4, 0xf

    if-ne v4, v1, :cond_5

    const/4 v4, 0x1

    goto :goto_5

    :cond_5
    const/4 v4, 0x0

    :goto_5
    invoke-virtual {p1, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setByteMode(Z)V

    .line 724
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->faddbits(I)V

    goto :goto_6

    .line 726
    :cond_6
    invoke-virtual {p1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setByteMode(Z)V

    .line 728
    :goto_6
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    .line 729
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp2()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    .line 731
    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMCmdFlags;->VM_CmdFlags:[B

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v5

    .line 732
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->getVMCommand()I

    move-result v5

    aget-byte v4, v4, v5

    and-int/lit8 v4, v4, 0x3

    if-lez v4, :cond_c

    .line 735
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v5

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v6

    invoke-direct {p0, v5, v6}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->decodeArg(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;Z)V

    const/4 v5, 0x2

    if-ne v4, v5, :cond_7

    .line 737
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp2()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->isByteMode()Z

    move-result v5

    invoke-direct {p0, v4, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->decodeArg(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;Z)V

    goto :goto_9

    .line 739
    :cond_7
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getType()Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    move-result-object v4

    sget-object v5, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPINT:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    if-ne v4, v5, :cond_c

    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMCmdFlags;->VM_CmdFlags:[B

    .line 740
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    move-result-object v5

    .line 741
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->getVMCommand()I

    move-result v5

    aget-byte v4, v4, v5

    and-int/lit8 v4, v4, 0x18

    if-eqz v4, :cond_c

    .line 742
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->getData()I

    move-result v4

    const/16 v5, 0x100

    if-lt v4, v5, :cond_8

    add-int/lit16 v4, v4, -0x100

    goto :goto_8

    :cond_8
    const/16 v5, 0x88

    if-lt v4, v5, :cond_9

    add-int/lit16 v4, v4, -0x108

    goto :goto_7

    :cond_9
    const/16 v5, 0x10

    if-lt v4, v5, :cond_a

    add-int/lit8 v4, v4, -0x8

    goto :goto_7

    :cond_a
    if-lt v4, v3, :cond_b

    add-int/lit8 v4, v4, -0x10

    .line 757
    :cond_b
    :goto_7
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmdCount()I

    move-result v5

    add-int/2addr v4, v5

    .line 759
    :goto_8
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v5

    invoke-virtual {v5, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setData(I)V

    .line 763
    :cond_c
    :goto_9
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmdCount()I

    move-result v4

    add-int/2addr v4, v1

    invoke-virtual {p3, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setCmdCount(I)V

    .line 764
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmd()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_3

    .line 767
    :cond_d
    new-instance p1, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;

    invoke-direct {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;-><init>()V

    .line 768
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {p1, v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V

    .line 771
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v0

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    .line 772
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->getOp2()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    move-result-object v0

    sget-object v2, Lir/mahdi/mzip/rar/unpack/vm/VMOpType;->VM_OPNONE:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    invoke-virtual {v0, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V

    .line 783
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmd()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 784
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmdCount()I

    move-result p1

    add-int/2addr p1, v1

    invoke-virtual {p3, p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setCmdCount(I)V

    if-eqz p2, :cond_e

    .line 787
    invoke-direct {p0, p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->optimize(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V

    :cond_e
    return-void
.end method

.method public setLowEndianValue(Ljava/util/Vector;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Vector<",
            "Ljava/lang/Byte;",
            ">;II)V"
        }
    .end annotation

    add-int/lit8 v0, p2, 0x0

    and-int/lit16 v1, p3, 0xff

    int-to-byte v1, v1

    .line 152
    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, p2, 0x1

    ushr-int/lit8 v1, p3, 0x8

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    .line 153
    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, p2, 0x2

    ushr-int/lit8 v1, p3, 0x10

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    .line 154
    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 p2, p2, 0x3

    ushr-int/lit8 p3, p3, 0x18

    and-int/lit16 p3, p3, 0xff

    int-to-byte p3, p3

    .line 155
    invoke-static {p3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public setLowEndianValue([BII)V
    .locals 0

    .line 144
    invoke-static {p1, p2, p3}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    return-void
.end method

.method public setMemory(I[BII)V
    .locals 5

    const/high16 v0, 0x40000

    if-ge p1, v0, :cond_1

    const/4 v1, 0x0

    .line 1184
    :goto_0
    array-length v2, p2

    sub-int/2addr v2, p3

    invoke-static {v2, p4}, Ljava/lang/Math;->min(II)I

    move-result v2

    if-ge v1, v2, :cond_1

    sub-int v2, v0, p1

    if-ge v2, v1, :cond_0

    goto :goto_1

    .line 1188
    :cond_0
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->mem:[B

    add-int v3, p1, v1

    add-int v4, p3, v1

    aget-byte v4, p2, v4

    aput-byte v4, v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method
