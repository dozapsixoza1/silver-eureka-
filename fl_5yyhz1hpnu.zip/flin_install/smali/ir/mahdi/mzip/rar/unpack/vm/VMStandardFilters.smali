.class public final enum Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;
.super Ljava/lang/Enum;
.source "VMStandardFilters.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_AUDIO:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_DELTA:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_E8:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_ITANIUM:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_RGB:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

.field public static final enum VMSF_UPCASE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;


# instance fields
.field private filter:I


# direct methods
.method static constructor <clinit>()V
    .locals 10

    .line 21
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v1, 0x0

    const-string v2, "VMSF_NONE"

    invoke-direct {v0, v2, v1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v2, 0x1

    const-string v3, "VMSF_E8"

    invoke-direct {v0, v3, v2, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v3, 0x2

    const-string v4, "VMSF_E8E9"

    invoke-direct {v0, v4, v3, v3}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v4, 0x3

    const-string v5, "VMSF_ITANIUM"

    invoke-direct {v0, v5, v4, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_ITANIUM:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 25
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v5, 0x4

    const-string v6, "VMSF_RGB"

    invoke-direct {v0, v6, v5, v5}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_RGB:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 26
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v6, 0x5

    const-string v7, "VMSF_AUDIO"

    invoke-direct {v0, v7, v6, v6}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_AUDIO:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 27
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v7, 0x6

    const-string v8, "VMSF_DELTA"

    invoke-direct {v0, v8, v7, v7}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_DELTA:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    .line 28
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/4 v8, 0x7

    const-string v9, "VMSF_UPCASE"

    invoke-direct {v0, v9, v8, v8}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_UPCASE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    const/16 v0, 0x8

    .line 20
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    sget-object v9, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v9, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_ITANIUM:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_RGB:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_AUDIO:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v6

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_DELTA:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v7

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_UPCASE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    aput-object v1, v0, v8

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 32
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 33
    iput p3, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->filter:I

    return-void
.end method

.method public static findFilter(I)Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;
    .locals 1

    .line 37
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 38
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_NONE:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    .line 41
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 42
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    .line 45
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 46
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_E8E9:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    .line 48
    :cond_2
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_ITANIUM:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 49
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_ITANIUM:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    .line 52
    :cond_3
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_RGB:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 53
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_RGB:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    .line 56
    :cond_4
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_AUDIO:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 57
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_AUDIO:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    .line 59
    :cond_5
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_DELTA:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->equals(I)Z

    move-result p0

    if-eqz p0, :cond_6

    .line 60
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->VMSF_DELTA:Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0

    :cond_6
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;
    .locals 1

    .line 20
    const-class v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;
    .locals 1

    .line 20
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;

    return-object v0
.end method


# virtual methods
.method public equals(I)Z
    .locals 1

    .line 70
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->filter:I

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getFilter()I
    .locals 1

    .line 66
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMStandardFilters;->filter:I

    return v0
.end method
