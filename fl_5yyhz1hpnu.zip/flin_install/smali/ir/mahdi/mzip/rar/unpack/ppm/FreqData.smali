.class public Lir/mahdi/mzip/rar/unpack/ppm/FreqData;
.super Lir/mahdi/mzip/rar/unpack/ppm/Pointer;
.source "FreqData.java"


# static fields
.field public static final size:I = 0x6


# direct methods
.method public constructor <init>([B)V
    .locals 0

    .line 33
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;-><init>([B)V

    return-void
.end method


# virtual methods
.method public getStats()I
    .locals 2

    .line 55
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    add-int/lit8 v1, v1, 0x2

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v0

    return v0
.end method

.method public getSummFreq()I
    .locals 2

    .line 43
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    const v1, 0xffff

    and-int/2addr v0, v1

    return v0
.end method

.method public incSummFreq(I)V
    .locals 2

    .line 51
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->incShortLittleEndian([BII)V

    return-void
.end method

.method public init([B)Lir/mahdi/mzip/rar/unpack/ppm/FreqData;
    .locals 0

    .line 37
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->mem:[B

    const/4 p1, 0x0

    .line 38
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    return-object p0
.end method

.method public setStats(I)V
    .locals 2

    .line 59
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    add-int/lit8 v1, v1, 0x2

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    return-void
.end method

.method public setStats(Lir/mahdi/mzip/rar/unpack/ppm/State;)V
    .locals 0

    .line 63
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setStats(I)V

    return-void
.end method

.method public setSummFreq(I)V
    .locals 2

    .line 47
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    int-to-short p1, p1

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 67
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "FreqData["

    .line 68
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  pos="

    .line 69
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->pos:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  size="

    .line 71
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    .line 72
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  summFreq="

    .line 73
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  stats="

    .line 75
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 77
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
