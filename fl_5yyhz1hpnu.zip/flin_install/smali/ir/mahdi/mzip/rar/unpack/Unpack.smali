.class public final Lir/mahdi/mzip/rar/unpack/Unpack;
.super Lir/mahdi/mzip/rar/unpack/Unpack20;
.source "Unpack.java"


# static fields
.field public static DBitLengthCounts:[I


# instance fields
.field private externalWindow:Z

.field private fileExtracted:Z

.field private filters:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lir/mahdi/mzip/rar/unpack/UnpackFilter;",
            ">;"
        }
    .end annotation
.end field

.field private lastFilter:I

.field private lowDistRepCount:I

.field private oldFilterLengths:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

.field private ppmError:Z

.field private ppmEscChar:I

.field private prevLowDist:I

.field private prgStack:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lir/mahdi/mzip/rar/unpack/UnpackFilter;",
            ">;"
        }
    .end annotation
.end field

.field private rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

.field private tablesRead:Z

.field private unpBlockType:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

.field private unpOldTable:[B

.field private writtenFileSize:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x13

    .line 38
    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lir/mahdi/mzip/rar/unpack/Unpack;->DBitLengthCounts:[I

    return-void

    :array_0
    .array-data 4
        0x4
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0xe
        0x0
        0xc
    .end array-data
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/unpack/ComprDataIO;)V
    .locals 1

    .line 63
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack20;-><init>()V

    .line 40
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    .line 42
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    .line 44
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    .line 46
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    .line 51
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    const/16 v0, 0x194

    .line 54
    new-array v0, v0, [B

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpOldTable:[B

    .line 64
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    const/4 p1, 0x0

    .line 65
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    const/4 p1, 0x0

    .line 66
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->externalWindow:Z

    .line 67
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->suspended:Z

    .line 68
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpAllBuf:Z

    .line 69
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpSomeRead:Z

    return-void
.end method

.method private ExecuteCode(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V
    .locals 6

    .line 961
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-lez v0, :cond_0

    .line 963
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object v0

    const/4 v1, 0x6

    iget-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    long-to-int v3, v2

    aput v3, v0, v1

    .line 966
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    const/16 v2, 0x24

    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    long-to-int v4, v3

    invoke-virtual {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    .line 970
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    const/16 v2, 0x28

    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    const/16 v5, 0x20

    ushr-long/2addr v3, v5

    long-to-int v4, v3

    invoke-virtual {v0, v1, v2, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    .line 972
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->execute(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V

    :cond_0
    return-void
.end method

.method private UnpWriteArea(II)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x1

    if-eq p2, p1, :cond_0

    .line 513
    iput-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpSomeRead:Z

    :cond_0
    if-ge p2, p1, :cond_1

    .line 516
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    neg-int v2, p1

    const v3, 0x3fffff

    and-int/2addr v2, v3

    invoke-direct {p0, v1, p1, v2}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteData([BII)V

    .line 517
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    const/4 v1, 0x0

    invoke-direct {p0, p1, v1, p2}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteData([BII)V

    .line 518
    iput-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpAllBuf:Z

    goto :goto_0

    .line 520
    :cond_1
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    sub-int/2addr p2, p1

    invoke-direct {p0, v0, p1, p2}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteData([BII)V

    :goto_0
    return-void
.end method

.method private UnpWriteBuf()V
    .locals 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 338
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    .line 339
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    sub-int/2addr v1, v0

    const v2, 0x3fffff

    and-int/2addr v1, v2

    const/4 v3, 0x0

    move v4, v1

    move v1, v0

    const/4 v0, 0x0

    .line 340
    :goto_0
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v0, v5, :cond_15

    .line 341
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v5, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    const/4 v6, 0x1

    if-nez v5, :cond_0

    goto/16 :goto_c

    .line 345
    :cond_0
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->isNextWindow()Z

    move-result v7

    if-eqz v7, :cond_1

    .line 346
    invoke-virtual {v5, v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setNextWindow(Z)V

    goto/16 :goto_c

    .line 349
    :cond_1
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockStart()I

    move-result v7

    .line 350
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockLength()I

    move-result v8

    sub-int v9, v7, v1

    and-int/2addr v9, v2

    if-ge v9, v4, :cond_14

    if-eq v1, v7, :cond_2

    .line 353
    invoke-direct {p0, v1, v7}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteArea(II)V

    .line 355
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    sub-int/2addr v1, v7

    and-int v4, v1, v2

    move v1, v7

    :cond_2
    if-gt v8, v4, :cond_11

    add-int v1, v7, v8

    and-int/2addr v1, v2

    if-lt v7, v1, :cond_4

    if-nez v1, :cond_3

    goto :goto_1

    :cond_3
    const/high16 v4, 0x400000

    sub-int/2addr v4, v7

    .line 366
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    iget-object v9, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    invoke-virtual {v8, v3, v9, v7, v4}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setMemory(I[BII)V

    .line 368
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    iget-object v9, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    invoke-virtual {v8, v4, v9, v3, v1}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setMemory(I[BII)V

    goto :goto_2

    .line 362
    :cond_4
    :goto_1
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    iget-object v9, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    invoke-virtual {v4, v3, v9, v7, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setMemory(I[BII)V

    .line 372
    :goto_2
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    .line 373
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getParentFilter()I

    move-result v8

    .line 372
    invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    .line 373
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v4

    .line 374
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v5

    .line 376
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/Vector;->size()I

    move-result v8

    const/16 v9, 0x40

    if-le v8, v9, :cond_5

    .line 381
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    .line 382
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    .line 381
    invoke-virtual {v8, v10}, Ljava/util/Vector;->setSize(I)V

    const/4 v8, 0x0

    .line 383
    :goto_3
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    sub-int/2addr v10, v9

    if-ge v8, v10, :cond_5

    .line 385
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    add-int/lit8 v11, v8, 0x40

    .line 387
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v12

    .line 385
    invoke-virtual {v10, v11, v12}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    .line 392
    :cond_5
    invoke-direct {p0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->ExecuteCode(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V

    .line 394
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/Vector;->size()I

    move-result v8

    if-le v8, v9, :cond_7

    .line 396
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/Vector;->size()I

    move-result v8

    .line 397
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    if-ge v8, v10, :cond_6

    .line 398
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    .line 399
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    .line 398
    invoke-virtual {v8, v10}, Ljava/util/Vector;->setSize(I)V

    :cond_6
    const/4 v8, 0x0

    .line 402
    :goto_4
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v10

    sub-int/2addr v10, v9

    if-ge v8, v10, :cond_8

    .line 404
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v10

    add-int/lit8 v11, v8, 0x40

    .line 406
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v12

    .line 404
    invoke-virtual {v10, v11, v12}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v8, v8, 0x1

    goto :goto_4

    .line 410
    :cond_7
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Vector;->clear()V

    .line 413
    :cond_8
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getFilteredDataOffset()I

    move-result v4

    .line 414
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getFilteredDataSize()I

    move-result v5

    .line 415
    new-array v8, v5, [B

    const/4 v10, 0x0

    :goto_5
    if-ge v10, v5, :cond_9

    .line 418
    iget-object v11, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->getMem()[B

    move-result-object v11

    add-int v12, v4, v10

    aget-byte v11, v11, v12

    aput-byte v11, v8, v10

    add-int/lit8 v10, v10, 0x1

    goto :goto_5

    .line 423
    :cond_9
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    const/4 v10, 0x0

    invoke-interface {v4, v0, v10}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :goto_6
    add-int/lit8 v4, v0, 0x1

    .line 424
    iget-object v11, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    if-ge v4, v11, :cond_10

    .line 425
    iget-object v11, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v11, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    if-eqz v11, :cond_10

    .line 427
    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockStart()I

    move-result v12

    if-ne v12, v7, :cond_10

    .line 428
    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockLength()I

    move-result v12

    if-ne v12, v5, :cond_10

    .line 429
    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->isNextWindow()Z

    move-result v12

    if-eqz v12, :cond_a

    goto/16 :goto_a

    .line 434
    :cond_a
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {v0, v3, v8, v3, v5}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setMemory(I[BII)V

    .line 436
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    .line 437
    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getParentFilter()I

    move-result v5

    .line 436
    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    .line 437
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v0

    .line 438
    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v5

    .line 440
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/Vector;->size()I

    move-result v8

    if-le v8, v9, :cond_b

    .line 444
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    .line 445
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/Vector;->size()I

    move-result v11

    .line 444
    invoke-virtual {v8, v11}, Ljava/util/Vector;->setSize(I)V

    const/4 v8, 0x0

    .line 447
    :goto_7
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/Vector;->size()I

    move-result v11

    sub-int/2addr v11, v9

    if-ge v8, v11, :cond_b

    .line 449
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    add-int/lit8 v12, v8, 0x40

    .line 451
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v13

    invoke-virtual {v13, v12}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v13

    .line 449
    invoke-virtual {v11, v12, v13}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v8, v8, 0x1

    goto :goto_7

    .line 456
    :cond_b
    invoke-direct {p0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->ExecuteCode(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V

    .line 458
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/Vector;->size()I

    move-result v8

    if-le v8, v9, :cond_d

    .line 460
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/Vector;->size()I

    move-result v8

    .line 461
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/Vector;->size()I

    move-result v11

    if-ge v8, v11, :cond_c

    .line 462
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v8

    .line 463
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/Vector;->size()I

    move-result v11

    .line 462
    invoke-virtual {v8, v11}, Ljava/util/Vector;->setSize(I)V

    :cond_c
    const/4 v8, 0x0

    .line 466
    :goto_8
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/Vector;->size()I

    move-result v11

    sub-int/2addr v11, v9

    if-ge v8, v11, :cond_e

    .line 468
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v11

    add-int/lit8 v12, v8, 0x40

    .line 470
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v13

    invoke-virtual {v13, v12}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v13

    .line 468
    invoke-virtual {v11, v12, v13}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v8, v8, 0x1

    goto :goto_8

    .line 474
    :cond_d
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    .line 476
    :cond_e
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getFilteredDataOffset()I

    move-result v0

    .line 477
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getFilteredDataSize()I

    move-result v8

    .line 479
    new-array v11, v8, [B

    const/4 v12, 0x0

    :goto_9
    if-ge v12, v8, :cond_f

    .line 481
    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v13

    add-int v14, v0, v12

    invoke-virtual {v13, v14}, Ljava/util/Vector;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Byte;

    invoke-virtual {v13}, Ljava/lang/Byte;->byteValue()B

    move-result v13

    aput-byte v13, v11, v12

    add-int/lit8 v12, v12, 0x1

    goto :goto_9

    .line 486
    :cond_f
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v0, v4, v10}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    move v0, v4

    move v5, v8

    move-object v8, v11

    goto/16 :goto_6

    .line 488
    :cond_10
    :goto_a
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {v4, v8, v3, v5}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpWrite([BII)V

    .line 489
    iput-boolean v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpSomeRead:Z

    .line 490
    iget-wide v7, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    int-to-long v4, v5

    add-long/2addr v7, v4

    iput-wide v7, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    .line 492
    iget v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    sub-int/2addr v4, v1

    and-int/2addr v4, v2

    goto :goto_c

    .line 494
    :cond_11
    :goto_b
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-ge v0, v2, :cond_13

    .line 495
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    if-eqz v2, :cond_12

    .line 496
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->isNextWindow()Z

    move-result v4

    if-eqz v4, :cond_12

    .line 497
    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setNextWindow(Z)V

    :cond_12
    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    .line 500
    :cond_13
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    return-void

    :cond_14
    :goto_c
    add-int/2addr v0, v6

    goto/16 :goto_0

    .line 506
    :cond_15
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    invoke-direct {p0, v1, v0}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteArea(II)V

    .line 507
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    return-void
.end method

.method private UnpWriteData([BII)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 526
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    iget-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    cmp-long v4, v0, v2

    if-ltz v4, :cond_0

    return-void

    .line 530
    :cond_0
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    iget-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    sub-long/2addr v0, v2

    int-to-long v2, p3

    cmp-long v4, v2, v0

    if-lez v4, :cond_1

    long-to-int p3, v0

    .line 534
    :cond_1
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {v0, p1, p2, p3}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpWrite([BII)V

    .line 536
    iget-wide p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    add-long/2addr p1, v2

    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    return-void
.end method

.method private addVMCode(ILjava/util/List;I)Z
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Byte;",
            ">;I)Z"
        }
    .end annotation

    .line 782
    new-instance p3, Lir/mahdi/mzip/rar/unpack/vm/BitInput;

    invoke-direct {p3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;-><init>()V

    .line 783
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->InitBitInput()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    const v2, 0x8000

    .line 785
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v2

    if-ge v1, v2, :cond_0

    .line 786
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->getInBuf()[B

    move-result-object v2

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Byte;

    invoke-virtual {v3}, Ljava/lang/Byte;->byteValue()B

    move-result v3

    aput-byte v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 788
    :cond_0
    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->init()V

    and-int/lit16 p2, p1, 0x80

    if-eqz p2, :cond_2

    .line 792
    invoke-static {p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result p2

    if-nez p2, :cond_1

    .line 794
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->initFilters()V

    goto :goto_1

    :cond_1
    add-int/lit8 p2, p2, -0x1

    goto :goto_1

    .line 799
    :cond_2
    iget p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastFilter:I

    .line 801
    :goto_1
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-gt p2, v1, :cond_1b

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-le p2, v1, :cond_3

    goto/16 :goto_e

    .line 804
    :cond_3
    iput p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastFilter:I

    .line 805
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ne p2, v1, :cond_4

    const/4 v1, 0x1

    goto :goto_2

    :cond_4
    const/4 v1, 0x0

    .line 807
    :goto_2
    new-instance v3, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    invoke-direct {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;-><init>()V

    if-eqz v1, :cond_6

    const/16 v4, 0x400

    if-le p2, v4, :cond_5

    return v0

    .line 819
    :cond_5
    new-instance v4, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    invoke-direct {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;-><init>()V

    .line 820
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 821
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    sub-int/2addr v5, v2

    invoke-virtual {v3, v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setParentFilter(I)V

    .line 822
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 823
    invoke-virtual {v4, v0}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setExecCount(I)V

    goto :goto_3

    .line 826
    :cond_6
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    invoke-interface {v4, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lir/mahdi/mzip/rar/unpack/UnpackFilter;

    .line 827
    invoke-virtual {v3, p2}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setParentFilter(I)V

    .line 828
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getExecCount()I

    move-result v5

    add-int/2addr v5, v2

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setExecCount(I)V

    .line 831
    :goto_3
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v5, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 832
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getExecCount()I

    move-result v5

    invoke-virtual {v3, v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setExecCount(I)V

    .line 834
    invoke-static {p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result v5

    and-int/lit8 v6, p1, 0x40

    if-eqz v6, :cond_7

    add-int/lit16 v5, v5, 0x102

    .line 838
    :cond_7
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    add-int/2addr v6, v5

    const v7, 0x3fffff

    and-int/2addr v6, v7

    invoke-virtual {v3, v6}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setBlockStart(I)V

    and-int/lit8 v6, p1, 0x20

    if-eqz v6, :cond_8

    .line 840
    invoke-static {p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result v6

    invoke-virtual {v3, v6}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setBlockLength(I)V

    goto :goto_5

    .line 842
    :cond_8
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    .line 843
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge p2, v6, :cond_9

    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    .line 844
    invoke-interface {v6, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    goto :goto_4

    :cond_9
    const/4 v6, 0x0

    .line 843
    :goto_4
    invoke-virtual {v3, v6}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setBlockLength(I)V

    .line 847
    :goto_5
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    iget v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    if-eq v6, v8, :cond_a

    iget v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    iget v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    sub-int/2addr v6, v8

    and-int/2addr v6, v7

    if-gt v6, v5, :cond_a

    const/4 v5, 0x1

    goto :goto_6

    :cond_a
    const/4 v5, 0x0

    :goto_6
    invoke-virtual {v3, v5}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->setNextWindow(Z)V

    .line 853
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockLength()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, p2, v6}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 856
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object p2

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object p2

    invoke-static {p2, v0}, Ljava/util/Arrays;->fill([II)V

    .line 857
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object p2

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object p2

    const v5, 0x3c000

    const/4 v6, 0x3

    aput v5, p2, v6

    .line 858
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object p2

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object p2

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockLength()I

    move-result v5

    const/4 v7, 0x4

    aput v5, p2, v7

    .line 859
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object p2

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object p2

    const/4 v5, 0x5

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getExecCount()I

    move-result v7

    aput v7, p2, v5

    and-int/lit8 p2, p1, 0x10

    const/4 v5, 0x7

    if-eqz p2, :cond_c

    .line 864
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result p2

    ushr-int/lit8 p2, p2, 0x9

    .line 865
    invoke-virtual {p3, v5}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    const/4 v7, 0x0

    :goto_7
    if-ge v7, v5, :cond_c

    shl-int v8, v2, v7

    and-int/2addr v8, p2

    if-eqz v8, :cond_b

    .line 869
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v8

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object v8

    invoke-static {p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result v9

    aput v9, v8, v7

    :cond_b
    add-int/lit8 v7, v7, 0x1

    goto :goto_7

    :cond_c
    const/16 p2, 0x8

    if-eqz v1, :cond_11

    .line 875
    invoke-static {p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result v1

    const/high16 v7, 0x10000

    if-ge v1, v7, :cond_10

    if-nez v1, :cond_d

    goto :goto_9

    .line 879
    :cond_d
    new-array v7, v1, [B

    const/4 v8, 0x0

    :goto_8
    if-ge v8, v1, :cond_f

    .line 881
    invoke-virtual {p3, v6}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->Overflow(I)Z

    move-result v9

    if-eqz v9, :cond_e

    return v0

    .line 884
    :cond_e
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result v9

    shr-int/2addr v9, p2

    int-to-byte v9, v9

    aput-byte v9, v7, v8

    .line 885
    invoke-virtual {p3, p2}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_8

    .line 888
    :cond_f
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v9

    invoke-virtual {v8, v7, v1, v9}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->prepare([BILir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V

    goto :goto_a

    :cond_10
    :goto_9
    return v0

    .line 890
    :cond_11
    :goto_a
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v7

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmd()Ljava/util/List;

    move-result-object v7

    invoke-virtual {v1, v7}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setAltCmd(Ljava/util/List;)V

    .line 891
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v7

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getCmdCount()I

    move-result v7

    invoke-virtual {v1, v7}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setCmdCount(I)V

    .line 893
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getStaticData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    if-lez v1, :cond_12

    const/16 v7, 0x2000

    if-ge v1, v7, :cond_12

    .line 897
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getStaticData()Ljava/util/Vector;

    move-result-object v4

    invoke-virtual {v1, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->setStaticData(Ljava/util/Vector;)V

    .line 901
    :cond_12
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    const/16 v4, 0x40

    if-ge v1, v4, :cond_13

    .line 904
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Vector;->clear()V

    .line 905
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/util/Vector;->setSize(I)V

    .line 910
    :cond_13
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    const/4 v7, 0x0

    :goto_b
    if-ge v7, v5, :cond_14

    .line 912
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    mul-int/lit8 v9, v7, 0x4

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v10

    .line 913
    invoke-virtual {v10}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getInitR()[I

    move-result-object v10

    aget v10, v10, v7

    .line 912
    invoke-virtual {v8, v1, v9, v10}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_b

    .line 918
    :cond_14
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    const/16 v7, 0x1c

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getBlockLength()I

    move-result v8

    invoke-virtual {v5, v1, v7, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    .line 920
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    const/16 v7, 0x20

    invoke-virtual {v5, v1, v7, v0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    .line 921
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    const/16 v7, 0x24

    invoke-virtual {v5, v1, v7, v0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    .line 922
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    const/16 v7, 0x28

    invoke-virtual {v5, v1, v7, v0}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    .line 926
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->rarVM:Lir/mahdi/mzip/rar/unpack/vm/RarVM;

    const/16 v7, 0x2c

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getExecCount()I

    move-result v8

    invoke-virtual {v5, v1, v7, v8}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->setLowEndianValue(Ljava/util/Vector;II)V

    const/4 v5, 0x0

    :goto_c
    const/16 v7, 0x10

    if-ge v5, v7, :cond_15

    add-int/lit8 v7, v5, 0x30

    .line 929
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v8

    invoke-virtual {v1, v7, v8}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v5, v5, 0x1

    goto :goto_c

    :cond_15
    and-int/2addr p1, p2

    if-eqz p1, :cond_1a

    .line 933
    invoke-virtual {p3, v6}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->Overflow(I)Z

    move-result p1

    if-eqz p1, :cond_16

    return v0

    .line 936
    :cond_16
    invoke-static {p3}, Lir/mahdi/mzip/rar/unpack/vm/RarVM;->ReadData(Lir/mahdi/mzip/rar/unpack/vm/BitInput;)I

    move-result p1

    const/16 v1, 0x1fc0

    if-le p1, v1, :cond_17

    return v0

    .line 940
    :cond_17
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    add-int/lit8 v5, p1, 0x40

    if-ge v1, v5, :cond_18

    .line 943
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v7

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v7

    sub-int/2addr v5, v1

    invoke-virtual {v7, v5}, Ljava/util/Vector;->setSize(I)V

    .line 947
    :cond_18
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    move-result-object v1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;->getGlobalData()Ljava/util/Vector;

    move-result-object v1

    const/4 v3, 0x0

    :goto_d
    if-ge v3, p1, :cond_1a

    .line 949
    invoke-virtual {p3, v6}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->Overflow(I)Z

    move-result v5

    if-eqz v5, :cond_19

    return v0

    :cond_19
    add-int v5, v4, v3

    .line 953
    invoke-virtual {p3}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->fgetbits()I

    move-result v7

    ushr-int/2addr v7, p2

    int-to-byte v7, v7

    invoke-static {v7}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v7

    .line 952
    invoke-virtual {v1, v5, v7}, Ljava/util/Vector;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 954
    invoke-virtual {p3, p2}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;->faddbits(I)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    :cond_1a
    return v2

    :cond_1b
    :goto_e
    return v0
.end method

.method private copyString(II)V
    .locals 5

    .line 555
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    sub-int/2addr v0, p2

    if-ltz v0, :cond_0

    const p2, 0x3ffefc

    if-ge v0, p2, :cond_0

    .line 557
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    if-ge v1, p2, :cond_0

    .line 560
    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    add-int/lit8 v3, v0, 0x1

    aget-byte v0, v2, v0

    aput-byte v0, p2, v1

    :goto_0
    add-int/lit8 p1, p1, -0x1

    if-lez p1, :cond_1

    .line 564
    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    add-int/lit8 v2, v3, 0x1

    aget-byte v1, v1, v3

    aput-byte v1, p2, v0

    move v3, v2

    goto :goto_0

    :cond_0
    :goto_1
    add-int/lit8 p2, p1, -0x1

    if-eqz p1, :cond_1

    .line 567
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    add-int/lit8 v3, v0, 0x1

    const v4, 0x3fffff

    and-int/2addr v0, v4

    aget-byte v0, v2, v0

    aput-byte v0, p1, v1

    .line 568
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    add-int/lit8 p1, p1, 0x1

    and-int/2addr p1, v4

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    move p1, p2

    move v0, v3

    goto :goto_1

    :cond_1
    return-void
.end method

.method private initFilters()V
    .locals 1

    .line 598
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldFilterLengths:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v0, 0x0

    .line 599
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastFilter:I

    .line 601
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->filters:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 603
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prgStack:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    return-void
.end method

.method private insertLastMatch(II)V
    .locals 0

    .line 548
    iput p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastDist:I

    .line 549
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastLength:I

    return-void
.end method

.method private insertOldDist(I)V
    .locals 4

    .line 541
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    const/4 v2, 0x2

    aget v1, v1, v2

    const/4 v3, 0x3

    aput v1, v0, v3

    .line 542
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    const/4 v3, 0x1

    aget v1, v1, v3

    aput v1, v0, v2

    .line 543
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    const/4 v2, 0x0

    aget v1, v1, v2

    aput v1, v0, v3

    .line 544
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    aput p1, v0, v2

    return-void
.end method

.method private readEndOfBlock()Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 607
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v0

    const v1, 0x8000

    and-int/2addr v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    .line 611
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    const/4 v0, 0x1

    const/4 v1, 0x0

    goto :goto_1

    :cond_0
    and-int/lit16 v0, v0, 0x4000

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x2

    .line 615
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    const/4 v1, 0x1

    :goto_1
    xor-int/lit8 v4, v0, 0x1

    .line 617
    iput-boolean v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->tablesRead:Z

    if-nez v1, :cond_3

    if-eqz v0, :cond_2

    .line 618
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->readTables()Z

    move-result v0

    if-eqz v0, :cond_3

    :cond_2
    const/4 v2, 0x1

    :cond_3
    return v2
.end method

.method private readTables()Z
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    const/16 v0, 0x14

    .line 622
    new-array v1, v0, [B

    const/16 v2, 0x194

    .line 624
    new-array v3, v2, [B

    .line 625
    iget v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    iget v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readTop:I

    add-int/lit8 v5, v5, -0x19

    const/4 v6, 0x0

    if-le v4, v5, :cond_0

    .line 626
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpReadBuf()Z

    move-result v4

    if-nez v4, :cond_0

    return v6

    .line 630
    :cond_0
    iget v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inBit:I

    rsub-int/lit8 v4, v4, 0x8

    const/4 v5, 0x7

    and-int/2addr v4, v5

    invoke-virtual {p0, v4}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    .line 631
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v4

    and-int/lit8 v4, v4, -0x1

    int-to-long v7, v4

    const-wide/32 v9, 0x8000

    and-long/2addr v9, v7

    const-wide/16 v11, 0x0

    cmp-long v4, v9, v11

    if-eqz v4, :cond_1

    .line 633
    sget-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpBlockType:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    .line 634
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmEscChar:I

    invoke-virtual {v0, p0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeInit(Lir/mahdi/mzip/rar/unpack/Unpack;I)Z

    move-result v0

    return v0

    .line 636
    :cond_1
    sget-object v4, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_LZ:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    iput-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpBlockType:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    .line 638
    iput v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prevLowDist:I

    .line 639
    iput v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lowDistRepCount:I

    const-wide/16 v9, 0x4000

    and-long/2addr v7, v9

    cmp-long v4, v7, v11

    if-nez v4, :cond_2

    .line 642
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpOldTable:[B

    invoke-static {v4, v6}, Ljava/util/Arrays;->fill([BB)V

    :cond_2
    const/4 v4, 0x2

    .line 644
    invoke-virtual {p0, v4}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    const/4 v4, 0x0

    :goto_0
    const/16 v7, 0xf

    const/4 v8, 0x1

    if-ge v4, v0, :cond_6

    .line 647
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v9

    ushr-int/lit8 v9, v9, 0xc

    and-int/lit16 v9, v9, 0xff

    const/4 v10, 0x4

    .line 648
    invoke-virtual {p0, v10}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    if-ne v9, v7, :cond_5

    .line 650
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v9

    ushr-int/lit8 v9, v9, 0xc

    and-int/lit16 v9, v9, 0xff

    .line 651
    invoke-virtual {p0, v10}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    if-nez v9, :cond_3

    .line 653
    aput-byte v7, v1, v4

    goto :goto_2

    :cond_3
    add-int/lit8 v9, v9, 0x2

    :goto_1
    add-int/lit8 v7, v9, -0x1

    if-lez v9, :cond_4

    .line 656
    array-length v9, v1

    if-ge v4, v9, :cond_4

    add-int/lit8 v9, v4, 0x1

    .line 657
    aput-byte v6, v1, v4

    move v4, v9

    move v9, v7

    goto :goto_1

    :cond_4
    add-int/lit8 v4, v4, -0x1

    goto :goto_2

    :cond_5
    int-to-byte v7, v9

    .line 662
    aput-byte v7, v1, v4

    :goto_2
    add-int/2addr v4, v8

    goto :goto_0

    .line 666
    :cond_6
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->BD:Lir/mahdi/mzip/rar/unpack/decode/BitDecode;

    invoke-virtual {p0, v1, v6, v4, v0}, Lir/mahdi/mzip/rar/unpack/Unpack;->makeDecodeTables([BILir/mahdi/mzip/rar/unpack/decode/Decode;I)V

    const/4 v0, 0x0

    :cond_7
    :goto_3
    if-ge v0, v2, :cond_d

    .line 671
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    iget v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readTop:I

    add-int/lit8 v4, v4, -0x5

    if-le v1, v4, :cond_8

    .line 672
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpReadBuf()Z

    move-result v1

    if-nez v1, :cond_8

    return v6

    .line 676
    :cond_8
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->BD:Lir/mahdi/mzip/rar/unpack/decode/BitDecode;

    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack;->decodeNumber(Lir/mahdi/mzip/rar/unpack/decode/Decode;)I

    move-result v1

    const/16 v4, 0x10

    if-ge v1, v4, :cond_9

    .line 678
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpOldTable:[B

    aget-byte v4, v4, v0

    add-int/2addr v1, v4

    and-int/2addr v1, v7

    int-to-byte v1, v1

    aput-byte v1, v3, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_9
    const/16 v9, 0x12

    const/4 v10, 0x3

    if-ge v1, v9, :cond_b

    if-ne v1, v4, :cond_a

    .line 683
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v1

    ushr-int/lit8 v1, v1, 0xd

    add-int/2addr v1, v10

    .line 684
    invoke-virtual {p0, v10}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    goto :goto_4

    .line 686
    :cond_a
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v1

    ushr-int/lit8 v1, v1, 0x9

    add-int/lit8 v1, v1, 0xb

    .line 687
    invoke-virtual {p0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    :goto_4
    add-int/lit8 v4, v1, -0x1

    if-lez v1, :cond_7

    if-ge v0, v2, :cond_7

    add-int/lit8 v1, v0, -0x1

    .line 690
    aget-byte v1, v3, v1

    aput-byte v1, v3, v0

    add-int/lit8 v0, v0, 0x1

    move v1, v4

    goto :goto_4

    :cond_b
    const/16 v4, 0x12

    if-ne v1, v4, :cond_c

    .line 696
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v1

    ushr-int/lit8 v1, v1, 0xd

    add-int/2addr v1, v10

    .line 697
    invoke-virtual {p0, v10}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    goto :goto_5

    .line 699
    :cond_c
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->fgetbits()I

    move-result v1

    ushr-int/lit8 v1, v1, 0x9

    add-int/lit8 v1, v1, 0xb

    .line 700
    invoke-virtual {p0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->faddbits(I)V

    :goto_5
    add-int/lit8 v4, v1, -0x1

    if-lez v1, :cond_7

    if-ge v0, v2, :cond_7

    add-int/lit8 v1, v0, 0x1

    .line 703
    aput-byte v6, v3, v0

    move v0, v1

    move v1, v4

    goto :goto_5

    .line 707
    :cond_d
    iput-boolean v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->tablesRead:Z

    .line 708
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readTop:I

    if-le v0, v1, :cond_e

    return v6

    .line 711
    :cond_e
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->LD:Lir/mahdi/mzip/rar/unpack/decode/LitDecode;

    const/16 v1, 0x12b

    invoke-virtual {p0, v3, v6, v0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack;->makeDecodeTables([BILir/mahdi/mzip/rar/unpack/decode/Decode;I)V

    .line 712
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->DD:Lir/mahdi/mzip/rar/unpack/decode/DistDecode;

    const/16 v2, 0x3c

    invoke-virtual {p0, v3, v1, v0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack;->makeDecodeTables([BILir/mahdi/mzip/rar/unpack/decode/Decode;I)V

    const/16 v0, 0x167

    .line 713
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->LDD:Lir/mahdi/mzip/rar/unpack/decode/LowDistDecode;

    const/16 v2, 0x11

    invoke-virtual {p0, v3, v0, v1, v2}, Lir/mahdi/mzip/rar/unpack/Unpack;->makeDecodeTables([BILir/mahdi/mzip/rar/unpack/decode/Decode;I)V

    const/16 v0, 0x178

    .line 714
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->RD:Lir/mahdi/mzip/rar/unpack/decode/RepDecode;

    const/16 v2, 0x1c

    invoke-virtual {p0, v3, v0, v1, v2}, Lir/mahdi/mzip/rar/unpack/Unpack;->makeDecodeTables([BILir/mahdi/mzip/rar/unpack/decode/Decode;I)V

    .line 718
    :goto_6
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpOldTable:[B

    array-length v1, v0

    if-ge v6, v1, :cond_f

    .line 719
    aget-byte v1, v3, v6

    aput-byte v1, v0, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_6

    :cond_f
    return v8
.end method

.method private readVMCode()Z
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 726
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v0

    const/16 v1, 0x8

    shr-int/2addr v0, v1

    .line 727
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    and-int/lit8 v2, v0, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v3, 0x7

    if-ne v2, v3, :cond_0

    .line 730
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v2

    shr-int/2addr v2, v1

    add-int/2addr v2, v3

    .line 731
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    goto :goto_0

    :cond_0
    if-ne v2, v1, :cond_1

    .line 733
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v2

    const/16 v3, 0x10

    .line 734
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    .line 736
    :cond_1
    :goto_0
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v2, :cond_3

    .line 738
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    iget v7, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readTop:I

    add-int/lit8 v7, v7, -0x1

    if-lt v6, v7, :cond_2

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpReadBuf()Z

    move-result v6

    if-nez v6, :cond_2

    add-int/lit8 v6, v2, -0x1

    if-ge v5, v6, :cond_2

    return v4

    .line 741
    :cond_2
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v6

    shr-int/2addr v6, v1

    int-to-byte v6, v6

    invoke-static {v6}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v6

    invoke-interface {v3, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 742
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 744
    :cond_3
    invoke-direct {p0, v0, v3, v2}, Lir/mahdi/mzip/rar/unpack/Unpack;->addVMCode(ILjava/util/List;I)Z

    move-result v0

    return v0
.end method

.method private readVMCodePPM()Z
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 748
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    return v2

    :cond_0
    and-int/lit8 v3, v0, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v4, 0x7

    if-ne v3, v4, :cond_2

    .line 754
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v3

    if-ne v3, v1, :cond_1

    return v2

    :cond_1
    add-int/2addr v3, v4

    goto :goto_0

    :cond_2
    const/16 v4, 0x8

    if-ne v3, v4, :cond_5

    .line 760
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v3

    if-ne v3, v1, :cond_3

    return v2

    .line 764
    :cond_3
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v4

    if-ne v4, v1, :cond_4

    return v2

    :cond_4
    mul-int/lit16 v3, v3, 0x100

    add-int/2addr v3, v4

    .line 770
    :cond_5
    :goto_0
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v3, :cond_7

    .line 772
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v6}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v6

    if-ne v6, v1, :cond_6

    return v2

    :cond_6
    int-to-byte v6, v6

    .line 776
    invoke-static {v6}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v6

    invoke-interface {v4, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 778
    :cond_7
    invoke-direct {p0, v0, v4, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->addVMCode(ILjava/util/List;I)Z

    move-result v0

    return v0
.end method

.method private unpack29(Z)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    const/16 v0, 0x3c

    .line 120
    new-array v1, v0, [I

    .line 121
    new-array v0, v0, [B

    const/4 v2, 0x1

    .line 125
    aget v3, v1, v2

    const/4 v4, 0x0

    if-nez v3, :cond_1

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 127
    :goto_0
    sget-object v8, Lir/mahdi/mzip/rar/unpack/Unpack;->DBitLengthCounts:[I

    array-length v9, v8

    if-ge v3, v9, :cond_1

    .line 128
    aget v8, v8, v3

    move v9, v5

    const/4 v5, 0x0

    :goto_1
    if-ge v5, v8, :cond_0

    .line 130
    aput v9, v1, v7

    int-to-byte v10, v6

    .line 131
    aput-byte v10, v0, v7

    add-int/lit8 v5, v5, 0x1

    add-int/lit8 v7, v7, 0x1

    shl-int v10, v2, v6

    add-int/2addr v9, v10

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v6, v6, 0x1

    move v5, v9

    goto :goto_0

    .line 136
    :cond_1
    iput-boolean v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->fileExtracted:Z

    .line 138
    iget-boolean v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->suspended:Z

    if-nez v3, :cond_4

    .line 139
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpInitData(Z)V

    .line 140
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpReadBuf()Z

    move-result v3

    if-nez v3, :cond_2

    return-void

    :cond_2
    if-eqz p1, :cond_3

    .line 143
    iget-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->tablesRead:Z

    if-nez p1, :cond_4

    :cond_3
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->readTables()Z

    move-result p1

    if-nez p1, :cond_4

    return-void

    .line 148
    :cond_4
    iget-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmError:Z

    if-eqz p1, :cond_5

    return-void

    .line 153
    :cond_5
    :goto_2
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    const v3, 0x3fffff

    and-int/2addr p1, v3

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    .line 155
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    iget v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readBorder:I

    if-le p1, v5, :cond_6

    .line 156
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpReadBuf()Z

    move-result p1

    if-nez p1, :cond_6

    goto/16 :goto_7

    .line 162
    :cond_6
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    iget v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    sub-int/2addr p1, v5

    and-int/2addr p1, v3

    const/16 v3, 0x104

    if-ge p1, v3, :cond_8

    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    if-eq p1, v3, :cond_8

    .line 165
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteBuf()V

    .line 166
    iget-wide v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    iget-wide v7, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    cmp-long p1, v5, v7

    if-lez p1, :cond_7

    return-void

    .line 169
    :cond_7
    iget-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->suspended:Z

    if-eqz p1, :cond_8

    .line 170
    iput-boolean v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->fileExtracted:Z

    return-void

    .line 174
    :cond_8
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpBlockType:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    sget-object v3, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-ne p1, v3, :cond_14

    .line 175
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result p1

    const/4 v3, -0x1

    if-ne p1, v3, :cond_9

    .line 177
    iput-boolean v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmError:Z

    goto/16 :goto_7

    .line 180
    :cond_9
    iget v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmEscChar:I

    if-ne p1, v8, :cond_13

    .line 181
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v8

    if-nez v8, :cond_a

    .line 183
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->readTables()Z

    move-result p1

    if-nez p1, :cond_5

    goto/16 :goto_7

    :cond_a
    if-eq v8, v6, :cond_1f

    if-ne v8, v3, :cond_b

    goto/16 :goto_7

    :cond_b
    if-ne v8, v5, :cond_c

    .line 192
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->readVMCodePPM()Z

    move-result p1

    if-nez p1, :cond_5

    goto/16 :goto_7

    :cond_c
    if-ne v8, v7, :cond_11

    const/4 p1, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    :goto_3
    if-ge p1, v7, :cond_f

    if-nez v6, :cond_f

    .line 201
    iget-object v10, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {v10}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result v10

    if-ne v10, v3, :cond_d

    const/4 v6, 0x1

    goto :goto_4

    :cond_d
    if-ne p1, v5, :cond_e

    and-int/lit16 v9, v10, 0xff

    goto :goto_4

    :cond_e
    shl-int/lit8 v8, v8, 0x8

    and-int/lit16 v10, v10, 0xff

    add-int/2addr v8, v10

    :goto_4
    add-int/lit8 p1, p1, 0x1

    goto :goto_3

    :cond_f
    if-eqz v6, :cond_10

    goto/16 :goto_7

    :cond_10
    add-int/lit8 v9, v9, 0x20

    add-int/lit8 v8, v8, 0x2

    .line 217
    invoke-direct {p0, v9, v8}, Lir/mahdi/mzip/rar/unpack/Unpack;->copyString(II)V

    goto/16 :goto_2

    :cond_11
    const/4 v5, 0x5

    if-ne v8, v5, :cond_13

    .line 221
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->decodeChar()I

    move-result p1

    if-ne p1, v3, :cond_12

    goto/16 :goto_7

    :cond_12
    add-int/lit8 p1, p1, 0x4

    .line 225
    invoke-direct {p0, p1, v2}, Lir/mahdi/mzip/rar/unpack/Unpack;->copyString(II)V

    goto/16 :goto_2

    .line 229
    :cond_13
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    iget v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    add-int/lit8 v6, v5, 0x1

    iput v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    int-to-byte p1, p1

    aput-byte p1, v3, v5

    goto/16 :goto_2

    .line 233
    :cond_14
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->LD:Lir/mahdi/mzip/rar/unpack/decode/LitDecode;

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->decodeNumber(Lir/mahdi/mzip/rar/unpack/decode/Decode;)I

    move-result p1

    const/16 v3, 0x100

    if-ge p1, v3, :cond_15

    .line 235
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    iget v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    add-int/lit8 v6, v5, 0x1

    iput v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    int-to-byte p1, p1

    aput-byte p1, v3, v5

    goto/16 :goto_2

    :cond_15
    const/16 v8, 0x10f

    const/16 v9, 0x10

    if-lt p1, v8, :cond_1d

    .line 239
    sget-object v3, Lir/mahdi/mzip/rar/unpack/Unpack;->LDecode:[I

    add-int/lit16 p1, p1, -0x10f

    aget v3, v3, p1

    add-int/2addr v3, v5

    .line 240
    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack;->LBits:[B

    aget-byte p1, v5, p1

    if-lez p1, :cond_16

    .line 241
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v5

    rsub-int/lit8 v6, p1, 0x10

    ushr-int/2addr v5, v6

    add-int/2addr v3, v5

    .line 242
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    .line 245
    :cond_16
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->DD:Lir/mahdi/mzip/rar/unpack/decode/DistDecode;

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->decodeNumber(Lir/mahdi/mzip/rar/unpack/decode/Decode;)I

    move-result p1

    .line 246
    aget v5, v1, p1

    add-int/2addr v5, v2

    .line 247
    aget-byte v6, v0, p1

    if-lez v6, :cond_1b

    const/16 v8, 0x9

    if-le p1, v8, :cond_1a

    if-le v6, v7, :cond_17

    .line 250
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result p1

    rsub-int/lit8 v8, v6, 0x14

    ushr-int/2addr p1, v8

    shl-int/2addr p1, v7

    add-int/2addr v5, p1

    add-int/lit8 v6, v6, -0x4

    .line 251
    invoke-virtual {p0, v6}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    .line 253
    :cond_17
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lowDistRepCount:I

    if-lez p1, :cond_18

    add-int/lit8 p1, p1, -0x1

    .line 254
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lowDistRepCount:I

    .line 255
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prevLowDist:I

    :goto_5
    add-int/2addr v5, p1

    goto :goto_6

    .line 257
    :cond_18
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->LDD:Lir/mahdi/mzip/rar/unpack/decode/LowDistDecode;

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->decodeNumber(Lir/mahdi/mzip/rar/unpack/decode/Decode;)I

    move-result p1

    if-ne p1, v9, :cond_19

    const/16 p1, 0xf

    .line 259
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lowDistRepCount:I

    .line 260
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prevLowDist:I

    goto :goto_5

    :cond_19
    add-int/2addr v5, p1

    .line 263
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->prevLowDist:I

    goto :goto_6

    .line 267
    :cond_1a
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result p1

    sub-int/2addr v9, v6

    ushr-int/2addr p1, v9

    add-int/2addr v5, p1

    .line 268
    invoke-virtual {p0, v6}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    :cond_1b
    :goto_6
    const/16 p1, 0x2000

    if-lt v5, p1, :cond_1c

    add-int/lit8 v3, v3, 0x1

    int-to-long v6, v5

    const-wide/32 v8, 0x40000

    cmp-long p1, v6, v8

    if-ltz p1, :cond_1c

    add-int/lit8 v3, v3, 0x1

    .line 279
    :cond_1c
    invoke-direct {p0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->insertOldDist(I)V

    .line 280
    invoke-direct {p0, v3, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->insertLastMatch(II)V

    .line 282
    invoke-direct {p0, v3, v5}, Lir/mahdi/mzip/rar/unpack/Unpack;->copyString(II)V

    goto/16 :goto_2

    :cond_1d
    if-ne p1, v3, :cond_1e

    .line 286
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->readEndOfBlock()Z

    move-result p1

    if-nez p1, :cond_5

    goto :goto_7

    :cond_1e
    const/16 v3, 0x101

    if-ne p1, v3, :cond_20

    .line 292
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->readVMCode()Z

    move-result p1

    if-nez p1, :cond_5

    .line 333
    :cond_1f
    :goto_7
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->UnpWriteBuf()V

    return-void

    :cond_20
    const/16 v3, 0x102

    if-ne p1, v3, :cond_21

    .line 298
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastLength:I

    if-eqz p1, :cond_5

    .line 299
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastLength:I

    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastDist:I

    invoke-direct {p0, p1, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->copyString(II)V

    goto/16 :goto_2

    :cond_21
    const/16 v3, 0x107

    if-ge p1, v3, :cond_24

    add-int/lit16 p1, p1, -0x103

    .line 305
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    aget v3, v3, p1

    :goto_8
    if-lez p1, :cond_22

    .line 307
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    iget-object v7, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    add-int/lit8 v8, p1, -0x1

    aget v7, v7, v8

    aput v7, v5, p1

    add-int/lit8 p1, p1, -0x1

    goto :goto_8

    .line 309
    :cond_22
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    aput v3, p1, v4

    .line 311
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->RD:Lir/mahdi/mzip/rar/unpack/decode/RepDecode;

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->decodeNumber(Lir/mahdi/mzip/rar/unpack/decode/Decode;)I

    move-result p1

    .line 312
    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack;->LDecode:[I

    aget v5, v5, p1

    add-int/2addr v5, v6

    .line 313
    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack;->LBits:[B

    aget-byte p1, v6, p1

    if-lez p1, :cond_23

    .line 314
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v6

    sub-int/2addr v9, p1

    ushr-int/2addr v6, v9

    add-int/2addr v5, v6

    .line 315
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    .line 317
    :cond_23
    invoke-direct {p0, v5, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->insertLastMatch(II)V

    .line 318
    invoke-direct {p0, v5, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->copyString(II)V

    goto/16 :goto_2

    :cond_24
    const/16 v3, 0x110

    if-ge p1, v3, :cond_5

    .line 322
    sget-object v3, Lir/mahdi/mzip/rar/unpack/Unpack;->SDDecode:[I

    add-int/lit16 p1, p1, -0x107

    aget v3, v3, p1

    add-int/2addr v3, v2

    .line 323
    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack;->SDBits:[I

    aget p1, v5, p1

    if-lez p1, :cond_25

    .line 324
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->getbits()I

    move-result v5

    sub-int/2addr v9, p1

    ushr-int/2addr v5, v9

    add-int/2addr v3, v5

    .line 325
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->addbits(I)V

    .line 327
    :cond_25
    invoke-direct {p0, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->insertOldDist(I)V

    .line 328
    invoke-direct {p0, v6, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->insertLastMatch(II)V

    .line 329
    invoke-direct {p0, v6, v3}, Lir/mahdi/mzip/rar/unpack/Unpack;->copyString(II)V

    goto/16 :goto_2
.end method

.method private unstoreFile()V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    const/high16 v0, 0x10000

    .line 104
    new-array v0, v0, [B

    .line 106
    :cond_0
    :goto_0
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    array-length v2, v0

    int-to-long v2, v2

    iget-wide v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    long-to-int v3, v2

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2, v3}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpRead([BII)I

    move-result v1

    if-eqz v1, :cond_3

    const/4 v3, -0x1

    if-ne v1, v3, :cond_1

    goto :goto_2

    :cond_1
    int-to-long v3, v1

    .line 110
    iget-wide v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    cmp-long v7, v3, v5

    if-gez v7, :cond_2

    goto :goto_1

    :cond_2
    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    long-to-int v1, v3

    .line 111
    :goto_1
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {v3, v0, v2, v1}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpWrite([BII)V

    .line 112
    iget-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-ltz v6, :cond_0

    .line 113
    iget-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    int-to-long v4, v1

    sub-long/2addr v2, v4

    iput-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    goto :goto_0

    :cond_3
    :goto_2
    return-void
.end method


# virtual methods
.method public cleanUp()V
    .locals 1

    .line 1022
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppm:Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;

    if-eqz v0, :cond_0

    .line 1023
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 1025
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->stopSubAllocator()V

    :cond_0
    return-void
.end method

.method public doUnpack(IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 85
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->getSubHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpMethod()B

    move-result v0

    const/16 v1, 0x30

    if-ne v0, v1, :cond_0

    .line 86
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unstoreFile()V

    :cond_0
    const/16 v0, 0xf

    if-eq p1, v0, :cond_3

    const/16 v0, 0x14

    if-eq p1, v0, :cond_2

    const/16 v0, 0x1a

    if-eq p1, v0, :cond_2

    const/16 v0, 0x1d

    if-eq p1, v0, :cond_1

    const/16 v0, 0x24

    if-eq p1, v0, :cond_1

    goto :goto_0

    .line 98
    :cond_1
    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpack29(Z)V

    goto :goto_0

    .line 94
    :cond_2
    invoke-virtual {p0, p2}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpack20(Z)V

    goto :goto_0

    .line 90
    :cond_3
    invoke-virtual {p0, p2}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpack15(Z)V

    :goto_0
    return-void
.end method

.method public getChar()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 1007
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    const/16 v1, 0x7fe2

    if-le v0, v1, :cond_0

    .line 1008
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpReadBuf()Z

    .line 1010
    :cond_0
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inBuf:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    return v0
.end method

.method public getPpmEscChar()I
    .locals 1

    .line 1014
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmEscChar:I

    return v0
.end method

.method public init([B)V
    .locals 0

    if-nez p1, :cond_0

    const/high16 p1, 0x400000

    .line 74
    new-array p1, p1, [B

    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    goto :goto_0

    .line 76
    :cond_0
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->window:[B

    const/4 p1, 0x1

    .line 77
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->externalWindow:Z

    :goto_0
    const/4 p1, 0x0

    .line 79
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->inAddr:I

    .line 80
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpInitData(Z)V

    return-void
.end method

.method public isFileExtracted()Z
    .locals 1

    .line 994
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->fileExtracted:Z

    return v0
.end method

.method public setDestSize(J)V
    .locals 0

    .line 998
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->destUnpSize:J

    const/4 p1, 0x0

    .line 999
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->fileExtracted:Z

    return-void
.end method

.method public setPpmEscChar(I)V
    .locals 0

    .line 1018
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmEscChar:I

    return-void
.end method

.method public setSuspended(Z)V
    .locals 0

    .line 1003
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->suspended:Z

    return-void
.end method

.method protected unpInitData(Z)V
    .locals 3

    const/4 v0, 0x0

    if-nez p1, :cond_0

    .line 574
    iput-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->tablesRead:Z

    .line 575
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDist:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([II)V

    .line 577
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->oldDistPtr:I

    .line 578
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastDist:I

    .line 579
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->lastLength:I

    .line 581
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpOldTable:[B

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([BB)V

    .line 583
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->unpPtr:I

    .line 584
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->wrPtr:I

    const/4 v1, 0x2

    .line 585
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmEscChar:I

    .line 587
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->initFilters()V

    .line 589
    :cond_0
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack;->InitBitInput()V

    .line 590
    iput-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->ppmError:Z

    const-wide/16 v1, 0x0

    .line 591
    iput-wide v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->writtenFileSize:J

    .line 592
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readTop:I

    .line 593
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack;->readBorder:I

    .line 594
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->unpInitData20(Z)V

    return-void
.end method
