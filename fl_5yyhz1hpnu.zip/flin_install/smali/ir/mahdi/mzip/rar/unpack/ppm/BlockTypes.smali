.class public final enum Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;
.super Ljava/lang/Enum;
.source "BlockTypes.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

.field public static final enum BLOCK_LZ:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

.field public static final enum BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;


# instance fields
.field private blockType:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    const/4 v1, 0x0

    const-string v2, "BLOCK_LZ"

    invoke-direct {v0, v2, v1, v1}, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_LZ:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    const/4 v2, 0x1

    const-string v3, "BLOCK_PPM"

    invoke-direct {v0, v3, v2, v2}, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    const/4 v0, 0x2

    .line 21
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    sget-object v3, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_LZ:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    aput-object v3, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    aput-object v1, v0, v2

    sput-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->$VALUES:[Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 26
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 27
    iput p3, p0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->blockType:I

    return-void
.end method

.method public static findBlockType(I)Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;
    .locals 1

    .line 31
    sget-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_LZ:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 32
    sget-object p0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_LZ:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    return-object p0

    .line 34
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->equals(I)Z

    move-result p0

    if-eqz p0, :cond_1

    .line 35
    sget-object p0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->BLOCK_PPM:Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;
    .locals 1

    .line 21
    const-class v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;
    .locals 1

    .line 21
    sget-object v0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->$VALUES:[Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;

    return-object v0
.end method


# virtual methods
.method public equals(I)Z
    .locals 1

    .line 45
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->blockType:I

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getBlockType()I
    .locals 1

    .line 41
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/BlockTypes;->blockType:I

    return v0
.end method
