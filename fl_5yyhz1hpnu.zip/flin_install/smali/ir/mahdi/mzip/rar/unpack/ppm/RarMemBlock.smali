.class public Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;
.super Lir/mahdi/mzip/rar/unpack/ppm/Pointer;
.source "RarMemBlock.java"


# static fields
.field public static final size:I = 0xc


# instance fields
.field private NU:I

.field private next:I

.field private prev:I

.field private stamp:I


# direct methods
.method public constructor <init>([B)V
    .locals 0

    .line 32
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;-><init>([B)V

    return-void
.end method


# virtual methods
.method public getNU()I
    .locals 2

    .line 74
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 75
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    add-int/lit8 v1, v1, 0x2

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    const v1, 0xffff

    and-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->NU:I

    .line 77
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->NU:I

    return v0
.end method

.method public getNext()I
    .locals 2

    .line 56
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 57
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    add-int/lit8 v1, v1, 0x4

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v0

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->next:I

    .line 59
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->next:I

    return v0
.end method

.method public getPrev()I
    .locals 2

    .line 88
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 89
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    add-int/lit8 v1, v1, 0x8

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v0

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->prev:I

    .line 91
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->prev:I

    return v0
.end method

.method public getStamp()I
    .locals 2

    .line 106
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 107
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    const v1, 0xffff

    and-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->stamp:I

    .line 109
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->stamp:I

    return v0
.end method

.method public insertAt(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V
    .locals 2

    .line 36
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;-><init>([B)V

    .line 37
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setPrev(I)V

    .line 38
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getPrev()I

    move-result p1

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 39
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNext(I)V

    .line 40
    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNext(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V

    .line 41
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result p1

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 42
    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setPrev(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V

    return-void
.end method

.method public remove()V
    .locals 2

    .line 46
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;-><init>([B)V

    .line 47
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getPrev()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 48
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNext(I)V

    .line 49
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 50
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getPrev()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setPrev(I)V

    return-void
.end method

.method public setNU(I)V
    .locals 2

    const v0, 0xffff

    and-int/2addr v0, p1

    .line 81
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->NU:I

    .line 82
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 83
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    add-int/lit8 v1, v1, 0x2

    int-to-short p1, p1

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    :cond_0
    return-void
.end method

.method public setNext(I)V
    .locals 2

    .line 63
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->next:I

    .line 64
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 65
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    add-int/lit8 v1, v1, 0x4

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    :cond_0
    return-void
.end method

.method public setNext(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V
    .locals 0

    .line 70
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNext(I)V

    return-void
.end method

.method public setPrev(I)V
    .locals 2

    .line 95
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->prev:I

    .line 96
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 97
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    add-int/lit8 v1, v1, 0x8

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    :cond_0
    return-void
.end method

.method public setPrev(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V
    .locals 0

    .line 102
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setPrev(I)V

    return-void
.end method

.method public setStamp(I)V
    .locals 2

    .line 113
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->stamp:I

    .line 114
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    if-eqz v0, :cond_0

    .line 115
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->pos:I

    int-to-short p1, p1

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    :cond_0
    return-void
.end method
