.class public Lir/mahdi/mzip/rar/unpack/decode/DistDecode;
.super Lir/mahdi/mzip/rar/unpack/decode/Decode;
.source "DistDecode.java"


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 22
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/decode/Decode;-><init>()V

    const/16 v0, 0x3c

    .line 23
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/decode/DistDecode;->decodeNum:[I

    return-void
.end method
