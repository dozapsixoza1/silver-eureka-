.class public Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;
.super Ljava/lang/Object;
.source "SEE2Context.java"


# static fields
.field public static final size:I = 0x4


# instance fields
.field private count:I

.field private shift:I

.field private summ:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 55
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    return v0
.end method

.method public getMean()I
    .locals 2

    .line 39
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    ushr-int v1, v0, v1

    sub-int/2addr v0, v1

    .line 40
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    if-nez v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    add-int/2addr v1, v0

    return v1
.end method

.method public getShift()I
    .locals 1

    .line 63
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    return v0
.end method

.method public getSumm()I
    .locals 1

    .line 71
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    return v0
.end method

.method public incSumm(I)V
    .locals 1

    .line 79
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->getSumm()I

    move-result v0

    add-int/2addr v0, p1

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->setSumm(I)V

    return-void
.end method

.method public init(I)V
    .locals 1

    const/4 v0, 0x3

    .line 33
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    .line 34
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    shl-int/2addr p1, v0

    const v0, 0xffff

    and-int/2addr p1, v0

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    const/4 p1, 0x4

    .line 35
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    return-void
.end method

.method public setCount(I)V
    .locals 0

    and-int/lit16 p1, p1, 0xff

    .line 59
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    return-void
.end method

.method public setShift(I)V
    .locals 0

    and-int/lit16 p1, p1, 0xff

    .line 67
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    return-void
.end method

.method public setSumm(I)V
    .locals 1

    const v0, 0xffff

    and-int/2addr p1, v0

    .line 75
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 83
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SEE2Context["

    .line 84
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  size="

    .line 85
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    .line 86
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  summ="

    .line 87
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  shift="

    .line 89
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  count="

    .line 91
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 92
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 93
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public update()V
    .locals 3

    .line 45
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    const/4 v1, 0x7

    if-ge v0, v1, :cond_0

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    if-nez v1, :cond_0

    .line 46
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    add-int/2addr v1, v1

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    const/4 v1, 0x3

    add-int/lit8 v2, v0, 0x1

    .line 47
    iput v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    shl-int v0, v1, v0

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    .line 49
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    const v1, 0xffff

    and-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->summ:I

    .line 50
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    and-int/lit16 v0, v0, 0xff

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->count:I

    .line 51
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    and-int/lit16 v0, v0, 0xff

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->shift:I

    return-void
.end method
