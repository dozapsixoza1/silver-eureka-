.class public final enum Lir/mahdi/mzip/rar/unpack/decode/CodeType;
.super Ljava/lang/Enum;
.source "CodeType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/decode/CodeType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_CACHELZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_ENDFILE:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_HUFFMAN:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_LZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_LZ2:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_REPEATLZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_STARTFILE:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_VM:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

.field public static final enum CODE_VMDATA:Lir/mahdi/mzip/rar/unpack/decode/CodeType;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    .line 18
    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v1, 0x0

    const-string v2, "CODE_HUFFMAN"

    invoke-direct {v0, v2, v1}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_HUFFMAN:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v2, 0x1

    const-string v3, "CODE_LZ"

    invoke-direct {v0, v3, v2}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_LZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v3, 0x2

    const-string v4, "CODE_LZ2"

    invoke-direct {v0, v4, v3}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_LZ2:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v4, 0x3

    const-string v5, "CODE_REPEATLZ"

    invoke-direct {v0, v5, v4}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_REPEATLZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v5, 0x4

    const-string v6, "CODE_CACHELZ"

    invoke-direct {v0, v6, v5}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_CACHELZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    .line 19
    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v6, 0x5

    const-string v7, "CODE_STARTFILE"

    invoke-direct {v0, v7, v6}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_STARTFILE:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v7, 0x6

    const-string v8, "CODE_ENDFILE"

    invoke-direct {v0, v8, v7}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_ENDFILE:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/4 v8, 0x7

    const-string v9, "CODE_VM"

    invoke-direct {v0, v9, v8}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_VM:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/16 v9, 0x8

    const-string v10, "CODE_VMDATA"

    invoke-direct {v0, v10, v9}, Lir/mahdi/mzip/rar/unpack/decode/CodeType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_VMDATA:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    const/16 v0, 0x9

    .line 17
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    sget-object v10, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_HUFFMAN:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v10, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_LZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_LZ2:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_REPEATLZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_CACHELZ:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_STARTFILE:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v6

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_ENDFILE:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v7

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_VM:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v8

    sget-object v1, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->CODE_VMDATA:Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    aput-object v1, v0, v9

    sput-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->$VALUES:[Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 17
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/decode/CodeType;
    .locals 1

    .line 17
    const-class v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/decode/CodeType;
    .locals 1

    .line 17
    sget-object v0, Lir/mahdi/mzip/rar/unpack/decode/CodeType;->$VALUES:[Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/decode/CodeType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/decode/CodeType;

    return-object v0
.end method
