.class public Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;
.super Ljava/lang/Object;
.source "SubAllocator.java"


# static fields
.field static final synthetic $assertionsDisabled:Z = false

.field public static final FIXED_UNIT_SIZE:I = 0xc

.field public static final N1:I = 0x4

.field public static final N2:I = 0x4

.field public static final N3:I = 0x4

.field public static final N4:I = 0x1a

.field public static final N_INDEXES:I = 0x26

.field public static final UNIT_SIZE:I


# instance fields
.field private fakeUnitsStart:I

.field private final freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

.field private freeListPos:I

.field private glueCount:I

.field private heap:[B

.field private heapEnd:I

.field private heapStart:I

.field private hiUnit:I

.field private indx2Units:[I

.field private loUnit:I

.field private pText:I

.field private subAllocatorSize:I

.field private tempMemBlockPos:I

.field private tempRarMemBlock1:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

.field private tempRarMemBlock2:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

.field private tempRarMemBlock3:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

.field private tempRarNode:Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

.field private units2Indx:[I

.field private unitsStart:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 28
    sget v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->size:I

    const/16 v1, 0xc

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    sput v0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->UNIT_SIZE:I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 55
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x26

    .line 32
    new-array v1, v0, [Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    .line 35
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    const/16 v0, 0x80

    .line 36
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    const/4 v0, 0x0

    .line 50
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarNode:Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    .line 51
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock1:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 52
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock2:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 53
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock3:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 56
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->clean()V

    return-void
.end method

.method private MBPtr(II)I
    .locals 0

    .line 88
    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result p2

    add-int/2addr p1, p2

    return p1
.end method

.method private U2B(I)I
    .locals 1

    .line 83
    sget v0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->UNIT_SIZE:I

    mul-int v0, v0, p1

    return v0
.end method

.method private allocUnitsRare(I)I
    .locals 3

    .line 206
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueCount:I

    if-nez v0, :cond_0

    const/16 v0, 0xff

    .line 207
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueCount:I

    .line 208
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueFreeBlocks()V

    .line 209
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v0, v0, p1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v0

    if-eqz v0, :cond_0

    .line 210
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->removeNode(I)I

    move-result p1

    return p1

    :cond_0
    move v0, p1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    const/16 v1, 0x26

    if-ne v0, v1, :cond_3

    .line 216
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueCount:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueCount:I

    .line 217
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget v0, v0, p1

    invoke-direct {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result v0

    .line 218
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget p1, v1, p1

    mul-int/lit8 p1, p1, 0xc

    .line 219
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->fakeUnitsStart:I

    iget v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    sub-int v2, v1, v2

    if-le v2, p1, :cond_2

    sub-int/2addr v1, p1

    .line 220
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->fakeUnitsStart:I

    .line 221
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    sub-int/2addr p1, v0

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    .line 222
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    return p1

    :cond_2
    const/4 p1, 0x0

    return p1

    .line 226
    :cond_3
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v1

    if-eqz v1, :cond_1

    .line 227
    invoke-direct {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->removeNode(I)I

    move-result v1

    .line 228
    invoke-direct {p0, v1, v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->splitBlock(III)V

    return v1
.end method

.method private glueFreeBlocks()V
    .locals 6

    .line 160
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock1:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 161
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempMemBlockPos:I

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 162
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock2:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 163
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock3:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 165
    iget v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    iget v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    const/4 v5, 0x0

    if-eq v3, v4, :cond_0

    .line 166
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    aput-byte v5, v4, v3

    .line 168
    :cond_0
    invoke-virtual {v0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setPrev(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V

    invoke-virtual {v0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNext(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V

    :goto_0
    const/16 v3, 0x26

    const v4, 0xffff

    if-ge v5, v3, :cond_2

    .line 169
    :goto_1
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v3, v3, v5

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v3

    if-eqz v3, :cond_1

    .line 170
    invoke-direct {p0, v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->removeNode(I)I

    move-result v3

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 171
    invoke-virtual {v1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->insertAt(Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;)V

    .line 172
    invoke-virtual {v1, v4}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setStamp(I)V

    .line 173
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget v3, v3, v5

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNU(I)V

    goto :goto_1

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 176
    :cond_2
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result v3

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    :goto_2
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v3

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v5

    if-eq v3, v5, :cond_4

    .line 181
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v3

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v5

    invoke-direct {p0, v3, v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->MBPtr(II)I

    move-result v3

    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 182
    :goto_3
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getStamp()I

    move-result v3

    if-ne v3, v4, :cond_3

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v3

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v5

    add-int/2addr v3, v5

    const/high16 v5, 0x10000

    if-ge v3, v5, :cond_3

    .line 183
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->remove()V

    .line 184
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v3

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v5

    add-int/2addr v3, v5

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setNU(I)V

    .line 185
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v3

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v5

    invoke-direct {p0, v3, v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->MBPtr(II)I

    move-result v3

    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    goto :goto_3

    .line 177
    :cond_3
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result v3

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    goto :goto_2

    .line 190
    :cond_4
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    .line 191
    :goto_4
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v2

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v3

    if-eq v2, v3, :cond_7

    .line 192
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->remove()V

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNU()I

    move-result v2

    :goto_5
    const/16 v3, 0x80

    if-le v2, v3, :cond_5

    .line 194
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v4

    const/16 v5, 0x25

    invoke-direct {p0, v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    add-int/lit8 v2, v2, -0x80

    .line 193
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v4

    invoke-direct {p0, v4, v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->MBPtr(II)I

    move-result v3

    invoke-virtual {v1, v3}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    goto :goto_5

    .line 196
    :cond_5
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 v5, v2, -0x1

    aget v4, v4, v5

    aget v5, v3, v4

    if-eq v5, v2, :cond_6

    add-int/lit8 v4, v4, -0x1

    .line 197
    aget v3, v3, v4

    sub-int v3, v2, v3

    .line 198
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v5

    sub-int/2addr v2, v3

    invoke-direct {p0, v5, v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->MBPtr(II)I

    move-result v2

    add-int/lit8 v3, v3, -0x1

    invoke-direct {p0, v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    .line 200
    :cond_6
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getAddress()I

    move-result v2

    invoke-direct {p0, v2, v4}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    .line 201
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->getNext()I

    move-result v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;->setAddress(I)V

    goto :goto_4

    :cond_7
    return-void
.end method

.method private insertNode(II)V
    .locals 1

    .line 64
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarNode:Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    .line 65
    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setAddress(I)V

    .line 66
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object p1, p1, p2

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result p1

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setNext(I)V

    .line 67
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object p1, p1, p2

    invoke-virtual {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setNext(Lir/mahdi/mzip/rar/unpack/ppm/RarNode;)V

    return-void
.end method

.method private removeNode(I)I
    .locals 3

    .line 75
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v0, v0, p1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v0

    .line 76
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarNode:Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    .line 77
    invoke-virtual {v1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setAddress(I)V

    .line 78
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object p1, v2, p1

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v1

    invoke-virtual {p1, v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setNext(I)V

    return v0
.end method

.method private sizeOfFreeList()I
    .locals 1

    .line 369
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    array-length v0, v0

    mul-int/lit8 v0, v0, 0x4

    return v0
.end method

.method private splitBlock(III)V
    .locals 2

    .line 92
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget p2, v0, p2

    aget v1, v0, p3

    sub-int/2addr p2, v1

    .line 93
    aget p3, v0, p3

    invoke-direct {p0, p3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result p3

    add-int/2addr p1, p3

    .line 94
    iget-object p3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 v1, p2, -0x1

    aget v0, v0, v1

    aget p3, p3, v0

    if-eq p3, p2, :cond_0

    add-int/lit8 v0, v0, -0x1

    .line 95
    invoke-direct {p0, p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    .line 96
    iget-object p3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget p3, p3, v0

    invoke-direct {p0, p3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result v0

    add-int/2addr p1, v0

    sub-int/2addr p2, p3

    .line 99
    :cond_0
    iget-object p3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 p2, p2, -0x1

    aget p2, p3, p2

    invoke-direct {p0, p1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    return-void
.end method


# virtual methods
.method public GetAllocatedMemory()I
    .locals 1

    .line 117
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    return v0
.end method

.method public allocContext()I
    .locals 2

    .line 247
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    if-eq v0, v1, :cond_0

    .line 248
    sget v1, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->UNIT_SIZE:I

    sub-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    return v0

    .line 249
    :cond_0
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v0

    if-eqz v0, :cond_1

    .line 250
    invoke-direct {p0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->removeNode(I)I

    move-result v0

    return v0

    .line 252
    :cond_1
    invoke-direct {p0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocUnitsRare(I)I

    move-result v0

    return v0
.end method

.method public allocUnits(I)I
    .locals 3

    .line 233
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 p1, p1, -0x1

    aget p1, v0, p1

    .line 234
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v0, v0, p1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v0

    if-eqz v0, :cond_0

    .line 235
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->removeNode(I)I

    move-result p1

    return p1

    .line 237
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    .line 238
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget v1, v1, p1

    invoke-direct {p0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    .line 239
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    iget v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    if-gt v1, v2, :cond_1

    return v0

    .line 242
    :cond_1
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget v0, v0, p1

    invoke-direct {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result v0

    sub-int/2addr v1, v0

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    .line 243
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocUnitsRare(I)I

    move-result p1

    return p1
.end method

.method public clean()V
    .locals 1

    const/4 v0, 0x0

    .line 60
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    return-void
.end method

.method public decPText(I)V
    .locals 1

    .line 318
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v0

    sub-int/2addr v0, p1

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->setPText(I)V

    return-void
.end method

.method public expandUnits(II)I
    .locals 3

    .line 256
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 v1, p2, -0x1

    aget v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    .line 257
    aget v0, v0, v1

    if-ne v2, v0, :cond_0

    return p1

    :cond_0
    add-int/lit8 v0, p2, 0x1

    .line 261
    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocUnits(I)I

    move-result v0

    if-eqz v0, :cond_1

    .line 264
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {p0, p2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result p2

    invoke-static {v1, p1, v1, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 265
    invoke-direct {p0, p1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    :cond_1
    return v0
.end method

.method public freeUnits(II)V
    .locals 1

    .line 294
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 p2, p2, -0x1

    aget p2, v0, p2

    invoke-direct {p0, p1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    return-void
.end method

.method public getFakeUnitsStart()I
    .locals 1

    .line 298
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->fakeUnitsStart:I

    return v0
.end method

.method public getHeap()[B
    .locals 1

    .line 373
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    return-object v0
.end method

.method public getHeapEnd()I
    .locals 1

    .line 306
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapEnd:I

    return v0
.end method

.method public getPText()I
    .locals 1

    .line 310
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    return v0
.end method

.method public getUnitsStart()I
    .locals 1

    .line 322
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    return v0
.end method

.method public incPText()V
    .locals 1

    .line 71
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    return-void
.end method

.method public initSubAllocator()V
    .locals 8

    .line 331
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeListPos:I

    .line 332
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->sizeOfFreeList()I

    move-result v2

    add-int/2addr v2, v1

    const/4 v3, 0x0

    invoke-static {v0, v1, v2, v3}, Ljava/util/Arrays;->fill([BIIB)V

    .line 335
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapStart:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    .line 337
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    div-int/lit8 v2, v1, 0x8

    const/16 v4, 0xc

    div-int/2addr v2, v4

    mul-int/lit8 v2, v2, 0x7

    mul-int/lit8 v2, v2, 0xc

    .line 339
    div-int/lit8 v5, v2, 0xc

    sget v6, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->UNIT_SIZE:I

    mul-int v5, v5, v6

    sub-int v2, v1, v2

    .line 341
    div-int/lit8 v7, v2, 0xc

    mul-int v7, v7, v6

    rem-int/lit8 v6, v2, 0xc

    add-int/2addr v7, v6

    add-int/2addr v1, v0

    .line 343
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    add-int/2addr v7, v0

    .line 344
    iput v7, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    iput v7, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    add-int/2addr v0, v2

    .line 345
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->fakeUnitsStart:I

    .line 346
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    add-int/2addr v0, v5

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    :goto_0
    const/4 v5, 0x4

    if-ge v1, v5, :cond_0

    .line 349
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    and-int/lit16 v6, v2, 0xff

    aput v6, v5, v1

    add-int/lit8 v1, v1, 0x1

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    add-int/2addr v2, v0

    :goto_1
    const/16 v6, 0x8

    if-ge v1, v6, :cond_1

    .line 352
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    and-int/lit16 v7, v2, 0xff

    aput v7, v6, v1

    add-int/lit8 v1, v1, 0x1

    add-int/lit8 v2, v2, 0x2

    goto :goto_1

    :cond_1
    add-int/2addr v2, v0

    :goto_2
    if-ge v1, v4, :cond_2

    .line 355
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    and-int/lit16 v7, v2, 0xff

    aput v7, v6, v1

    add-int/lit8 v1, v1, 0x1

    add-int/lit8 v2, v2, 0x3

    goto :goto_2

    :cond_2
    add-int/2addr v2, v0

    :goto_3
    const/16 v4, 0x26

    if-ge v1, v4, :cond_3

    .line 358
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    and-int/lit16 v6, v2, 0xff

    aput v6, v4, v1

    add-int/lit8 v1, v1, 0x1

    add-int/2addr v2, v5

    goto :goto_3

    .line 361
    :cond_3
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueCount:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_4
    const/16 v4, 0x80

    if-ge v1, v4, :cond_5

    .line 362
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->indx2Units:[I

    aget v4, v4, v2

    add-int/lit8 v5, v1, 0x1

    if-ge v4, v5, :cond_4

    const/4 v4, 0x1

    goto :goto_5

    :cond_4
    const/4 v4, 0x0

    :goto_5
    add-int/2addr v2, v4

    .line 363
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    and-int/lit16 v6, v2, 0xff

    aput v6, v4, v1

    move v1, v5

    goto :goto_4

    :cond_5
    return-void
.end method

.method public setFakeUnitsStart(I)V
    .locals 0

    .line 302
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->fakeUnitsStart:I

    return-void
.end method

.method public setPText(I)V
    .locals 0

    .line 314
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    return-void
.end method

.method public setUnitsStart(I)V
    .locals 0

    .line 326
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    return-void
.end method

.method public shrinkUnits(III)I
    .locals 2

    .line 273
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->units2Indx:[I

    add-int/lit8 p2, p2, -0x1

    aget p2, v0, p2

    add-int/lit8 v1, p3, -0x1

    .line 274
    aget v0, v0, v1

    if-ne p2, v0, :cond_0

    return p1

    .line 278
    :cond_0
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->getNext()I

    move-result v1

    if-eqz v1, :cond_1

    .line 279
    invoke-direct {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->removeNode(I)I

    move-result v0

    .line 284
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {p0, p3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->U2B(I)I

    move-result p3

    invoke-static {v1, p1, v1, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 285
    invoke-direct {p0, p1, p2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->insertNode(II)V

    return v0

    .line 288
    :cond_1
    invoke-direct {p0, p1, p2, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->splitBlock(III)V

    return p1
.end method

.method public startSubAllocator(I)Z
    .locals 5

    shl-int/lit8 p1, p1, 0x14

    .line 122
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    const/4 v1, 0x1

    if-ne v0, p1, :cond_0

    return v1

    .line 125
    :cond_0
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->stopSubAllocator()V

    .line 126
    div-int/lit8 v0, p1, 0xc

    sget v2, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->UNIT_SIZE:I

    mul-int v0, v0, v2

    add-int/2addr v0, v2

    add-int/lit8 v3, v0, 0x1

    add-int/lit16 v3, v3, 0x98

    .line 132
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempMemBlockPos:I

    add-int/lit8 v3, v3, 0xc

    .line 135
    new-array v3, v3, [B

    iput-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    .line 136
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapStart:I

    .line 137
    iget v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapStart:I

    add-int v4, v3, v0

    sub-int/2addr v4, v2

    iput v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapEnd:I

    .line 138
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    add-int/2addr v3, v0

    .line 140
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeListPos:I

    const/4 p1, 0x0

    .line 145
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeListPos:I

    :goto_0
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    array-length v3, v2

    if-ge p1, v3, :cond_1

    .line 146
    new-instance v3, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;-><init>([B)V

    aput-object v3, v2, p1

    .line 147
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->freeList:[Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    aget-object v2, v2, p1

    invoke-virtual {v2, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;->setAddress(I)V

    add-int/lit8 p1, p1, 0x1

    add-int/lit8 v0, v0, 0x4

    goto :goto_0

    .line 151
    :cond_1
    new-instance p1, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarNode;-><init>([B)V

    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarNode:Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    .line 152
    new-instance p1, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;-><init>([B)V

    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock1:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 153
    new-instance p1, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;-><init>([B)V

    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock2:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 154
    new-instance p1, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    invoke-direct {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;-><init>([B)V

    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock3:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    return v1
.end method

.method public stopSubAllocator()V
    .locals 2

    .line 103
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    .line 104
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    const/4 v0, 0x0

    .line 105
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heap:[B

    const/4 v1, 0x1

    .line 106
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapStart:I

    .line 109
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarNode:Lir/mahdi/mzip/rar/unpack/ppm/RarNode;

    .line 110
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock1:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 111
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock2:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    .line 112
    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->tempRarMemBlock3:Lir/mahdi/mzip/rar/unpack/ppm/RarMemBlock;

    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 396
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SubAllocator["

    .line 397
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  subAllocatorSize="

    .line 398
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->subAllocatorSize:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  glueCount="

    .line 400
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 401
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->glueCount:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  heapStart="

    .line 402
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 403
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->heapStart:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  loUnit="

    .line 404
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 405
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->loUnit:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  hiUnit="

    .line 406
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 407
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->hiUnit:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  pText="

    .line 408
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 409
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->pText:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  unitsStart="

    .line 410
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 411
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->unitsStart:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 412
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 413
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
