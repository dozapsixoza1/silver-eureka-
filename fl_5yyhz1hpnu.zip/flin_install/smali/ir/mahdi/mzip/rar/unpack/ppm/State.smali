.class public Lir/mahdi/mzip/rar/unpack/ppm/State;
.super Lir/mahdi/mzip/rar/unpack/ppm/Pointer;
.source "State.java"


# static fields
.field public static final size:I = 0x6


# direct methods
.method public constructor <init>([B)V
    .locals 0

    .line 27
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/Pointer;-><init>([B)V

    return-void
.end method

.method public static ppmdSwap(Lir/mahdi/mzip/rar/unpack/ppm/State;Lir/mahdi/mzip/rar/unpack/ppm/State;)V
    .locals 5

    .line 31
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget-object v1, p1, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    .line 32
    iget p0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    iget p1, p1, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    const/4 v2, 0x0

    :goto_0
    const/4 v3, 0x6

    if-ge v2, v3, :cond_0

    .line 33
    aget-byte v3, v0, p0

    .line 34
    aget-byte v4, v1, p1

    aput-byte v4, v0, p0

    .line 35
    aput-byte v3, v1, p1

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 p0, p0, 0x1

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public decAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;
    .locals 1

    .line 88
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v0, v0, -0x6

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    return-object p0
.end method

.method public getFreq()I
    .locals 2

    .line 54
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v1, v1, 0x1

    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    return v0
.end method

.method public getSuccessor()I
    .locals 2

    .line 66
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v1, v1, 0x2

    invoke-static {v0, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v0

    return v0
.end method

.method public getSymbol()I
    .locals 2

    .line 46
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    return v0
.end method

.method public incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;
    .locals 1

    .line 93
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v0, v0, 0x6

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    return-object p0
.end method

.method public incFreq(I)V
    .locals 3

    .line 62
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v1, v1, 0x1

    aget-byte v2, v0, v1

    add-int/2addr v2, p1

    int-to-byte p1, v2

    aput-byte p1, v0, v1

    return-void
.end method

.method public init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;
    .locals 0

    .line 40
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    const/4 p1, 0x0

    .line 41
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    return-object p0
.end method

.method public setFreq(I)V
    .locals 2

    .line 58
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v1, v1, 0x1

    int-to-byte p1, p1

    aput-byte p1, v0, v1

    return-void
.end method

.method public setSuccessor(I)V
    .locals 2

    .line 70
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    add-int/lit8 v1, v1, 0x2

    invoke-static {v0, v1, p1}, Lir/mahdi/mzip/rar/io/Raw;->writeIntLittleEndian([BII)V

    return-void
.end method

.method public setSuccessor(Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;)V
    .locals 0

    .line 74
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(I)V

    return-void
.end method

.method public setSymbol(I)V
    .locals 2

    .line 50
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    int-to-byte p1, p1

    aput-byte p1, v0, v1

    return-void
.end method

.method public setValues(Lir/mahdi/mzip/rar/unpack/ppm/State;)V
    .locals 4

    .line 84
    iget-object v0, p1, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget p1, p1, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->mem:[B

    iget v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    const/4 v3, 0x6

    invoke-static {v0, p1, v1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method

.method public setValues(Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)V
    .locals 1

    .line 78
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result v0

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSymbol(I)V

    .line 79
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getFreq()I

    move-result v0

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    .line 80
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSuccessor()I

    move-result p1

    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(I)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 98
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "State["

    .line 99
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  pos="

    .line 100
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/State;->pos:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  size="

    .line 102
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    .line 103
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  symbol="

    .line 104
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  freq="

    .line 106
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  successor="

    .line 108
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 110
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
