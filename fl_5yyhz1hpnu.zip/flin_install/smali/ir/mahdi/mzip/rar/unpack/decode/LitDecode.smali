.class public Lir/mahdi/mzip/rar/unpack/decode/LitDecode;
.super Lir/mahdi/mzip/rar/unpack/decode/Decode;
.source "LitDecode.java"


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 21
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/decode/Decode;-><init>()V

    const/16 v0, 0x12b

    .line 22
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/decode/LitDecode;->decodeNum:[I

    return-void
.end method
