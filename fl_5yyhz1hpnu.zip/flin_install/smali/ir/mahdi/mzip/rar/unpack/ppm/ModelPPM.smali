.class public Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;
.super Ljava/lang/Object;
.source "ModelPPM.java"


# static fields
.field public static final BIN_SCALE:I = 0x4000

.field public static final INTERVAL:I = 0x80

.field public static final INT_BITS:I = 0x7

.field private static InitBinEsc:[I = null

.field public static final MAX_FREQ:I = 0x7c

.field public static final MAX_O:I = 0x40

.field public static final PERIOD_BITS:I = 0x7

.field public static final TOT_BITS:I = 0xe


# instance fields
.field private HB2Flag:[I

.field private NS2BSIndx:[I

.field private NS2Indx:[I

.field private SEE2Cont:[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

.field private binSumm:[[I

.field private charMask:[I

.field private coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

.field private dummySEE2Cont:Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

.field private escCount:I

.field private foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private hiBitsFlag:I

.field private initEsc:I

.field private initRL:I

.field private maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private maxOrder:I

.field private medContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private numMasked:I

.field private orderFall:I

.field private prevSuccess:I

.field private final ps:[I

.field private runLength:I

.field private subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

.field private final tempPPMContext1:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private final tempPPMContext2:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private final tempPPMContext3:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private final tempPPMContext4:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

.field private final tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState2:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState3:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempState4:Lir/mahdi/mzip/rar/unpack/ppm/State;

.field private final tempStateRef1:Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

.field private final tempStateRef2:Lir/mahdi/mzip/rar/unpack/ppm/StateRef;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    .line 41
    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->InitBinEsc:[I

    return-void

    :array_0
    .array-data 4
        0x3cdd
        0x1f3f
        0x59bf
        0x48f3
        0x64a1
        0x5abc
        0x6632
        0x6051
    .end array-data
.end method

.method public constructor <init>()V
    .locals 4

    .line 70
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 44
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 45
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState2:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 46
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState3:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 47
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState4:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 48
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempStateRef1:Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    .line 49
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempStateRef2:Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    .line 50
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext1:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 51
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext2:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 52
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext3:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 53
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-direct {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext4:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    const/16 v0, 0x40

    .line 54
    new-array v2, v0, [I

    iput-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->ps:[I

    const/16 v2, 0x19

    const/16 v3, 0x10

    .line 55
    filled-new-array {v2, v3}, [I

    move-result-object v2

    const-class v3, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    invoke-static {v3, v2}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    iput-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->SEE2Cont:[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    const/16 v2, 0x100

    .line 60
    new-array v3, v2, [I

    iput-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->charMask:[I

    .line 61
    new-array v3, v2, [I

    iput-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2Indx:[I

    .line 62
    new-array v3, v2, [I

    iput-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2BSIndx:[I

    .line 63
    new-array v2, v2, [I

    iput-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->HB2Flag:[I

    const/16 v2, 0x80

    .line 66
    filled-new-array {v2, v0}, [I

    move-result-object v0

    const-class v2, I

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->binSumm:[[I

    .line 67
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    .line 68
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    .line 71
    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 72
    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 73
    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->medContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    return-void
.end method

.method private clearMask()V
    .locals 2

    const/4 v0, 0x1

    .line 156
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    .line 157
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->charMask:[I

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    return-void
.end method

.method private createSuccessors(ZLir/mahdi/mzip/rar/unpack/ppm/State;)I
    .locals 9

    .line 364
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempStateRef2:Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    .line 365
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState1:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v1

    .line 368
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext1:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v3

    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v2

    .line 369
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v3

    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 370
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext2:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v4

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v3

    .line 371
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result v4

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 374
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState2:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v5

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez p1, :cond_1

    .line 380
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->ps:[I

    iget-object v7, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v7}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v7

    aput v7, p1, v5

    .line 381
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    const/4 v7, 0x0

    :goto_1
    if-nez p1, :cond_8

    .line 387
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result p1

    if-eqz p1, :cond_2

    .line 388
    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result p1

    invoke-virtual {v4, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 389
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result p1

    invoke-virtual {v2, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    const/4 p1, 0x1

    goto :goto_3

    :cond_2
    :goto_2
    const/4 p1, 0x0

    :goto_3
    if-nez p1, :cond_5

    .line 394
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result p1

    invoke-virtual {v2, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 395
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result p1

    if-eq p1, v6, :cond_4

    .line 396
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result p1

    invoke-virtual {v4, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 397
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p1

    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p2

    if-eq p1, p2, :cond_5

    .line 399
    :cond_3
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 400
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p1

    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p2

    if-ne p1, p2, :cond_3

    goto :goto_4

    .line 403
    :cond_4
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getOneState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result p1

    invoke-virtual {v4, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 407
    :cond_5
    :goto_4
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result p1

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p2

    if-eq p1, p2, :cond_6

    .line 408
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result p1

    invoke-virtual {v2, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    goto :goto_5

    .line 411
    :cond_6
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->ps:[I

    add-int/lit8 p2, v7, 0x1

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v8

    aput v8, p1, v7

    .line 412
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result p1

    if-nez p1, :cond_7

    move v7, p2

    goto :goto_5

    :cond_7
    move v7, p2

    goto :goto_2

    :cond_8
    :goto_5
    if-nez v7, :cond_9

    .line 416
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    return p1

    .line 418
    :cond_9
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object p1

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p2

    aget-byte p1, p1, p2

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setSymbol(I)V

    .line 421
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    add-int/2addr p1, v6

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setSuccessor(I)V

    .line 422
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result p1

    if-eq p1, v6, :cond_f

    .line 423
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result p2

    if-gt p1, p2, :cond_a

    return v5

    .line 426
    :cond_a
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result p1

    invoke-virtual {v4, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 427
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result p2

    if-eq p1, p2, :cond_c

    .line 429
    :cond_b
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 430
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result p1

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result p2

    if-ne p1, p2, :cond_b

    .line 432
    :cond_c
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result p1

    sub-int/2addr p1, v6

    .line 433
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object p2

    invoke-virtual {p2}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result p2

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v3

    sub-int/2addr p2, v3

    sub-int/2addr p2, p1

    mul-int/lit8 v3, p1, 0x2

    if-gt v3, p2, :cond_e

    mul-int/lit8 p1, p1, 0x5

    if-le p1, p2, :cond_d

    const/4 p1, 0x1

    goto :goto_6

    :cond_d
    const/4 p1, 0x0

    goto :goto_6

    :cond_e
    mul-int/lit8 p1, p2, 0x3

    add-int/2addr v3, p1

    sub-int/2addr v3, v6

    mul-int/lit8 p2, p2, 0x2

    .line 435
    div-int p1, v3, p2

    :goto_6
    add-int/2addr v6, p1

    invoke-virtual {v0, v6}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setFreq(I)V

    goto :goto_7

    .line 438
    :cond_f
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getOneState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object p1

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result p1

    invoke-virtual {v0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setFreq(I)V

    .line 442
    :cond_10
    :goto_7
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->ps:[I

    add-int/lit8 v7, v7, -0x1

    aget p1, p1, v7

    invoke-virtual {v1, p1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 443
    invoke-virtual {v2, p0, v1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->createChild(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;Lir/mahdi/mzip/rar/unpack/ppm/State;Lir/mahdi/mzip/rar/unpack/ppm/StateRef;)I

    move-result p1

    invoke-virtual {v2, p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 444
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    if-nez p1, :cond_11

    return v5

    :cond_11
    if-nez v7, :cond_10

    .line 448
    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    return p1
.end method

.method private restartModelRare()V
    .locals 9

    .line 81
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->charMask:[I

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    .line 82
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->initSubAllocator()V

    .line 83
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxOrder:I

    const/16 v2, 0xc

    if-ge v0, v2, :cond_0

    goto :goto_0

    :cond_0
    const/16 v0, 0xc

    :goto_0
    neg-int v0, v0

    const/4 v2, 0x1

    sub-int/2addr v0, v2

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initRL:I

    .line 84
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocContext()I

    move-result v0

    .line 85
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v3, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 86
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v3, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 87
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setSuffix(I)V

    .line 88
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxOrder:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    .line 89
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    const/16 v3, 0x100

    invoke-virtual {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setNumStats(I)V

    .line 90
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v0

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v4

    add-int/2addr v4, v2

    invoke-virtual {v0, v4}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setSummFreq(I)V

    .line 92
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    const/16 v4, 0x80

    invoke-virtual {v0, v4}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocUnits(I)I

    move-result v0

    .line 93
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v5, v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 94
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v5

    invoke-virtual {v5, v0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setStats(I)V

    .line 96
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeap()[B

    move-result-object v5

    invoke-direct {v0, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    .line 97
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v5

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v5

    .line 98
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initRL:I

    iput v6, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->runLength:I

    .line 99
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->prevSuccess:I

    const/4 v6, 0x0

    :goto_1
    if-ge v6, v3, :cond_1

    mul-int/lit8 v7, v6, 0x6

    add-int/2addr v7, v5

    .line 101
    invoke-virtual {v0, v7}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 102
    invoke-virtual {v0, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSymbol(I)V

    .line 103
    invoke-virtual {v0, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    .line 104
    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(I)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_2
    if-ge v0, v4, :cond_4

    const/4 v2, 0x0

    :goto_3
    const/16 v3, 0x8

    if-ge v2, v3, :cond_3

    const/4 v3, 0x0

    :goto_4
    const/16 v5, 0x40

    if-ge v3, v5, :cond_2

    .line 110
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->binSumm:[[I

    aget-object v5, v5, v0

    add-int v6, v2, v3

    sget-object v7, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->InitBinEsc:[I

    aget v7, v7, v2

    add-int/lit8 v8, v0, 0x2

    div-int/2addr v7, v8

    rsub-int v7, v7, 0x4000

    aput v7, v5, v6

    add-int/lit8 v3, v3, 0x8

    goto :goto_4

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_4
    const/4 v0, 0x0

    :goto_5
    const/16 v2, 0x19

    if-ge v0, v2, :cond_6

    const/4 v2, 0x0

    :goto_6
    const/16 v3, 0x10

    if-ge v2, v3, :cond_5

    .line 116
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->SEE2Cont:[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    aget-object v3, v3, v0

    aget-object v3, v3, v2

    mul-int/lit8 v4, v0, 0x5

    add-int/lit8 v4, v4, 0xa

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->init(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_5
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_6
    return-void
.end method

.method private startModelRare(I)V
    .locals 5

    const/4 v0, 0x1

    .line 123
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    .line 124
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxOrder:I

    .line 125
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->restartModelRare()V

    .line 127
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2BSIndx:[I

    const/4 v1, 0x0

    aput v1, p1, v1

    const/4 v2, 0x2

    .line 128
    aput v2, p1, v0

    const/4 p1, 0x0

    :goto_0
    const/16 v2, 0x9

    if-ge p1, v2, :cond_0

    .line 130
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2BSIndx:[I

    add-int/lit8 v3, p1, 0x2

    const/4 v4, 0x4

    aput v4, v2, v3

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_1
    const/16 v2, 0xf5

    if-ge p1, v2, :cond_1

    .line 133
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2BSIndx:[I

    add-int/lit8 v3, p1, 0xb

    const/4 v4, 0x6

    aput v4, v2, v3

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_2
    const/4 v2, 0x3

    if-ge p1, v2, :cond_2

    .line 136
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2Indx:[I

    aput p1, v2, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    :cond_2
    move v0, p1

    const/4 v2, 0x1

    const/4 v3, 0x1

    :goto_3
    const/16 v4, 0x100

    if-ge p1, v4, :cond_4

    .line 139
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2Indx:[I

    aput v0, v4, p1

    add-int/lit8 v2, v2, -0x1

    if-nez v2, :cond_3

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v0, v0, 0x1

    move v2, v3

    :cond_3
    add-int/lit8 p1, p1, 0x1

    goto :goto_3

    :cond_4
    const/4 p1, 0x0

    :goto_4
    const/16 v0, 0x40

    if-ge p1, v0, :cond_5

    .line 146
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->HB2Flag:[I

    aput v1, v0, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_5
    :goto_5
    const/16 p1, 0xc0

    if-ge v1, p1, :cond_6

    .line 149
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->HB2Flag:[I

    add-int/lit8 v0, v1, 0x40

    const/16 v2, 0x8

    aput v2, p1, v0

    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    .line 151
    :cond_6
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->dummySEE2Cont:Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    const/4 v0, 0x7

    invoke-virtual {p1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;->setShift(I)V

    return-void
.end method

.method private updateModel()V
    .locals 15

    .line 459
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempStateRef1:Lir/mahdi/mzip/rar/unpack/ppm/StateRef;

    .line 460
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 461
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState3:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v1

    .line 462
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempState4:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v3

    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v2

    .line 464
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext3:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v4

    invoke-virtual {v3, v4}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v3

    .line 465
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->tempPPMContext4:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v5

    invoke-virtual {v4, v5}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->init([B)Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    move-result-object v4

    .line 468
    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result v5

    invoke-virtual {v3, v5}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 469
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getFreq()I

    move-result v5

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/16 v8, 0x1f

    if-ge v5, v8, :cond_3

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v5

    if-eqz v5, :cond_3

    .line 470
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v5

    if-eq v5, v7, :cond_2

    .line 471
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v5

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v5

    invoke-virtual {v1, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 472
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v5

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result v8

    if-eq v5, v8, :cond_1

    .line 474
    :cond_0
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 475
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v5

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result v8

    if-ne v5, v8, :cond_0

    .line 476
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v5

    add-int/lit8 v5, v5, -0x6

    invoke-virtual {v2, v5}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 477
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v5

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v8

    if-lt v5, v8, :cond_1

    .line 478
    invoke-static {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->ppmdSwap(Lir/mahdi/mzip/rar/unpack/ppm/State;Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 479
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->decAddress()Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 482
    :cond_1
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v2

    const/16 v5, 0x73

    if-ge v2, v5, :cond_3

    .line 483
    invoke-virtual {v1, v6}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    .line 484
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v2

    invoke-virtual {v2, v6}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    goto :goto_0

    .line 487
    :cond_2
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getOneState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v2

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v2

    invoke-virtual {v1, v2}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 488
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v2

    const/16 v5, 0x20

    if-ge v2, v5, :cond_3

    .line 489
    invoke-virtual {v1, v7}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    .line 493
    :cond_3
    :goto_0
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    if-nez v2, :cond_5

    .line 494
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-direct {p0, v7, v1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->createSuccessors(ZLir/mahdi/mzip/rar/unpack/ppm/State;)I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(I)V

    .line 495
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 496
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result v1

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 497
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v0

    if-nez v0, :cond_4

    .line 498
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->updateModelRestart()V

    :cond_4
    return-void

    .line 503
    :cond_5
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeap()[B

    move-result-object v2

    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v5

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result v8

    int-to-byte v8, v8

    aput-byte v8, v2, v5

    .line 504
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->incPText()V

    .line 505
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v2

    invoke-virtual {v4, v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 506
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v2

    iget-object v5, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v5}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getFakeUnitsStart()I

    move-result v5

    if-lt v2, v5, :cond_6

    .line 507
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->updateModelRestart()V

    return-void

    .line 512
    :cond_6
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSuccessor()I

    move-result v2

    const/4 v5, 0x0

    if-eqz v2, :cond_8

    .line 513
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSuccessor()I

    move-result v2

    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v8

    if-gt v2, v8, :cond_7

    .line 514
    invoke-direct {p0, v5, v1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->createSuccessors(ZLir/mahdi/mzip/rar/unpack/ppm/State;)I

    move-result v2

    invoke-virtual {v0, v2}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setSuccessor(I)V

    .line 515
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSuccessor()I

    move-result v2

    if-nez v2, :cond_7

    .line 516
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->updateModelRestart()V

    return-void

    .line 520
    :cond_7
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    sub-int/2addr v2, v7

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    if-nez v2, :cond_9

    .line 521
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSuccessor()I

    move-result v2

    invoke-virtual {v4, v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 522
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v2

    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v8

    if-eq v2, v8, :cond_9

    .line 523
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v2, v7}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->decPText(I)V

    goto :goto_1

    .line 527
    :cond_8
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v8

    invoke-virtual {v2, v8}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(I)V

    .line 528
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0, v2}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->setSuccessor(Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;)V

    .line 532
    :cond_9
    :goto_1
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v2

    .line 533
    iget-object v8, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v8

    invoke-virtual {v8}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v8

    sub-int/2addr v8, v2

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getFreq()I

    move-result v9

    sub-int/2addr v9, v7

    sub-int/2addr v8, v9

    .line 534
    iget-object v9, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v9}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v9

    invoke-virtual {v3, v9}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 535
    :goto_2
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v9

    iget-object v10, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v10}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v10

    if-eq v9, v10, :cond_18

    .line 537
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v9

    const/4 v10, 0x3

    if-eq v9, v7, :cond_e

    and-int/lit8 v11, v9, 0x1

    if-nez v11, :cond_a

    .line 540
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v11

    iget-object v12, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    .line 541
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v13

    invoke-virtual {v13}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v13

    ushr-int/lit8 v14, v9, 0x1

    invoke-virtual {v12, v13, v14}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->expandUnits(II)I

    move-result v12

    .line 540
    invoke-virtual {v11, v12}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setStats(I)V

    .line 543
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v11

    invoke-virtual {v11}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v11

    if-nez v11, :cond_a

    .line 544
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->updateModelRestart()V

    return-void

    :cond_a
    mul-int/lit8 v11, v9, 0x2

    if-ge v11, v2, :cond_b

    const/4 v11, 0x1

    goto :goto_3

    :cond_b
    const/4 v11, 0x0

    :goto_3
    mul-int/lit8 v12, v9, 0x4

    if-gt v12, v2, :cond_c

    const/4 v12, 0x1

    goto :goto_4

    :cond_c
    const/4 v12, 0x0

    .line 554
    :goto_4
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v13

    invoke-virtual {v13}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v13

    mul-int/lit8 v14, v9, 0x8

    if-gt v13, v14, :cond_d

    const/4 v13, 0x1

    goto :goto_5

    :cond_d
    const/4 v13, 0x0

    :goto_5
    and-int/2addr v12, v13

    mul-int/lit8 v12, v12, 0x2

    add-int/2addr v11, v12

    .line 556
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v12

    invoke-virtual {v12, v11}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    goto :goto_8

    .line 558
    :cond_e
    iget-object v11, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v11, v7}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->allocUnits(I)I

    move-result v11

    invoke-virtual {v1, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 559
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v11

    if-nez v11, :cond_f

    .line 560
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->updateModelRestart()V

    return-void

    .line 563
    :cond_f
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getOneState()Lir/mahdi/mzip/rar/unpack/ppm/State;

    move-result-object v11

    invoke-virtual {v1, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setValues(Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 564
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v11

    invoke-virtual {v11, v1}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setStats(Lir/mahdi/mzip/rar/unpack/ppm/State;)V

    .line 565
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v11

    const/16 v12, 0x1e

    if-ge v11, v12, :cond_10

    .line 566
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v11

    invoke-virtual {v1, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;->incFreq(I)V

    goto :goto_6

    :cond_10
    const/16 v11, 0x78

    .line 568
    invoke-virtual {v1, v11}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    .line 570
    :goto_6
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v11

    .line 571
    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getFreq()I

    move-result v12

    iget v13, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initEsc:I

    add-int/2addr v12, v13

    if-le v2, v10, :cond_11

    const/4 v13, 0x1

    goto :goto_7

    :cond_11
    const/4 v13, 0x0

    :goto_7
    add-int/2addr v12, v13

    .line 570
    invoke-virtual {v11, v12}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->setSummFreq(I)V

    .line 573
    :goto_8
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getFreq()I

    move-result v11

    mul-int/lit8 v11, v11, 0x2

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v12

    invoke-virtual {v12}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v12

    add-int/lit8 v12, v12, 0x6

    mul-int v11, v11, v12

    .line 574
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v12

    invoke-virtual {v12}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getSummFreq()I

    move-result v12

    add-int/2addr v12, v8

    mul-int/lit8 v13, v12, 0x6

    if-ge v11, v13, :cond_14

    if-le v11, v12, :cond_12

    const/4 v13, 0x1

    goto :goto_9

    :cond_12
    const/4 v13, 0x0

    :goto_9
    add-int/2addr v13, v7

    mul-int/lit8 v12, v12, 0x4

    if-lt v11, v12, :cond_13

    const/4 v11, 0x1

    goto :goto_a

    :cond_13
    const/4 v11, 0x0

    :goto_a
    add-int/2addr v13, v11

    .line 577
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v11

    invoke-virtual {v11, v10}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    goto :goto_e

    :cond_14
    mul-int/lit8 v10, v12, 0x9

    if-lt v11, v10, :cond_15

    const/4 v10, 0x1

    goto :goto_b

    :cond_15
    const/4 v10, 0x0

    :goto_b
    add-int/lit8 v10, v10, 0x4

    mul-int/lit8 v13, v12, 0xc

    if-lt v11, v13, :cond_16

    const/4 v13, 0x1

    goto :goto_c

    :cond_16
    const/4 v13, 0x0

    :goto_c
    add-int/2addr v10, v13

    mul-int/lit8 v12, v12, 0xf

    if-lt v11, v12, :cond_17

    const/4 v11, 0x1

    goto :goto_d

    :cond_17
    const/4 v11, 0x0

    :goto_d
    add-int v13, v10, v11

    .line 581
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v10

    invoke-virtual {v10, v13}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->incSummFreq(I)V

    .line 583
    :goto_e
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v10

    invoke-virtual {v10}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v10

    mul-int/lit8 v11, v9, 0x6

    add-int/2addr v10, v11

    invoke-virtual {v1, v10}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setAddress(I)V

    .line 584
    invoke-virtual {v1, v4}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSuccessor(Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;)V

    .line 585
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSymbol()I

    move-result v10

    invoke-virtual {v1, v10}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setSymbol(I)V

    .line 586
    invoke-virtual {v1, v13}, Lir/mahdi/mzip/rar/unpack/ppm/State;->setFreq(I)V

    add-int/lit8 v9, v9, 0x1

    .line 587
    invoke-virtual {v3, v9}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setNumStats(I)V

    .line 536
    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result v9

    invoke-virtual {v3, v9}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    goto/16 :goto_2

    .line 590
    :cond_18
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/StateRef;->getSuccessor()I

    move-result v0

    .line 591
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 592
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v1, v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    return-void
.end method

.method private updateModelRestart()V
    .locals 1

    .line 452
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->restartModelRare()V

    const/4 v0, 0x0

    .line 453
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    return-void
.end method


# virtual methods
.method public decodeChar()I
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 208
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v0

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v1

    const/4 v2, -0x1

    if-le v0, v1, :cond_c

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 209
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v0

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeapEnd()I

    move-result v1

    if-le v0, v1, :cond_0

    goto/16 :goto_4

    .line 213
    :cond_0
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3

    .line 214
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v0

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v3

    if-le v0, v3, :cond_2

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 215
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getFreqData()Lir/mahdi/mzip/rar/unpack/ppm/FreqData;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/FreqData;->getStats()I

    move-result v0

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeapEnd()I

    move-result v3

    if-le v0, v3, :cond_1

    goto :goto_0

    .line 218
    :cond_1
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->decodeSymbol1(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)Z

    move-result v0

    if-nez v0, :cond_4

    :cond_2
    :goto_0
    return v2

    .line 222
    :cond_3
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->decodeBinSymbol(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)V

    .line 224
    :cond_4
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->decode()V

    .line 225
    :goto_1
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getAddress()I

    move-result v0

    if-nez v0, :cond_9

    .line 226
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->ariDecNormalize()V

    .line 228
    :cond_5
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    add-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    .line 229
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getSuffix()I

    move-result v3

    invoke-virtual {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 230
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v0

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v3

    if-le v0, v3, :cond_8

    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 231
    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result v0

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeapEnd()I

    move-result v3

    if-le v0, v3, :cond_6

    goto :goto_2

    .line 234
    :cond_6
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getNumStats()I

    move-result v0

    iget v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->numMasked:I

    if-eq v0, v3, :cond_5

    .line 235
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->decodeSymbol2(Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;)Z

    move-result v0

    if-nez v0, :cond_7

    return v2

    .line 238
    :cond_7
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->decode()V

    goto :goto_1

    :cond_8
    :goto_2
    return v2

    .line 240
    :cond_9
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSymbol()I

    move-result v0

    .line 241
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    if-nez v1, :cond_a

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result v1

    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getPText()I

    move-result v2

    if-le v1, v2, :cond_a

    .line 243
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/State;->getSuccessor()I

    move-result v1

    .line 244
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v2, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    .line 245
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {v2, v1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->setAddress(I)V

    goto :goto_3

    .line 247
    :cond_a
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->updateModel()V

    .line 249
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    if-nez v1, :cond_b

    .line 250
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->clearMask()V

    .line 253
    :cond_b
    :goto_3
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->ariDecNormalize()V

    return v0

    :cond_c
    :goto_4
    return v2
.end method

.method public decodeInit(Lir/mahdi/mzip/rar/unpack/Unpack;I)Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 163
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->getChar()I

    move-result p2

    and-int/lit16 p2, p2, 0xff

    and-int/lit8 v0, p2, 0x20

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    .line 168
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->getChar()I

    move-result v3

    goto :goto_1

    .line 170
    :cond_1
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->GetAllocatedMemory()I

    move-result v3

    if-nez v3, :cond_2

    return v2

    :cond_2
    const/4 v3, 0x0

    :goto_1
    and-int/lit8 v4, p2, 0x40

    if-eqz v4, :cond_3

    .line 175
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/Unpack;->getChar()I

    move-result v4

    .line 176
    invoke-virtual {p1, v4}, Lir/mahdi/mzip/rar/unpack/Unpack;->setPpmEscChar(I)V

    .line 178
    :cond_3
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-virtual {v4, p1}, Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;->initDecoder(Lir/mahdi/mzip/rar/unpack/Unpack;)V

    if-eqz v0, :cond_8

    and-int/lit8 p1, p2, 0x1f

    add-int/2addr p1, v1

    const/16 p2, 0x10

    if-le p1, p2, :cond_4

    add-int/lit8 p1, p1, -0x10

    mul-int/lit8 p1, p1, 0x3

    add-int/2addr p1, p2

    :cond_4
    if-ne p1, v1, :cond_5

    .line 185
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->stopSubAllocator()V

    return v2

    .line 188
    :cond_5
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    add-int/2addr v3, v1

    invoke-virtual {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->startSubAllocator(I)Z

    .line 189
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v3

    invoke-direct {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 190
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v3

    invoke-direct {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->medContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 191
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v3

    invoke-direct {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    .line 192
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getHeap()[B

    move-result-object v3

    invoke-direct {v0, v3}, Lir/mahdi/mzip/rar/unpack/ppm/State;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    .line 193
    new-instance v0, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->dummySEE2Cont:Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    const/4 v0, 0x0

    :goto_2
    const/16 v3, 0x19

    if-ge v0, v3, :cond_7

    const/4 v3, 0x0

    :goto_3
    if-ge v3, p2, :cond_6

    .line 196
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->SEE2Cont:[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    aget-object v4, v4, v0

    new-instance v5, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    invoke-direct {v5}, Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;-><init>()V

    aput-object v5, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    .line 199
    :cond_7
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->startModelRare(I)V

    .line 201
    :cond_8
    iget-object p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->minContext:Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/unpack/ppm/PPMContext;->getAddress()I

    move-result p1

    if-eqz p1, :cond_9

    goto :goto_4

    :cond_9
    const/4 v1, 0x0

    :goto_4
    return v1
.end method

.method public getBinSumm()[[I
    .locals 1

    .line 330
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->binSumm:[[I

    return-object v0
.end method

.method public getCharMask()[I
    .locals 1

    .line 282
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->charMask:[I

    return-object v0
.end method

.method public getCoder()Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;
    .locals 1

    .line 334
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    return-object v0
.end method

.method public getDummySEE2Cont()Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;
    .locals 1

    .line 262
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->dummySEE2Cont:Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    return-object v0
.end method

.method public getEscCount()I
    .locals 1

    .line 270
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    return v0
.end method

.method public getFoundState()Lir/mahdi/mzip/rar/unpack/ppm/State;
    .locals 1

    .line 350
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    return-object v0
.end method

.method public getHB2Flag()[I
    .locals 1

    .line 338
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->HB2Flag:[I

    return-object v0
.end method

.method public getHeap()[B
    .locals 1

    .line 354
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;->getHeap()[B

    move-result-object v0

    return-object v0
.end method

.method public getHiBitsFlag()I
    .locals 1

    .line 322
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->hiBitsFlag:I

    return v0
.end method

.method public getInitEsc()I
    .locals 1

    .line 294
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initEsc:I

    return v0
.end method

.method public getInitRL()I
    .locals 1

    .line 266
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initRL:I

    return v0
.end method

.method public getNS2BSIndx()[I
    .locals 1

    .line 342
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2BSIndx:[I

    return-object v0
.end method

.method public getNS2Indx()[I
    .locals 1

    .line 346
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->NS2Indx:[I

    return-object v0
.end method

.method public getNumMasked()I
    .locals 1

    .line 286
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->numMasked:I

    return v0
.end method

.method public getOrderFall()I
    .locals 1

    .line 358
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    return v0
.end method

.method public getPrevSuccess()I
    .locals 1

    .line 314
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->prevSuccess:I

    return v0
.end method

.method public getRunLength()I
    .locals 1

    .line 302
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->runLength:I

    return v0
.end method

.method public getSEE2Cont()[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;
    .locals 1

    .line 258
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->SEE2Cont:[[Lir/mahdi/mzip/rar/unpack/ppm/SEE2Context;

    return-object v0
.end method

.method public getSubAlloc()Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;
    .locals 1

    .line 77
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    return-object v0
.end method

.method public incEscCount(I)V
    .locals 1

    .line 278
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getEscCount()I

    move-result v0

    add-int/2addr v0, p1

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setEscCount(I)V

    return-void
.end method

.method public incRunLength(I)V
    .locals 1

    .line 310
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->getRunLength()I

    move-result v0

    add-int/2addr v0, p1

    invoke-virtual {p0, v0}, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->setRunLength(I)V

    return-void
.end method

.method public setEscCount(I)V
    .locals 0

    and-int/lit16 p1, p1, 0xff

    .line 274
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    return-void
.end method

.method public setHiBitsFlag(I)V
    .locals 0

    and-int/lit16 p1, p1, 0xff

    .line 326
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->hiBitsFlag:I

    return-void
.end method

.method public setInitEsc(I)V
    .locals 0

    .line 298
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initEsc:I

    return-void
.end method

.method public setNumMasked(I)V
    .locals 0

    .line 290
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->numMasked:I

    return-void
.end method

.method public setPrevSuccess(I)V
    .locals 0

    and-int/lit16 p1, p1, 0xff

    .line 318
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->prevSuccess:I

    return-void
.end method

.method public setRunLength(I)V
    .locals 0

    .line 306
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->runLength:I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 605
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ModelPPM["

    .line 606
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n  numMasked="

    .line 607
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 608
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->numMasked:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  initEsc="

    .line 609
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 610
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initEsc:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  orderFall="

    .line 611
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 612
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->orderFall:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  maxOrder="

    .line 613
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 614
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->maxOrder:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  runLength="

    .line 615
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 616
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->runLength:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  initRL="

    .line 617
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 618
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->initRL:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  escCount="

    .line 619
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 620
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->escCount:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  prevSuccess="

    .line 621
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 622
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->prevSuccess:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\n  foundState="

    .line 623
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 624
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->foundState:Lir/mahdi/mzip/rar/unpack/ppm/State;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\n  coder="

    .line 625
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 626
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->coder:Lir/mahdi/mzip/rar/unpack/ppm/RangeCoder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\n  subAlloc="

    .line 627
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 628
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ppm/ModelPPM;->subAlloc:Lir/mahdi/mzip/rar/unpack/ppm/SubAllocator;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\n]"

    .line 629
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 630
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
