.class public final enum Lir/mahdi/mzip/rar/unpack/vm/VMCommands;
.super Ljava/lang/Enum;
.source "VMCommands.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/vm/VMCommands;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_ADC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_ADD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_ADDB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_ADDD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_AND:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_CALL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_CMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_CMPB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_CMPD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_DEC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_DECB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_DECD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_DIV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_INC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_INCB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_INCD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JAE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JBE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JNS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JNZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_JZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_MOV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_MOVB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_MOVD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_MOVSX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_MOVZX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_MUL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_NEG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_NEGB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_NEGD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_NOT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_OR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_POP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_POPA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_POPF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_PRINT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_PUSH:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_PUSHA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_PUSHF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SAR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SHL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SHR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_STANDARD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SUB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SUBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_SUBD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_TEST:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_XCHG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

.field public static final enum VM_XOR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;


# instance fields
.field private vmCommand:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    .line 21
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v1, 0x0

    const-string v2, "VM_MOV"

    invoke-direct {v0, v2, v1, v1}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v2, 0x1

    const-string v3, "VM_CMP"

    invoke-direct {v0, v3, v2, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v3, 0x2

    const-string v4, "VM_ADD"

    invoke-direct {v0, v4, v3, v3}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v4, 0x3

    const-string v5, "VM_SUB"

    invoke-direct {v0, v5, v4, v4}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v5, 0x4

    const-string v6, "VM_JZ"

    invoke-direct {v0, v6, v5, v5}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v6, 0x5

    const-string v7, "VM_JNZ"

    invoke-direct {v0, v7, v6, v6}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v7, 0x6

    const-string v8, "VM_INC"

    invoke-direct {v0, v8, v7, v7}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/4 v8, 0x7

    const-string v9, "VM_DEC"

    invoke-direct {v0, v9, v8, v8}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DEC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v9, 0x8

    const-string v10, "VM_JMP"

    invoke-direct {v0, v10, v9, v9}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v10, 0x9

    const-string v11, "VM_XOR"

    invoke-direct {v0, v11, v10, v10}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XOR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v11, 0xa

    const-string v12, "VM_AND"

    invoke-direct {v0, v12, v11, v11}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_AND:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v12, 0xb

    const-string v13, "VM_OR"

    invoke-direct {v0, v13, v12, v12}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_OR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v13, 0xc

    const-string v14, "VM_TEST"

    invoke-direct {v0, v14, v13, v13}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_TEST:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v14, 0xd

    const-string v15, "VM_JS"

    invoke-direct {v0, v15, v14, v14}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v15, 0xe

    const-string v14, "VM_JNS"

    invoke-direct {v0, v14, v15, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v14, "VM_JB"

    const/16 v15, 0xf

    const/16 v13, 0xf

    invoke-direct {v0, v14, v15, v13}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_JBE"

    const/16 v14, 0x10

    const/16 v15, 0x10

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JBE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_JA"

    const/16 v14, 0x11

    const/16 v15, 0x11

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_JAE"

    const/16 v14, 0x12

    const/16 v15, 0x12

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JAE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_PUSH"

    const/16 v14, 0x13

    const/16 v15, 0x13

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSH:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_POP"

    const/16 v14, 0x14

    const/16 v15, 0x14

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_CALL"

    const/16 v14, 0x15

    const/16 v15, 0x15

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CALL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_RET"

    const/16 v14, 0x16

    const/16 v15, 0x16

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_NOT"

    const/16 v14, 0x17

    const/16 v15, 0x17

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NOT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_SHL"

    const/16 v14, 0x18

    const/16 v15, 0x18

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_SHR"

    const/16 v14, 0x19

    const/16 v15, 0x19

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 25
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_SAR"

    const/16 v14, 0x1a

    const/16 v15, 0x1a

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SAR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_NEG"

    const/16 v14, 0x1b

    const/16 v15, 0x1b

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_PUSHA"

    const/16 v14, 0x1c

    const/16 v15, 0x1c

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_POPA"

    const/16 v14, 0x1d

    const/16 v15, 0x1d

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_PUSHF"

    const/16 v14, 0x1e

    const/16 v15, 0x1e

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_POPF"

    const/16 v14, 0x1f

    const/16 v15, 0x1f

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 26
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_MOVZX"

    const/16 v14, 0x20

    const/16 v15, 0x20

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVZX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_MOVSX"

    const/16 v14, 0x21

    const/16 v15, 0x21

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVSX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_XCHG"

    const/16 v14, 0x22

    const/16 v15, 0x22

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XCHG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_MUL"

    const/16 v14, 0x23

    const/16 v15, 0x23

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MUL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_DIV"

    const/16 v14, 0x24

    const/16 v15, 0x24

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DIV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_ADC"

    const/16 v14, 0x25

    const/16 v15, 0x25

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 27
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_SBB"

    const/16 v14, 0x26

    const/16 v15, 0x26

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_PRINT"

    const/16 v14, 0x27

    const/16 v15, 0x27

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PRINT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 30
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_MOVB"

    const/16 v14, 0x28

    const/16 v15, 0x28

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_MOVD"

    const/16 v14, 0x29

    const/16 v15, 0x29

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_CMPB"

    const/16 v14, 0x2a

    const/16 v15, 0x2a

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_CMPD"

    const/16 v14, 0x2b

    const/16 v15, 0x2b

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 32
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_ADDB"

    const/16 v14, 0x2c

    const/16 v15, 0x2c

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_ADDD"

    const/16 v14, 0x2d

    const/16 v15, 0x2d

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_SUBB"

    const/16 v14, 0x2e

    const/16 v15, 0x2e

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_SUBD"

    const/16 v14, 0x2f

    const/16 v15, 0x2f

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_INCB"

    const/16 v14, 0x30

    const/16 v15, 0x30

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_INCD"

    const/16 v14, 0x31

    const/16 v15, 0x31

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_DECB"

    const/16 v14, 0x32

    const/16 v15, 0x32

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 33
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_DECD"

    const/16 v14, 0x33

    const/16 v15, 0x33

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_NEGB"

    const/16 v14, 0x34

    const/16 v15, 0x34

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_NEGD"

    const/16 v14, 0x35

    const/16 v15, 0x35

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    .line 36
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const-string v13, "VM_STANDARD"

    const/16 v14, 0x36

    const/16 v15, 0x36

    invoke-direct {v0, v13, v14, v15}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_STANDARD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v0, 0x37

    .line 20
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    sget-object v13, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v13, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v6

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v7

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DEC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v8

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v9

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XOR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v10

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_AND:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v11

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_OR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    aput-object v1, v0, v12

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_TEST:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0xc

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0xd

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0xe

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0xf

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JBE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x10

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x11

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JAE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x12

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSH:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x13

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x14

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CALL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x15

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x16

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NOT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x17

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x18

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x19

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SAR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x1a

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x1b

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x1c

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x1d

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x1e

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x1f

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVZX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x20

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVSX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x21

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XCHG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x22

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MUL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x23

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DIV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x24

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x25

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x26

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PRINT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x27

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x28

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x29

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x2a

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x2b

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x2c

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x2d

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x2e

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x2f

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x30

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x31

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x32

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x33

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x34

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x35

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_STANDARD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    const/16 v2, 0x36

    aput-object v1, v0, v2

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 40
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 41
    iput p3, p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->vmCommand:I

    return-void
.end method

.method public static findVMCommand(I)Lir/mahdi/mzip/rar/unpack/vm/VMCommands;
    .locals 1

    .line 45
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 46
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 48
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 49
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 51
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 52
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 54
    :cond_2
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 55
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 57
    :cond_3
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 58
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 60
    :cond_4
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 61
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNZ:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 63
    :cond_5
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 64
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 66
    :cond_6
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DEC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 67
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DEC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 69
    :cond_7
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 70
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JMP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 72
    :cond_8
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XOR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 73
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XOR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 75
    :cond_9
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_AND:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 76
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_AND:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 78
    :cond_a
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_OR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 79
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_OR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 81
    :cond_b
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_TEST:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 82
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_TEST:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 84
    :cond_c
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_d

    .line 85
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 87
    :cond_d
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 88
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JNS:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 90
    :cond_e
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 91
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 93
    :cond_f
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JBE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 94
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JBE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 96
    :cond_10
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 97
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 99
    :cond_11
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JAE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 100
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_JAE:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 102
    :cond_12
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSH:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 103
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSH:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 105
    :cond_13
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_14

    .line 106
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POP:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 108
    :cond_14
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CALL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_15

    .line 109
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CALL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 111
    :cond_15
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_16

    .line 112
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_RET:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 114
    :cond_16
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NOT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_17

    .line 115
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NOT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 117
    :cond_17
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_18

    .line 118
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 120
    :cond_18
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_19

    .line 121
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SHR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 123
    :cond_19
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SAR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 124
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SAR:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 126
    :cond_1a
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1b

    .line 127
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 129
    :cond_1b
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1c

    .line 130
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 132
    :cond_1c
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 133
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPA:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 135
    :cond_1d
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1e

    .line 136
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PUSHF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 138
    :cond_1e
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 139
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_POPF:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 141
    :cond_1f
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVZX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_20

    .line 142
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVZX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 144
    :cond_20
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVSX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_21

    .line 145
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVSX:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 147
    :cond_21
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XCHG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_22

    .line 148
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_XCHG:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 150
    :cond_22
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MUL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_23

    .line 151
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MUL:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 153
    :cond_23
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DIV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_24

    .line 154
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DIV:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 156
    :cond_24
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_25

    .line 157
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADC:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 159
    :cond_25
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_26

    .line 160
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 162
    :cond_26
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PRINT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_27

    .line 163
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_PRINT:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 165
    :cond_27
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_28

    .line 166
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 168
    :cond_28
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_29

    .line 169
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_MOVD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 171
    :cond_29
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2a

    .line 172
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 174
    :cond_2a
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2b

    .line 175
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_CMPD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 177
    :cond_2b
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2c

    .line 178
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 180
    :cond_2c
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2d

    .line 181
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_ADDD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 183
    :cond_2d
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2e

    .line 184
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 186
    :cond_2e
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 187
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_SUBD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 189
    :cond_2f
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_30

    .line 190
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 192
    :cond_30
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_31

    .line 193
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_INCD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 195
    :cond_31
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_32

    .line 196
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 198
    :cond_32
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_33

    .line 199
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_DECD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 201
    :cond_33
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_34

    .line 202
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGB:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 204
    :cond_34
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_35

    .line 205
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_NEGD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    .line 207
    :cond_35
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_STANDARD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->equals(I)Z

    move-result p0

    if-eqz p0, :cond_36

    .line 208
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->VM_STANDARD:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0

    :cond_36
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/vm/VMCommands;
    .locals 1

    .line 20
    const-class v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/vm/VMCommands;
    .locals 1

    .line 20
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object v0
.end method


# virtual methods
.method public equals(I)Z
    .locals 1

    .line 218
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->vmCommand:I

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getVMCommand()I
    .locals 1

    .line 214
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMCommands;->vmCommand:I

    return v0
.end method
