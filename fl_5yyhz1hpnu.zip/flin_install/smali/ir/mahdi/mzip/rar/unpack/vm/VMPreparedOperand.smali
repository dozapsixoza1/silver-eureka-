.class public Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;
.super Ljava/lang/Object;
.source "VMPreparedOperand.java"


# instance fields
.field private Base:I

.field private Data:I

.field private Type:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

.field private offset:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getBase()I
    .locals 1

    .line 28
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->Base:I

    return v0
.end method

.method public getData()I
    .locals 1

    .line 36
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->Data:I

    return v0
.end method

.method public getOffset()I
    .locals 1

    .line 52
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->offset:I

    return v0
.end method

.method public getType()Lir/mahdi/mzip/rar/unpack/vm/VMOpType;
    .locals 1

    .line 44
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->Type:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-object v0
.end method

.method public setBase(I)V
    .locals 0

    .line 32
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->Base:I

    return-void
.end method

.method public setData(I)V
    .locals 0

    .line 40
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->Data:I

    return-void
.end method

.method public setOffset(I)V
    .locals 0

    .line 56
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->offset:I

    return-void
.end method

.method public setType(Lir/mahdi/mzip/rar/unpack/vm/VMOpType;)V
    .locals 0

    .line 48
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;->Type:Lir/mahdi/mzip/rar/unpack/vm/VMOpType;

    return-void
.end method
