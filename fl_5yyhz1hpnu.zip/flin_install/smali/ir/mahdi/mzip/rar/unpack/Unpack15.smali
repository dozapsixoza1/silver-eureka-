.class public abstract Lir/mahdi/mzip/rar/unpack/Unpack15;
.super Lir/mahdi/mzip/rar/unpack/vm/BitInput;
.source "Unpack15.java"


# static fields
.field private static DecHf0:[I = null

.field private static DecHf1:[I = null

.field private static DecHf2:[I = null

.field private static DecHf3:[I = null

.field private static DecHf4:[I = null

.field private static DecL1:[I = null

.field private static DecL2:[I = null

.field private static PosHf0:[I = null

.field private static PosHf1:[I = null

.field private static PosHf2:[I = null

.field private static PosHf3:[I = null

.field private static PosHf4:[I = null

.field private static PosL1:[I = null

.field private static PosL2:[I = null

.field private static final STARTHF0:I = 0x4

.field private static final STARTHF1:I = 0x5

.field private static final STARTHF2:I = 0x5

.field private static final STARTHF3:I = 0x6

.field private static final STARTHF4:I = 0x8

.field private static final STARTL1:I = 0x2

.field private static final STARTL2:I = 0x3

.field static ShortLen1:[I

.field static ShortLen2:[I

.field static ShortXor1:[I

.field static ShortXor2:[I


# instance fields
.field protected AvrLn1:I

.field protected AvrLn2:I

.field protected AvrLn3:I

.field protected AvrPlc:I

.field protected AvrPlcB:I

.field protected Buf60:I

.field protected ChSet:[I

.field protected ChSetA:[I

.field protected ChSetB:[I

.field protected ChSetC:[I

.field protected FlagBuf:I

.field protected FlagsCnt:I

.field protected LCount:I

.field protected MaxDist3:I

.field protected NToPl:[I

.field protected NToPlB:[I

.field protected NToPlC:[I

.field protected Nhfb:I

.field protected Nlzb:I

.field protected NumHuf:I

.field protected Place:[I

.field protected PlaceA:[I

.field protected PlaceB:[I

.field protected PlaceC:[I

.field protected StMode:I

.field protected destUnpSize:J

.field protected lastDist:I

.field protected lastLength:I

.field protected oldDist:[I

.field protected oldDistPtr:I

.field protected readBorder:I

.field protected readTop:I

.field protected suspended:Z

.field protected unpAllBuf:Z

.field protected unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

.field protected unpPtr:I

.field protected unpSomeRead:Z

.field protected window:[B

.field protected wrPtr:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/16 v0, 0x10

    .line 37
    new-array v1, v0, [I

    fill-array-data v1, :array_0

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortLen1:[I

    const/16 v1, 0xf

    .line 38
    new-array v2, v1, [I

    fill-array-data v2, :array_1

    sput-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortXor1:[I

    .line 40
    new-array v0, v0, [I

    fill-array-data v0, :array_2

    sput-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortLen2:[I

    .line 41
    new-array v0, v1, [I

    fill-array-data v0, :array_3

    sput-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortXor2:[I

    const/16 v0, 0xb

    .line 43
    new-array v0, v0, [I

    fill-array-data v0, :array_4

    sput-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecL1:[I

    const/16 v0, 0xd

    .line 45
    new-array v1, v0, [I

    fill-array-data v1, :array_5

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosL1:[I

    const/16 v1, 0xa

    .line 46
    new-array v1, v1, [I

    fill-array-data v1, :array_6

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecL2:[I

    .line 48
    new-array v1, v0, [I

    fill-array-data v1, :array_7

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosL2:[I

    const/16 v1, 0x9

    .line 49
    new-array v1, v1, [I

    fill-array-data v1, :array_8

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf0:[I

    .line 51
    new-array v1, v0, [I

    fill-array-data v1, :array_9

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf0:[I

    const/16 v1, 0x8

    .line 53
    new-array v2, v1, [I

    fill-array-data v2, :array_a

    sput-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf1:[I

    .line 55
    new-array v2, v0, [I

    fill-array-data v2, :array_b

    sput-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf1:[I

    .line 57
    new-array v1, v1, [I

    fill-array-data v1, :array_c

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf2:[I

    .line 59
    new-array v1, v0, [I

    fill-array-data v1, :array_d

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf2:[I

    const/4 v1, 0x7

    .line 60
    new-array v1, v1, [I

    fill-array-data v1, :array_e

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf3:[I

    .line 62
    new-array v1, v0, [I

    fill-array-data v1, :array_f

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf3:[I

    const/4 v1, 0x6

    .line 63
    new-array v1, v1, [I

    fill-array-data v1, :array_10

    sput-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf4:[I

    .line 65
    new-array v0, v0, [I

    fill-array-data v0, :array_11

    sput-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf4:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x3
        0x4
        0x4
        0x5
        0x6
        0x7
        0x8
        0x8
        0x4
        0x4
        0x5
        0x6
        0x6
        0x4
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0xa0
        0xd0
        0xe0
        0xf0
        0xf8
        0xfc
        0xfe
        0xff
        0xc0
        0x80
        0x90
        0x98
        0x9c
        0xb0
    .end array-data

    :array_2
    .array-data 4
        0x2
        0x3
        0x3
        0x3
        0x4
        0x4
        0x5
        0x6
        0x6
        0x4
        0x4
        0x5
        0x6
        0x6
        0x4
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x40
        0x60
        0xa0
        0xd0
        0xe0
        0xf0
        0xf8
        0xfc
        0xc0
        0x80
        0x90
        0x98
        0x9c
        0xb0
    .end array-data

    :array_4
    .array-data 4
        0x8000
        0xa000
        0xc000
        0xd000
        0xe000
        0xea00
        0xee00
        0xf000
        0xf200
        0xf200
        0xffff
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x0
        0x0
        0x2
        0x3
        0x5
        0x7
        0xb
        0x10
        0x14
        0x18
        0x20
        0x20
    .end array-data

    :array_6
    .array-data 4
        0xa000
        0xc000
        0xd000
        0xe000
        0xea00
        0xee00
        0xf000
        0xf200
        0xf240
        0xffff
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x5
        0x7
        0x9
        0xd
        0x12
        0x16
        0x1a
        0x22
        0x24
    .end array-data

    :array_8
    .array-data 4
        0x8000
        0xc000
        0xe000
        0xf200
        0xf200
        0xf200
        0xf200
        0xf200
        0xffff
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x8
        0x10
        0x18
        0x21
        0x21
        0x21
        0x21
        0x21
    .end array-data

    :array_a
    .array-data 4
        0x2000
        0xc000
        0xe000
        0xf000
        0xf200
        0xf200
        0xf7e0
        0xffff
    .end array-data

    :array_b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4
        0x2c
        0x3c
        0x4c
        0x50
        0x50
        0x7f
    .end array-data

    :array_c
    .array-data 4
        0x1000
        0x2400
        0x8000
        0xc000
        0xfa00
        0xffff
        0xffff
        0xffff
    .end array-data

    :array_d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x2
        0x7
        0x35
        0x75
        0xe9
        0x0
        0x0
    .end array-data

    :array_e
    .array-data 4
        0x800
        0x2400
        0xee00
        0xfe80
        0xffff
        0xffff
        0xffff
    .end array-data

    :array_f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x2
        0x10
        0xda
        0xfb
        0x0
        0x0
    .end array-data

    :array_10
    .array-data 4
        0xff00
        0xffff
        0xffff
        0xffff
        0xffff
        0xffff
    .end array-data

    :array_11
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xff
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    .line 28
    invoke-direct {p0}, Lir/mahdi/mzip/rar/unpack/vm/BitInput;-><init>()V

    const/4 v0, 0x4

    .line 74
    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDist:[I

    const/16 v0, 0x100

    .line 77
    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSet:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetA:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetB:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetC:[I

    .line 79
    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Place:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceA:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceB:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceC:[I

    .line 81
    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPl:[I

    new-array v1, v0, [I

    iput-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlB:[I

    new-array v0, v0, [I

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlC:[I

    return-void
.end method

.method private getShortLen1(I)I
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    .line 191
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Buf60:I

    add-int/lit8 p1, p1, 0x3

    goto :goto_0

    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortLen1:[I

    aget p1, v0, p1

    :goto_0
    return p1
.end method

.method private getShortLen2(I)I
    .locals 1

    const/4 v0, 0x3

    if-ne p1, v0, :cond_0

    .line 195
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Buf60:I

    add-int/2addr p1, v0

    goto :goto_0

    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortLen2:[I

    aget p1, v0, p1

    :goto_0
    return p1
.end method


# virtual methods
.method protected corrHuff([I[I)V
    .locals 7

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    :goto_0
    const/16 v4, 0x20

    if-ltz v2, :cond_1

    move v5, v3

    const/4 v3, 0x0

    :goto_1
    if-ge v3, v4, :cond_0

    .line 512
    aget v6, p1, v5

    and-int/lit16 v6, v6, -0x100

    or-int/2addr v6, v2

    aput v6, p1, v5

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, -0x1

    move v3, v5

    goto :goto_0

    .line 516
    :cond_1
    invoke-static {p2, v1}, Ljava/util/Arrays;->fill([II)V

    const/4 p1, 0x6

    :goto_2
    if-ltz p1, :cond_2

    rsub-int/lit8 v1, p1, 0x7

    mul-int/lit8 v1, v1, 0x20

    .line 518
    aput v1, p2, p1

    add-int/lit8 p1, p1, -0x1

    goto :goto_2

    :cond_2
    return-void
.end method

.method protected decodeNum(II[I[I)I
    .locals 3

    const v0, 0xfff0

    and-int/2addr p1, v0

    const/4 v0, 0x0

    move v1, p2

    const/4 p2, 0x0

    .line 532
    :goto_0
    aget v2, p3, p2

    if-gt v2, p1, :cond_0

    add-int/lit8 v1, v1, 0x1

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    .line 535
    :cond_0
    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    if-eqz p2, :cond_1

    add-int/lit8 p2, p2, -0x1

    .line 536
    aget v0, p3, p2

    :cond_1
    sub-int/2addr p1, v0

    rsub-int/lit8 p2, v1, 0x10

    ushr-int/2addr p1, p2

    aget p2, p4, v1

    add-int/2addr p1, p2

    return p1
.end method

.method protected getFlagsBuf()V
    .locals 7

    .line 463
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    sget-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf2:[I

    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf2:[I

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v3, v1, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    .line 466
    :goto_0
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetC:[I

    aget v2, v1, v0

    ushr-int/lit8 v3, v2, 0x8

    .line 467
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    .line 468
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlC:[I

    add-int/lit8 v4, v2, 0x1

    and-int/lit16 v2, v2, 0xff

    aget v5, v3, v2

    add-int/lit8 v6, v5, 0x1

    aput v6, v3, v2

    and-int/lit16 v2, v4, 0xff

    if-eqz v2, :cond_0

    .line 475
    aget v2, v1, v5

    aput v2, v1, v0

    .line 476
    aput v4, v1, v5

    return-void

    .line 472
    :cond_0
    invoke-virtual {p0, v1, v3}, Lir/mahdi/mzip/rar/unpack/Unpack15;->corrHuff([I[I)V

    goto :goto_0
.end method

.method protected huffDecode()V
    .locals 9

    .line 389
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    .line 391
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    const/4 v2, 0x4

    const/16 v3, 0x8

    const/4 v4, 0x5

    const/16 v5, 0x75ff

    if-le v1, v5, :cond_0

    .line 392
    sget-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf4:[I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf4:[I

    invoke-virtual {p0, v0, v3, v1, v5}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v1

    goto :goto_0

    :cond_0
    const/16 v5, 0x5dff

    if-le v1, v5, :cond_1

    const/4 v1, 0x6

    .line 395
    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf3:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf3:[I

    invoke-virtual {p0, v0, v1, v5, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v1

    goto :goto_0

    :cond_1
    const/16 v5, 0x35ff

    if-le v1, v5, :cond_2

    .line 398
    sget-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf2:[I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf2:[I

    invoke-virtual {p0, v0, v4, v1, v5}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v1

    goto :goto_0

    :cond_2
    const/16 v5, 0xdff

    if-le v1, v5, :cond_3

    .line 401
    sget-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf1:[I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf1:[I

    invoke-virtual {p0, v0, v4, v1, v5}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v1

    goto :goto_0

    .line 404
    :cond_3
    sget-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf0:[I

    sget-object v5, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf0:[I

    invoke-virtual {p0, v0, v2, v1, v5}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v1

    :goto_0
    const/16 v5, 0xff

    and-int/2addr v1, v5

    .line 411
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->StMode:I

    const/16 v7, 0x10

    const/4 v8, 0x1

    if-eqz v6, :cond_7

    if-nez v1, :cond_4

    const/16 v6, 0xfff

    if-le v0, v6, :cond_4

    const/16 v1, 0x100

    :cond_4
    const/4 v0, -0x1

    add-int/2addr v1, v0

    if-ne v1, v0, :cond_8

    .line 416
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    .line 417
    invoke-virtual {p0, v8}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    const v1, 0x8000

    and-int/2addr v1, v0

    if-eqz v1, :cond_5

    const/4 v0, 0x0

    .line 419
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->StMode:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NumHuf:I

    return-void

    :cond_5
    and-int/lit16 v0, v0, 0x4000

    if-eqz v0, :cond_6

    goto :goto_1

    :cond_6
    const/4 v2, 0x3

    .line 423
    :goto_1
    invoke-virtual {p0, v8}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    .line 424
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    sget-object v1, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf2:[I

    sget-object v3, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf2:[I

    invoke-virtual {p0, v0, v4, v1, v3}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    shl-int/2addr v0, v4

    .line 425
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v1

    ushr-int/lit8 v1, v1, 0xb

    or-int/2addr v0, v1

    .line 426
    invoke-virtual {p0, v4}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    .line 427
    invoke-virtual {p0, v0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void

    .line 432
    :cond_7
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NumHuf:I

    add-int/lit8 v2, v0, 0x1

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NumHuf:I

    if-lt v0, v7, :cond_8

    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    if-nez v0, :cond_8

    .line 433
    iput v8, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->StMode:I

    .line 436
    :cond_8
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    add-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    .line 437
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    ushr-int/lit8 v2, v0, 0x8

    sub-int/2addr v0, v2

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    .line 438
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    add-int/2addr v0, v7

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    .line 439
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    if-le v0, v5, :cond_9

    const/16 v0, 0x90

    .line 440
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    .line 441
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    ushr-int/2addr v0, v8

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    .line 444
    :cond_9
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->window:[B

    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    add-int/lit8 v4, v2, 0x1

    iput v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSet:[I

    aget v4, v4, v1

    ushr-int/lit8 v3, v4, 0x8

    int-to-byte v3, v3

    aput-byte v3, v0, v2

    .line 445
    iget-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    const-wide/16 v6, 0x1

    sub-long/2addr v2, v6

    iput-wide v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    .line 448
    :goto_2
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSet:[I

    aget v2, v0, v1

    .line 449
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPl:[I

    add-int/lit8 v4, v2, 0x1

    and-int/2addr v2, v5

    aget v6, v3, v2

    add-int/lit8 v7, v6, 0x1

    aput v7, v3, v2

    and-int/lit16 v2, v4, 0xff

    const/16 v7, 0xa1

    if-le v2, v7, :cond_a

    .line 451
    invoke-virtual {p0, v0, v3}, Lir/mahdi/mzip/rar/unpack/Unpack15;->corrHuff([I[I)V

    goto :goto_2

    .line 457
    :cond_a
    aget v2, v0, v6

    aput v2, v0, v1

    .line 458
    aput v4, v0, v6

    return-void
.end method

.method protected initHuff()V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    const/16 v2, 0x100

    if-ge v1, v2, :cond_0

    .line 495
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Place:[I

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceA:[I

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceB:[I

    aput v1, v4, v1

    aput v1, v3, v1

    aput v1, v2, v1

    .line 496
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceC:[I

    xor-int/lit8 v3, v1, -0x1

    add-int/lit8 v3, v3, 0x1

    and-int/lit16 v3, v3, 0xff

    aput v3, v2, v1

    .line 497
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSet:[I

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetB:[I

    shl-int/lit8 v5, v1, 0x8

    aput v5, v4, v1

    aput v5, v2, v1

    .line 498
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetA:[I

    aput v1, v2, v1

    .line 499
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetC:[I

    shl-int/lit8 v3, v3, 0x8

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 502
    :cond_0
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPl:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([II)V

    .line 503
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlB:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([II)V

    .line 504
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlC:[I

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([II)V

    .line 505
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetB:[I

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlB:[I

    invoke-virtual {p0, v0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->corrHuff([I[I)V

    return-void
.end method

.method protected longLZ()V
    .locals 15

    const/4 v0, 0x0

    .line 297
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NumHuf:I

    .line 298
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    const/16 v2, 0x10

    add-int/2addr v1, v2

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    .line 299
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    const/16 v3, 0xff

    const/4 v4, 0x1

    if-le v1, v3, :cond_0

    const/16 v1, 0x90

    .line 300
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    .line 301
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    ushr-int/2addr v1, v4

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    .line 303
    :cond_0
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    .line 305
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v5

    .line 306
    iget v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    const/16 v7, 0x7a

    const/16 v8, 0x100

    const/16 v9, 0x40

    const/4 v10, 0x3

    if-lt v6, v7, :cond_1

    .line 307
    sget-object v0, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecL2:[I

    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosL2:[I

    invoke-virtual {p0, v5, v10, v0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v5

    goto :goto_1

    :cond_1
    if-lt v6, v9, :cond_2

    const/4 v0, 0x2

    .line 310
    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecL1:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosL1:[I

    invoke-virtual {p0, v5, v0, v2, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v5

    goto :goto_1

    :cond_2
    if-ge v5, v8, :cond_3

    .line 314
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    goto :goto_1

    :cond_3
    :goto_0
    shl-int v2, v5, v0

    const v6, 0x8000

    and-int/2addr v2, v6

    if-nez v2, :cond_4

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    add-int/lit8 v2, v0, 0x1

    .line 318
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    move v5, v0

    .line 322
    :goto_1
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    add-int/2addr v0, v5

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    .line 323
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    ushr-int/lit8 v2, v0, 0x5

    sub-int/2addr v0, v2

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    .line 325
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    .line 326
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlcB:I

    const/16 v6, 0x28ff

    const/4 v7, 0x4

    const/4 v11, 0x5

    if-le v2, v6, :cond_5

    .line 327
    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf2:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf2:[I

    invoke-virtual {p0, v0, v11, v2, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    goto :goto_2

    :cond_5
    const/16 v6, 0x6ff

    if-le v2, v6, :cond_6

    .line 330
    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf1:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf1:[I

    invoke-virtual {p0, v0, v11, v2, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    goto :goto_2

    .line 332
    :cond_6
    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf0:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf0:[I

    invoke-virtual {p0, v0, v7, v2, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    .line 335
    :goto_2
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlcB:I

    add-int/2addr v2, v0

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlcB:I

    .line 336
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlcB:I

    shr-int/lit8 v6, v2, 0x8

    sub-int/2addr v2, v6

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlcB:I

    .line 338
    :goto_3
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetB:[I

    and-int/lit16 v6, v0, 0xff

    aget v6, v2, v6

    .line 339
    iget-object v11, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NToPlB:[I

    add-int/lit8 v12, v6, 0x1

    and-int/2addr v6, v3

    aget v13, v11, v6

    add-int/lit8 v14, v13, 0x1

    aput v14, v11, v6

    and-int/lit16 v6, v12, 0xff

    if-nez v6, :cond_7

    .line 341
    invoke-virtual {p0, v2, v11}, Lir/mahdi/mzip/rar/unpack/Unpack15;->corrHuff([I[I)V

    goto :goto_3

    .line 347
    :cond_7
    aget v3, v2, v13

    aput v3, v2, v0

    .line 348
    aput v12, v2, v13

    const v0, 0xff00

    and-int/2addr v0, v12

    .line 350
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v2

    ushr-int/lit8 v2, v2, 0x8

    or-int/2addr v0, v2

    ushr-int/2addr v0, v4

    const/4 v2, 0x7

    .line 351
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    .line 353
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    if-eq v5, v4, :cond_9

    if-eq v5, v7, :cond_9

    if-nez v5, :cond_8

    .line 355
    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->MaxDist3:I

    if-gt v0, v3, :cond_8

    add-int/lit8 v3, v2, 0x1

    .line 356
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    .line 357
    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    shr-int/lit8 v4, v3, 0x8

    sub-int/2addr v3, v4

    iput v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    goto :goto_4

    .line 359
    :cond_8
    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    if-lez v3, :cond_9

    sub-int/2addr v3, v4

    .line 360
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    :cond_9
    :goto_4
    add-int/2addr v5, v10

    .line 365
    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->MaxDist3:I

    if-lt v0, v3, :cond_a

    add-int/lit8 v5, v5, 0x1

    :cond_a
    if-gt v0, v8, :cond_b

    add-int/lit8 v5, v5, 0x8

    :cond_b
    const/16 v3, 0xb0

    if-gt v2, v3, :cond_d

    .line 371
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    const/16 v3, 0x2a00

    if-lt v2, v3, :cond_c

    if-ge v1, v9, :cond_c

    goto :goto_5

    :cond_c
    const/16 v1, 0x2001

    .line 374
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->MaxDist3:I

    goto :goto_6

    :cond_d
    :goto_5
    const/16 v1, 0x7f00

    .line 372
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->MaxDist3:I

    .line 376
    :goto_6
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDist:[I

    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    aput v0, v1, v2

    .line 377
    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    and-int/2addr v1, v10

    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    .line 378
    iput v5, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastLength:I

    .line 379
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastDist:I

    .line 380
    invoke-virtual {p0, v0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void
.end method

.method protected oldCopyString(II)V
    .locals 4

    .line 523
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    int-to-long v2, p2

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    :goto_0
    add-int/lit8 v0, p2, -0x1

    if-eqz p2, :cond_0

    .line 525
    iget-object p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->window:[B

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    sub-int v2, v1, p1

    const v3, 0x3fffff

    and-int/2addr v2, v3

    aget-byte v2, p2, v2

    aput-byte v2, p2, v1

    add-int/lit8 v1, v1, 0x1

    and-int p2, v1, v3

    .line 526
    iput p2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    move p2, v0

    goto :goto_0

    :cond_0
    return-void
.end method

.method protected oldUnpInitData(Z)V
    .locals 1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    .line 481
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Buf60:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NumHuf:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn3:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn2:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn1:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlcB:I

    const/16 p1, 0x3500

    .line 482
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrPlc:I

    const/16 p1, 0x2001

    .line 483
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->MaxDist3:I

    const/16 p1, 0x80

    .line 484
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    .line 486
    :cond_0
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    .line 487
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    .line 488
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->StMode:I

    .line 489
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    .line 490
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    return-void
.end method

.method protected oldUnpWriteBuf()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 540
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->wrPtr:I

    const/4 v2, 0x1

    if-eq v0, v1, :cond_0

    .line 541
    iput-boolean v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpSomeRead:Z

    .line 543
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->wrPtr:I

    if-ge v0, v1, :cond_1

    .line 544
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->window:[B

    neg-int v4, v1

    const v5, 0x3fffff

    and-int/2addr v4, v5

    invoke-virtual {v0, v3, v1, v4}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpWrite([BII)V

    .line 545
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->window:[B

    const/4 v3, 0x0

    iget v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    invoke-virtual {v0, v1, v3, v4}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpWrite([BII)V

    .line 546
    iput-boolean v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpAllBuf:Z

    goto :goto_0

    .line 548
    :cond_1
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->window:[B

    sub-int/2addr v0, v1

    invoke-virtual {v2, v3, v1, v0}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpWrite([BII)V

    .line 550
    :goto_0
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->wrPtr:I

    return-void
.end method

.method protected shortLZ()V
    .locals 10

    const/4 v0, 0x0

    .line 203
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->NumHuf:I

    .line 205
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v1

    .line 206
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    const v3, 0x8000

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ne v2, v4, :cond_1

    .line 207
    invoke-virtual {p0, v5}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    if-lt v1, v3, :cond_0

    .line 209
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastDist:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastLength:I

    invoke-virtual {p0, v0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void

    :cond_0
    shl-int/lit8 v1, v1, 0x1

    .line 213
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    :cond_1
    ushr-int/lit8 v1, v1, 0x8

    .line 216
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn1:I

    const/16 v6, 0x25

    const/16 v7, 0xff

    const/4 v8, -0x1

    if-ge v2, v6, :cond_3

    const/4 v2, 0x0

    .line 218
    :goto_0
    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortXor1:[I

    aget v6, v6, v2

    xor-int/2addr v6, v1

    invoke-direct {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getShortLen1(I)I

    move-result v9

    ushr-int v9, v7, v9

    xor-int/2addr v9, v8

    and-int/2addr v6, v9

    if-nez v6, :cond_2

    .line 222
    invoke-direct {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getShortLen1(I)I

    move-result v1

    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    goto :goto_2

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    .line 225
    :goto_1
    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->ShortXor2:[I

    aget v6, v6, v2

    xor-int/2addr v6, v1

    invoke-direct {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getShortLen2(I)I

    move-result v9

    shr-int v9, v7, v9

    xor-int/2addr v9, v8

    and-int/2addr v6, v9

    if-nez v6, :cond_b

    .line 229
    invoke-direct {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getShortLen2(I)I

    move-result v1

    invoke-virtual {p0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    :goto_2
    const/4 v1, 0x5

    const/16 v6, 0x9

    const/4 v9, 0x3

    if-lt v2, v6, :cond_9

    if-ne v2, v6, :cond_4

    .line 234
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    add-int/2addr v0, v5

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    .line 235
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastDist:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastLength:I

    invoke-virtual {p0, v0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void

    :cond_4
    const/16 v6, 0xe

    if-ne v2, v6, :cond_5

    .line 239
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    .line 240
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    sget-object v2, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecL2:[I

    sget-object v4, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosL2:[I

    invoke-virtual {p0, v0, v9, v2, v4}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    add-int/2addr v0, v1

    .line 241
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v1

    shr-int/2addr v1, v5

    or-int/2addr v1, v3

    const/16 v2, 0xf

    .line 242
    invoke-virtual {p0, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->faddbits(I)V

    .line 243
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastLength:I

    .line 244
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastDist:I

    .line 245
    invoke-virtual {p0, v1, v0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void

    .line 249
    :cond_5
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    .line 251
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDist:[I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    add-int/lit8 v3, v2, -0x9

    sub-int/2addr v1, v3

    and-int/2addr v1, v9

    aget v0, v0, v1

    .line 252
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v1

    sget-object v3, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecL1:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosL1:[I

    invoke-virtual {p0, v1, v4, v3, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v1

    add-int/2addr v1, v4

    const/16 v3, 0x101

    if-ne v1, v3, :cond_6

    const/16 v3, 0xa

    if-ne v2, v3, :cond_6

    .line 254
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Buf60:I

    xor-int/2addr v0, v5

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Buf60:I

    return-void

    :cond_6
    const/16 v2, 0x100

    if-le v0, v2, :cond_7

    add-int/lit8 v1, v1, 0x1

    .line 259
    :cond_7
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->MaxDist3:I

    if-lt v0, v2, :cond_8

    add-int/lit8 v1, v1, 0x1

    .line 262
    :cond_8
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDist:[I

    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    add-int/lit8 v4, v3, 0x1

    iput v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    aput v0, v2, v3

    .line 263
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    and-int/2addr v2, v9

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    .line 264
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastLength:I

    .line 265
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastDist:I

    .line 266
    invoke-virtual {p0, v0, v1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void

    .line 270
    :cond_9
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->LCount:I

    .line 271
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn1:I

    add-int/2addr v0, v2

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn1:I

    .line 272
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn1:I

    shr-int/lit8 v3, v0, 0x4

    sub-int/2addr v0, v3

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->AvrLn1:I

    .line 274
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->fgetbits()I

    move-result v0

    sget-object v3, Lir/mahdi/mzip/rar/unpack/Unpack15;->DecHf2:[I

    sget-object v6, Lir/mahdi/mzip/rar/unpack/Unpack15;->PosHf2:[I

    invoke-virtual {p0, v0, v1, v3, v6}, Lir/mahdi/mzip/rar/unpack/Unpack15;->decodeNum(II[I[I)I

    move-result v0

    and-int/2addr v0, v7

    .line 275
    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->ChSetA:[I

    aget v3, v1, v0

    add-int/2addr v0, v8

    if-eq v0, v8, :cond_a

    .line 277
    iget-object v6, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->PlaceA:[I

    aget v7, v6, v3

    sub-int/2addr v7, v5

    aput v7, v6, v3

    .line 278
    aget v7, v1, v0

    .line 279
    aget v8, v6, v7

    add-int/2addr v8, v5

    aput v8, v6, v7

    add-int/lit8 v6, v0, 0x1

    .line 280
    aput v7, v1, v6

    .line 281
    aput v3, v1, v0

    :cond_a
    add-int/2addr v2, v4

    .line 284
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDist:[I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    add-int/lit8 v4, v1, 0x1

    iput v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    add-int/2addr v3, v5

    aput v3, v0, v1

    .line 285
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    and-int/2addr v0, v9

    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldDistPtr:I

    .line 286
    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastLength:I

    .line 287
    iput v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->lastDist:I

    .line 288
    invoke-virtual {p0, v3, v2}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldCopyString(II)V

    return-void

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_1
.end method

.method protected abstract unpInitData(Z)V
.end method

.method protected unpReadBuf()Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 164
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inAddr:I

    sub-int/2addr v0, v1

    const/4 v1, 0x0

    if-gez v0, :cond_0

    return v1

    .line 168
    :cond_0
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inAddr:I

    const/16 v3, 0x4000

    if-le v2, v3, :cond_2

    if-lez v0, :cond_1

    .line 174
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inBuf:[B

    iget v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inAddr:I

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inBuf:[B

    invoke-static {v2, v3, v4, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 176
    :cond_1
    iput v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inAddr:I

    .line 177
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    goto :goto_0

    .line 179
    :cond_2
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    .line 182
    :goto_0
    iget-object v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpIO:Lir/mahdi/mzip/rar/unpack/ComprDataIO;

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inBuf:[B

    const v4, 0x8000

    sub-int/2addr v4, v0

    and-int/lit8 v4, v4, -0x10

    invoke-virtual {v2, v3, v0, v4}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpRead([BII)I

    move-result v0

    if-lez v0, :cond_3

    .line 184
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    add-int/2addr v2, v0

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    .line 186
    :cond_3
    iget v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    add-int/lit8 v2, v2, -0x1e

    iput v2, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readBorder:I

    const/4 v2, -0x1

    if-eq v0, v2, :cond_4

    const/4 v1, 0x1

    :cond_4
    return v1
.end method

.method protected unpack15(Z)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    .line 91
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->suspended:Z

    if-eqz v0, :cond_0

    .line 92
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->wrPtr:I

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    goto :goto_1

    .line 94
    :cond_0
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpInitData(Z)V

    .line 95
    invoke-virtual {p0, p1}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldUnpInitData(Z)V

    .line 96
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpReadBuf()Z

    if-nez p1, :cond_1

    .line 98
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->initHuff()V

    const/4 p1, 0x0

    .line 99
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    goto :goto_0

    .line 101
    :cond_1
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->wrPtr:I

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    .line 103
    :goto_0
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    const-wide/16 v2, 0x1

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    .line 105
    :goto_1
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    const-wide/16 v2, 0x0

    cmp-long p1, v0, v2

    if-ltz p1, :cond_2

    .line 106
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getFlagsBuf()V

    const/16 p1, 0x8

    .line 107
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    .line 110
    :cond_2
    :goto_2
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->destUnpSize:J

    cmp-long p1, v0, v2

    if-ltz p1, :cond_c

    .line 111
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    const v0, 0x3fffff

    and-int/2addr p1, v0

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    .line 113
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->inAddr:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->readTop:I

    add-int/lit8 v1, v1, -0x1e

    if-le p1, v1, :cond_3

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpReadBuf()Z

    move-result p1

    if-nez p1, :cond_3

    goto/16 :goto_3

    .line 116
    :cond_3
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->wrPtr:I

    iget v1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->unpPtr:I

    sub-int v4, p1, v1

    and-int/2addr v0, v4

    const/16 v4, 0x10e

    if-ge v0, v4, :cond_4

    if-eq p1, v1, :cond_4

    .line 118
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldUnpWriteBuf()V

    .line 119
    iget-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->suspended:Z

    if-eqz p1, :cond_4

    return-void

    .line 123
    :cond_4
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->StMode:I

    if-eqz p1, :cond_5

    .line 124
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->huffDecode()V

    goto :goto_2

    .line 128
    :cond_5
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    const/4 v0, 0x7

    if-gez p1, :cond_6

    .line 129
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getFlagsBuf()V

    .line 130
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    .line 133
    :cond_6
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    and-int/lit16 v1, p1, 0x80

    if-eqz v1, :cond_8

    shl-int/lit8 p1, p1, 0x1

    .line 134
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    .line 135
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    if-le p1, v0, :cond_7

    .line 136
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->longLZ()V

    goto :goto_2

    .line 138
    :cond_7
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->huffDecode()V

    goto :goto_2

    :cond_8
    shl-int/lit8 p1, p1, 0x1

    .line 141
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    .line 142
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    if-gez p1, :cond_9

    .line 143
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->getFlagsBuf()V

    .line 144
    iput v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagsCnt:I

    .line 146
    :cond_9
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    and-int/lit16 v0, p1, 0x80

    if-eqz v0, :cond_b

    shl-int/lit8 p1, p1, 0x1

    .line 147
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    .line 148
    iget p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nlzb:I

    iget v0, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->Nhfb:I

    if-le p1, v0, :cond_a

    .line 149
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->huffDecode()V

    goto/16 :goto_2

    .line 151
    :cond_a
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->longLZ()V

    goto/16 :goto_2

    :cond_b
    shl-int/lit8 p1, p1, 0x1

    .line 154
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/Unpack15;->FlagBuf:I

    .line 155
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->shortLZ()V

    goto/16 :goto_2

    .line 159
    :cond_c
    :goto_3
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/Unpack15;->oldUnpWriteBuf()V

    return-void
.end method
