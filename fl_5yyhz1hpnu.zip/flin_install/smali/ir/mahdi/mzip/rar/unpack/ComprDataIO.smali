.class public Lir/mahdi/mzip/rar/unpack/ComprDataIO;
.super Ljava/lang/Object;
.source "ComprDataIO.java"


# instance fields
.field private final archive:Lir/mahdi/mzip/rar/Archive;

.field private curPackRead:J

.field private curPackWrite:J

.field private curUnpRead:J

.field private curUnpWrite:J

.field private currentCommand:C

.field private decryption:I

.field private encryption:I

.field private inputStream:Ljava/io/InputStream;

.field private lastPercent:I

.field private nextVolumeMissing:Z

.field private outputStream:Ljava/io/OutputStream;

.field private packFileCRC:J

.field private packVolume:Z

.field private packedCRC:J

.field private processedArcSize:J

.field private skipUnpCRC:Z

.field private subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

.field private testMode:Z

.field private totalArcSize:J

.field private totalPackRead:J

.field private unpArcSize:J

.field private unpFileCRC:J

.field private unpPackedSize:J

.field private unpVolume:Z


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/Archive;)V
    .locals 0

    .line 77
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 78
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    return-void
.end method


# virtual methods
.method public getCurPackRead()J
    .locals 2

    .line 205
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackRead:J

    return-wide v0
.end method

.method public getCurPackWrite()J
    .locals 2

    .line 213
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackWrite:J

    return-wide v0
.end method

.method public getCurUnpRead()J
    .locals 2

    .line 221
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpRead:J

    return-wide v0
.end method

.method public getCurUnpWrite()J
    .locals 2

    .line 229
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpWrite:J

    return-wide v0
.end method

.method public getDecryption()I
    .locals 1

    .line 237
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->decryption:I

    return v0
.end method

.method public getEncryption()I
    .locals 1

    .line 245
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->encryption:I

    return v0
.end method

.method public getPackFileCRC()J
    .locals 2

    .line 269
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packFileCRC:J

    return-wide v0
.end method

.method public getPackedCRC()J
    .locals 2

    .line 261
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packedCRC:J

    return-wide v0
.end method

.method public getProcessedArcSize()J
    .locals 2

    .line 285
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->processedArcSize:J

    return-wide v0
.end method

.method public getSubHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;
    .locals 1

    .line 333
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

    return-object v0
.end method

.method public getTotalArcSize()J
    .locals 2

    .line 293
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->totalArcSize:J

    return-wide v0
.end method

.method public getTotalPackRead()J
    .locals 2

    .line 301
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->totalPackRead:J

    return-wide v0
.end method

.method public getUnpArcSize()J
    .locals 2

    .line 309
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpArcSize:J

    return-wide v0
.end method

.method public getUnpFileCRC()J
    .locals 2

    .line 317
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    return-wide v0
.end method

.method public init(Lir/mahdi/mzip/rar/rarfile/FileHeader;)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 103
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getPositionInFile()J

    move-result-wide v0

    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getHeaderSize()S

    move-result v2

    int-to-long v2, v2

    add-long v6, v0, v2

    .line 104
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFullPackSize()J

    move-result-wide v0

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    .line 105
    new-instance v0, Lir/mahdi/mzip/rar/io/ReadOnlyAccessInputStream;

    iget-object v1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v1}, Lir/mahdi/mzip/rar/Archive;->getRof()Lir/mahdi/mzip/rar/io/IReadOnlyAccess;

    move-result-object v5

    iget-wide v1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    add-long v8, v6, v1

    move-object v4, v0

    invoke-direct/range {v4 .. v9}, Lir/mahdi/mzip/rar/io/ReadOnlyAccessInputStream;-><init>(Lir/mahdi/mzip/rar/io/IReadOnlyAccess;JJ)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->inputStream:Ljava/io/InputStream;

    .line 107
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

    const-wide/16 v0, 0x0

    .line 108
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpRead:J

    .line 109
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackWrite:J

    const-wide/16 v0, -0x1

    .line 110
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packedCRC:J

    return-void
.end method

.method public init(Ljava/io/OutputStream;)V
    .locals 4

    .line 82
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->outputStream:Ljava/io/OutputStream;

    const-wide/16 v0, 0x0

    .line 83
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    const/4 p1, 0x0

    .line 84
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->testMode:Z

    .line 85
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->skipUnpCRC:Z

    .line 86
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packVolume:Z

    .line 87
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpVolume:Z

    .line 88
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->nextVolumeMissing:Z

    .line 90
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->encryption:I

    .line 91
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->decryption:I

    .line 92
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->totalPackRead:J

    .line 93
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpWrite:J

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpRead:J

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackWrite:J

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackRead:J

    const-wide/16 v2, -0x1

    .line 94
    iput-wide v2, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packedCRC:J

    iput-wide v2, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    iput-wide v2, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packFileCRC:J

    const/4 v2, -0x1

    .line 95
    iput v2, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->lastPercent:I

    const/4 v2, 0x0

    .line 96
    iput-object v2, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

    .line 98
    iput-char p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->currentCommand:C

    .line 99
    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->totalArcSize:J

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->processedArcSize:J

    return-void
.end method

.method public isNextVolumeMissing()Z
    .locals 1

    .line 253
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->nextVolumeMissing:Z

    return v0
.end method

.method public isPackVolume()Z
    .locals 1

    .line 277
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packVolume:Z

    return v0
.end method

.method public isUnpVolume()Z
    .locals 1

    .line 325
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpVolume:Z

    return v0
.end method

.method public setCurPackRead(J)V
    .locals 0

    .line 209
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackRead:J

    return-void
.end method

.method public setCurPackWrite(J)V
    .locals 0

    .line 217
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curPackWrite:J

    return-void
.end method

.method public setCurUnpRead(J)V
    .locals 0

    .line 225
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpRead:J

    return-void
.end method

.method public setCurUnpWrite(J)V
    .locals 0

    .line 233
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpWrite:J

    return-void
.end method

.method public setDecryption(I)V
    .locals 0

    .line 241
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->decryption:I

    return-void
.end method

.method public setEncryption(I)V
    .locals 0

    .line 249
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->encryption:I

    return-void
.end method

.method public setNextVolumeMissing(Z)V
    .locals 0

    .line 257
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->nextVolumeMissing:Z

    return-void
.end method

.method public setPackFileCRC(J)V
    .locals 0

    .line 273
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packFileCRC:J

    return-void
.end method

.method public setPackVolume(Z)V
    .locals 0

    .line 281
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packVolume:Z

    return-void
.end method

.method public setPackedCRC(J)V
    .locals 0

    .line 265
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packedCRC:J

    return-void
.end method

.method public setPackedSizeToRead(J)V
    .locals 0

    .line 193
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    return-void
.end method

.method public setProcessedArcSize(J)V
    .locals 0

    .line 289
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->processedArcSize:J

    return-void
.end method

.method public setSkipUnpCRC(Z)V
    .locals 0

    .line 201
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->skipUnpCRC:Z

    return-void
.end method

.method public setSubHeader(Lir/mahdi/mzip/rar/rarfile/FileHeader;)V
    .locals 0

    .line 337
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

    return-void
.end method

.method public setTestMode(Z)V
    .locals 0

    .line 197
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->testMode:Z

    return-void
.end method

.method public setTotalArcSize(J)V
    .locals 0

    .line 297
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->totalArcSize:J

    return-void
.end method

.method public setTotalPackRead(J)V
    .locals 0

    .line 305
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->totalPackRead:J

    return-void
.end method

.method public setUnpArcSize(J)V
    .locals 0

    .line 313
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpArcSize:J

    return-void
.end method

.method public setUnpFileCRC(J)V
    .locals 0

    .line 321
    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    return-void
.end method

.method public setUnpVolume(Z)V
    .locals 0

    .line 329
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpVolume:Z

    return-void
.end method

.method public unpRead([BII)I
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lir/mahdi/mzip/rar/exception/RarException;
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v2, -0x1

    if-lez p3, :cond_8

    int-to-long v3, p3

    .line 117
    iget-wide v5, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    cmp-long v1, v3, v5

    if-lez v1, :cond_0

    long-to-int v1, v5

    goto :goto_1

    :cond_0
    move v1, p3

    .line 119
    :goto_1
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->inputStream:Ljava/io/InputStream;

    invoke-virtual {v3, p1, p2, v1}, Ljava/io/InputStream;->read([BII)I

    move-result v1

    if-ltz v1, :cond_7

    .line 123
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSplitAfter()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 124
    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packedCRC:J

    long-to-int v4, v3

    invoke-static {v4, p1, p2, v1}, Lir/mahdi/mzip/rar/crc/RarCRC;->checkCrc(I[BII)I

    move-result v3

    int-to-long v3, v3

    iput-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->packedCRC:J

    .line 128
    :cond_1
    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpRead:J

    int-to-long v5, v1

    add-long/2addr v3, v5

    iput-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpRead:J

    add-int/2addr v0, v1

    add-int/2addr p2, v1

    sub-int/2addr p3, v1

    .line 132
    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    sub-long/2addr v3, v5

    iput-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    .line 133
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v3, v1}, Lir/mahdi/mzip/rar/Archive;->bytesReadRead(I)V

    .line 134
    iget-wide v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpPackedSize:J

    const-wide/16 v5, 0x0

    cmp-long v7, v3, v5

    if-nez v7, :cond_8

    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->subHead:Lir/mahdi/mzip/rar/rarfile/FileHeader;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSplitAfter()Z

    move-result v3

    if-eqz v3, :cond_8

    .line 135
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/Archive;->getVolumeManager()Lir/mahdi/mzip/rar/VolumeManager;

    move-result-object v3

    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    .line 136
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/Archive;->getVolume()Lir/mahdi/mzip/rar/Volume;

    move-result-object v5

    .line 135
    invoke-interface {v3, v4, v5}, Lir/mahdi/mzip/rar/VolumeManager;->nextArchive(Lir/mahdi/mzip/rar/Archive;Lir/mahdi/mzip/rar/Volume;)Lir/mahdi/mzip/rar/Volume;

    move-result-object v3

    if-nez v3, :cond_2

    const/4 p1, 0x1

    .line 138
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->nextVolumeMissing:Z

    return v2

    .line 142
    :cond_2
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->getSubHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object v4

    .line 143
    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpVersion()B

    move-result v5

    const/16 v6, 0x14

    if-lt v5, v6, :cond_4

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileCRC()I

    move-result v5

    if-eq v5, v2, :cond_4

    .line 144
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->getPackedCRC()J

    move-result-wide v5

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileCRC()I

    move-result v4

    xor-int/2addr v4, v2

    int-to-long v7, v4

    cmp-long v4, v5, v7

    if-nez v4, :cond_3

    goto :goto_2

    .line 145
    :cond_3
    new-instance p1, Lir/mahdi/mzip/rar/exception/RarException;

    sget-object p2, Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;->crcError:Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;

    invoke-direct {p1, p2}, Lir/mahdi/mzip/rar/exception/RarException;-><init>(Lir/mahdi/mzip/rar/exception/RarException$RarExceptionType;)V

    throw p1

    .line 147
    :cond_4
    :goto_2
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v4}, Lir/mahdi/mzip/rar/Archive;->getUnrarCallback()Lir/mahdi/mzip/rar/UnrarCallback;

    move-result-object v4

    if-eqz v4, :cond_5

    .line 149
    invoke-interface {v4, v3}, Lir/mahdi/mzip/rar/UnrarCallback;->isNextVolumeReady(Lir/mahdi/mzip/rar/Volume;)Z

    move-result v4

    if-nez v4, :cond_5

    return v2

    .line 152
    :cond_5
    iget-object v4, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v4, v3}, Lir/mahdi/mzip/rar/Archive;->setVolume(Lir/mahdi/mzip/rar/Volume;)V

    .line 153
    iget-object v3, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v3}, Lir/mahdi/mzip/rar/Archive;->nextFileHeader()Lir/mahdi/mzip/rar/rarfile/FileHeader;

    move-result-object v3

    if-nez v3, :cond_6

    return v2

    .line 157
    :cond_6
    invoke-virtual {p0, v3}, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->init(Lir/mahdi/mzip/rar/rarfile/FileHeader;)V

    goto/16 :goto_0

    .line 121
    :cond_7
    new-instance p1, Ljava/io/EOFException;

    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    throw p1

    :cond_8
    if-eq v1, v2, :cond_9

    goto :goto_3

    :cond_9
    move v0, v1

    :goto_3
    return v0
.end method

.method public unpWrite([BII)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 171
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->testMode:Z

    if-nez v0, :cond_0

    .line 173
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->outputStream:Ljava/io/OutputStream;

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/OutputStream;->write([BII)V

    .line 176
    :cond_0
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpWrite:J

    int-to-long v2, p3

    add-long/2addr v0, v2

    iput-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->curUnpWrite:J

    .line 178
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->skipUnpCRC:Z

    if-nez v0, :cond_2

    .line 179
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->archive:Lir/mahdi/mzip/rar/Archive;

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/Archive;->isOldFormat()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 180
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    long-to-int p2, v0

    int-to-short p2, p2

    .line 181
    invoke-static {p2, p1, p3}, Lir/mahdi/mzip/rar/crc/RarCRC;->checkOldCrc(S[BI)S

    move-result p1

    int-to-long p1, p1

    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    goto :goto_0

    .line 183
    :cond_1
    iget-wide v0, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    long-to-int v1, v0

    invoke-static {v1, p1, p2, p3}, Lir/mahdi/mzip/rar/crc/RarCRC;->checkCrc(I[BII)I

    move-result p1

    int-to-long p1, p1

    iput-wide p1, p0, Lir/mahdi/mzip/rar/unpack/ComprDataIO;->unpFileCRC:J

    :cond_2
    :goto_0
    return-void
.end method
