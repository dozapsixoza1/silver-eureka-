.class public Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;
.super Ljava/lang/Object;
.source "VMPreparedCommand.java"


# instance fields
.field private ByteMode:Z

.field private Op1:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

.field private Op2:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

.field private OpCode:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->Op1:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->Op2:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    return-void
.end method


# virtual methods
.method public getOp1()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;
    .locals 1

    .line 35
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->Op1:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    return-object v0
.end method

.method public getOp2()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;
    .locals 1

    .line 43
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->Op2:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    return-object v0
.end method

.method public getOpCode()Lir/mahdi/mzip/rar/unpack/vm/VMCommands;
    .locals 1

    .line 51
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->OpCode:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-object v0
.end method

.method public isByteMode()Z
    .locals 1

    .line 27
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->ByteMode:Z

    return v0
.end method

.method public setByteMode(Z)V
    .locals 0

    .line 31
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->ByteMode:Z

    return-void
.end method

.method public setOp1(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;)V
    .locals 0

    .line 39
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->Op1:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    return-void
.end method

.method public setOp2(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;)V
    .locals 0

    .line 47
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->Op2:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedOperand;

    return-void
.end method

.method public setOpCode(Lir/mahdi/mzip/rar/unpack/vm/VMCommands;)V
    .locals 0

    .line 55
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedCommand;->OpCode:Lir/mahdi/mzip/rar/unpack/vm/VMCommands;

    return-void
.end method
