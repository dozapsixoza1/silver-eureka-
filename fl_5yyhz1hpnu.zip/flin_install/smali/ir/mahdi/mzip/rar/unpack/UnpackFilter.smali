.class public Lir/mahdi/mzip/rar/unpack/UnpackFilter;
.super Ljava/lang/Object;
.source "UnpackFilter.java"


# instance fields
.field private BlockLength:I

.field private BlockStart:I

.field private ExecCount:I

.field private NextWindow:Z

.field private ParentFilter:I

.field private Prg:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    invoke-direct {v0}, Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;-><init>()V

    iput-object v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->Prg:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    return-void
.end method


# virtual methods
.method public getBlockLength()I
    .locals 1

    .line 39
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->BlockLength:I

    return v0
.end method

.method public getBlockStart()I
    .locals 1

    .line 47
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->BlockStart:I

    return v0
.end method

.method public getExecCount()I
    .locals 1

    .line 55
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->ExecCount:I

    return v0
.end method

.method public getParentFilter()I
    .locals 1

    .line 71
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->ParentFilter:I

    return v0
.end method

.method public getPrg()Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;
    .locals 1

    .line 79
    iget-object v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->Prg:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    return-object v0
.end method

.method public isNextWindow()Z
    .locals 1

    .line 63
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->NextWindow:Z

    return v0
.end method

.method public setBlockLength(I)V
    .locals 0

    .line 43
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->BlockLength:I

    return-void
.end method

.method public setBlockStart(I)V
    .locals 0

    .line 51
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->BlockStart:I

    return-void
.end method

.method public setExecCount(I)V
    .locals 0

    .line 59
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->ExecCount:I

    return-void
.end method

.method public setNextWindow(Z)V
    .locals 0

    .line 67
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->NextWindow:Z

    return-void
.end method

.method public setParentFilter(I)V
    .locals 0

    .line 75
    iput p1, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->ParentFilter:I

    return-void
.end method

.method public setPrg(Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;)V
    .locals 0

    .line 83
    iput-object p1, p0, Lir/mahdi/mzip/rar/unpack/UnpackFilter;->Prg:Lir/mahdi/mzip/rar/unpack/vm/VMPreparedProgram;

    return-void
.end method
