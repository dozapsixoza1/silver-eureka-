.class public final enum Lir/mahdi/mzip/rar/unpack/vm/VMFlags;
.super Ljava/lang/Enum;
.source "VMFlags.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/unpack/vm/VMFlags;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

.field public static final enum VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

.field public static final enum VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

.field public static final enum VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;


# instance fields
.field private flag:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 21
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v3, "VM_FC"

    invoke-direct {v0, v3, v1, v2}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    const/4 v3, 0x2

    const-string v4, "VM_FZ"

    invoke-direct {v0, v4, v2, v3}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    const-string v4, "VM_FS"

    const/high16 v5, -0x80000000

    invoke-direct {v0, v4, v3, v5}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    const/4 v0, 0x3

    .line 20
    new-array v0, v0, [Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    sget-object v4, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    aput-object v4, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    aput-object v1, v0, v3

    sput-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 27
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 28
    iput p3, p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->flag:I

    return-void
.end method

.method public static findFlag(I)Lir/mahdi/mzip/rar/unpack/vm/VMFlags;
    .locals 1

    .line 32
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 33
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FC:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    return-object p0

    .line 35
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->equals(I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 36
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FS:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    return-object p0

    .line 38
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->equals(I)Z

    move-result p0

    if-eqz p0, :cond_2

    .line 39
    sget-object p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->VM_FZ:Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    return-object p0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/unpack/vm/VMFlags;
    .locals 1

    .line 20
    const-class v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/unpack/vm/VMFlags;
    .locals 1

    .line 20
    sget-object v0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->$VALUES:[Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/unpack/vm/VMFlags;

    return-object v0
.end method


# virtual methods
.method public equals(I)Z
    .locals 1

    .line 45
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->flag:I

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getFlag()I
    .locals 1

    .line 49
    iget v0, p0, Lir/mahdi/mzip/rar/unpack/vm/VMFlags;->flag:I

    return v0
.end method
