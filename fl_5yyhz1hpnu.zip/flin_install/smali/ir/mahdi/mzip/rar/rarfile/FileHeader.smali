.class public Lir/mahdi/mzip/rar/rarfile/FileHeader;
.super Lir/mahdi/mzip/rar/rarfile/BlockHeader;
.source "FileHeader.java"


# static fields
.field private static final NEWLHD_SIZE:B = 0x20t

.field private static final SALT_SIZE:B = 0x8t


# instance fields
.field private aTime:Ljava/util/Date;

.field private arcTime:Ljava/util/Date;

.field private cTime:Ljava/util/Date;

.field private fileAttr:I

.field private final fileCRC:I

.field private fileName:Ljava/lang/String;

.field private final fileNameBytes:[B

.field private fileNameW:Ljava/lang/String;

.field private final fileTime:I

.field private fullPackSize:J

.field private fullUnpackSize:J

.field private highPackSize:I

.field private highUnpackSize:I

.field private final hostOS:Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field private mTime:Ljava/util/Date;

.field private nameSize:S

.field private recoverySectors:I

.field private final salt:[B

.field private subData:[B

.field private subFlags:I

.field private unpMethod:B

.field private unpSize:J

.field private unpVersion:B


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;[B)V
    .locals 8

    .line 66
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;)V

    const/16 p1, 0x8

    .line 37
    new-array v0, p1, [B

    iput-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->salt:[B

    const/4 v0, -0x1

    .line 63
    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->recoverySectors:I

    const/4 v0, 0x0

    .line 69
    invoke-static {p2, v0}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndianAsLong([BI)J

    move-result-wide v1

    iput-wide v1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpSize:J

    const/4 v1, 0x4

    .line 71
    aget-byte v1, p2, v1

    invoke-static {v1}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->findHostSystem(B)Lir/mahdi/mzip/rar/rarfile/HostSystem;

    move-result-object v1

    iput-object v1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hostOS:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v1, 0x5

    .line 74
    invoke-static {p2, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v1

    iput v1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileCRC:I

    const/16 v1, 0x9

    .line 77
    invoke-static {p2, v1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v2

    iput v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileTime:I

    .line 80
    iget-byte v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpVersion:B

    const/16 v3, 0xd

    aget-byte v3, p2, v3

    and-int/lit16 v3, v3, 0xff

    or-int/2addr v2, v3

    int-to-byte v2, v2

    iput-byte v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpVersion:B

    .line 82
    iget-byte v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpMethod:B

    const/16 v3, 0xe

    aget-byte v3, p2, v3

    and-int/lit16 v3, v3, 0xff

    or-int/2addr v2, v3

    int-to-byte v2, v2

    iput-byte v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpMethod:B

    const/16 v2, 0xf

    .line 84
    invoke-static {p2, v2}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v2

    iput-short v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    const/16 v2, 0x11

    .line 87
    invoke-static {p2, v2}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v2

    iput v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileAttr:I

    .line 89
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isLargeBlock()Z

    move-result v2

    const/16 v3, 0x15

    if-eqz v2, :cond_0

    .line 90
    invoke-static {p2, v3}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v2

    iput v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highPackSize:I

    const/16 v2, 0x19

    .line 93
    invoke-static {p2, v2}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result v2

    iput v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highUnpackSize:I

    const/16 v3, 0x1d

    goto :goto_0

    .line 96
    :cond_0
    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highPackSize:I

    .line 97
    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highUnpackSize:I

    .line 98
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpSize:J

    const-wide/16 v6, -0x1

    cmp-long v2, v4, v6

    if-nez v2, :cond_1

    .line 100
    iput-wide v6, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpSize:J

    const v2, 0x7fffffff

    .line 101
    iput v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highUnpackSize:I

    .line 105
    :cond_1
    :goto_0
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    iget v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highPackSize:I

    int-to-long v6, v2

    or-long/2addr v4, v6

    iput-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    .line 106
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    const/16 v2, 0x20

    shl-long/2addr v4, v2

    iput-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    .line 107
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getPackSize()I

    move-result v6

    int-to-long v6, v6

    or-long/2addr v4, v6

    iput-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    .line 109
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    iget v6, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highUnpackSize:I

    int-to-long v6, v6

    or-long/2addr v4, v6

    iput-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    .line 110
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    shl-long/2addr v4, v2

    iput-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    .line 111
    iget-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    iget-wide v6, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpSize:J

    add-long/2addr v4, v6

    iput-wide v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    .line 113
    iget-short v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    const/16 v5, 0x1000

    if-le v4, v5, :cond_2

    const/16 v4, 0x1000

    :cond_2
    iput-short v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    .line 115
    iget-short v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    new-array v4, v4, [B

    iput-object v4, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    move v4, v3

    const/4 v3, 0x0

    .line 116
    :goto_1
    iget-short v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    if-ge v3, v5, :cond_3

    .line 117
    iget-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    aget-byte v6, p2, v4

    aput-byte v6, v5, v3

    add-int/lit8 v4, v4, 0x1

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 121
    :cond_3
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isFileHeader()Z

    move-result v3

    if-eqz v3, :cond_6

    .line 122
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isUnicode()Z

    move-result v3

    const-string v5, ""

    if-eqz v3, :cond_5

    .line 124
    iput-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileName:Ljava/lang/String;

    .line 125
    iput-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameW:Ljava/lang/String;

    const/4 v3, 0x0

    .line 126
    :goto_2
    iget-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    array-length v6, v5

    if-ge v3, v6, :cond_4

    aget-byte v5, v5, v3

    if-eqz v5, :cond_4

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 130
    :cond_4
    new-array v5, v3, [B

    .line 131
    iget-object v6, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    array-length v7, v5

    invoke-static {v6, v0, v5, v0, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 132
    new-instance v6, Ljava/lang/String;

    invoke-direct {v6, v5}, Ljava/lang/String;-><init>([B)V

    iput-object v6, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileName:Ljava/lang/String;

    .line 133
    iget-short v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    if-eq v3, v5, :cond_6

    add-int/lit8 v3, v3, 0x1

    .line 135
    iget-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    invoke-static {v5, v3}, Lir/mahdi/mzip/rar/rarfile/FileNameDecoder;->decode([BI)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameW:Ljava/lang/String;

    goto :goto_3

    .line 138
    :cond_5
    new-instance v3, Ljava/lang/String;

    iget-object v6, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    invoke-direct {v3, v6}, Ljava/lang/String;-><init>([B)V

    iput-object v3, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileName:Ljava/lang/String;

    .line 139
    iput-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameW:Ljava/lang/String;

    .line 143
    :cond_6
    :goto_3
    sget-object v3, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    iget-byte v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->headerType:B

    invoke-virtual {v3, v5}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v3

    if-eqz v3, :cond_9

    .line 144
    iget-short v3, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->headerSize:S

    sub-int/2addr v3, v2

    iget-short v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    sub-int/2addr v3, v2

    .line 145
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hasSalt()Z

    move-result v2

    if-eqz v2, :cond_7

    add-int/lit8 v3, v3, -0x8

    :cond_7
    if-lez v3, :cond_8

    .line 149
    new-array v2, v3, [B

    iput-object v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->subData:[B

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v3, :cond_8

    .line 151
    iget-object v5, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->subData:[B

    aget-byte v6, p2, v4

    aput-byte v6, v5, v2

    add-int/lit8 v4, v4, 0x1

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    .line 156
    :cond_8
    sget-object v2, Lir/mahdi/mzip/rar/rarfile/NewSubHeaderType;->SUBHEAD_TYPE_RR:Lir/mahdi/mzip/rar/rarfile/NewSubHeaderType;

    iget-object v3, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    invoke-virtual {v2, v3}, Lir/mahdi/mzip/rar/rarfile/NewSubHeaderType;->byteEquals([B)Z

    move-result v2

    if-eqz v2, :cond_9

    .line 157
    iget-object v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->subData:[B

    aget-byte v3, v2, p1

    aget-byte v1, v2, v1

    shl-int/2addr v1, p1

    add-int/2addr v3, v1

    const/16 v1, 0xa

    aget-byte v1, v2, v1

    shl-int/lit8 v1, v1, 0x10

    add-int/2addr v3, v1

    const/16 v1, 0xb

    aget-byte v1, v2, v1

    shl-int/lit8 v1, v1, 0x18

    add-int/2addr v3, v1

    iput v3, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->recoverySectors:I

    .line 162
    :cond_9
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hasSalt()Z

    move-result v1

    if-eqz v1, :cond_a

    :goto_5
    if-ge v0, p1, :cond_a

    .line 164
    iget-object v1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->salt:[B

    aget-byte v2, p2, v4

    aput-byte v2, v1, v0

    add-int/lit8 v4, v4, 0x1

    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 168
    :cond_a
    iget p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileTime:I

    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getDateDos(I)Ljava/util/Date;

    move-result-object p1

    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->mTime:Ljava/util/Date;

    return-void
.end method

.method private getDateDos(I)Ljava/util/Date;
    .locals 4

    .line 201
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    ushr-int/lit8 v1, p1, 0x19

    add-int/lit16 v1, v1, 0x7bc

    const/4 v2, 0x1

    .line 202
    invoke-virtual {v0, v2, v1}, Ljava/util/Calendar;->set(II)V

    ushr-int/lit8 v1, p1, 0x15

    and-int/lit8 v1, v1, 0xf

    sub-int/2addr v1, v2

    const/4 v2, 0x2

    .line 203
    invoke-virtual {v0, v2, v1}, Ljava/util/Calendar;->set(II)V

    ushr-int/lit8 v1, p1, 0x10

    and-int/lit8 v1, v1, 0x1f

    const/4 v3, 0x5

    .line 204
    invoke-virtual {v0, v3, v1}, Ljava/util/Calendar;->set(II)V

    ushr-int/lit8 v1, p1, 0xb

    and-int/lit8 v1, v1, 0x1f

    const/16 v3, 0xb

    .line 205
    invoke-virtual {v0, v3, v1}, Ljava/util/Calendar;->set(II)V

    ushr-int/lit8 v1, p1, 0x5

    and-int/lit8 v1, v1, 0x3f

    const/16 v3, 0xc

    .line 206
    invoke-virtual {v0, v3, v1}, Ljava/util/Calendar;->set(II)V

    and-int/lit8 p1, p1, 0x1f

    mul-int/lit8 p1, p1, 0x2

    const/16 v1, 0xd

    .line 207
    invoke-virtual {v0, v1, p1}, Ljava/util/Calendar;->set(II)V

    .line 208
    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p1

    return-object p1
.end method


# virtual methods
.method public getATime()Ljava/util/Date;
    .locals 1

    .line 220
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->aTime:Ljava/util/Date;

    return-object v0
.end method

.method public getArcTime()Ljava/util/Date;
    .locals 1

    .line 212
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->arcTime:Ljava/util/Date;

    return-object v0
.end method

.method public getCTime()Ljava/util/Date;
    .locals 1

    .line 228
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->cTime:Ljava/util/Date;

    return-object v0
.end method

.method public getFileAttr()I
    .locals 1

    .line 236
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileAttr:I

    return v0
.end method

.method public getFileCRC()I
    .locals 1

    .line 244
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileCRC:I

    return v0
.end method

.method public getFileNameByteArray()[B
    .locals 1

    .line 248
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameBytes:[B

    return-object v0
.end method

.method public getFileNameString()Ljava/lang/String;
    .locals 1

    .line 252
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileName:Ljava/lang/String;

    return-object v0
.end method

.method public getFileNameW()Ljava/lang/String;
    .locals 1

    .line 260
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameW:Ljava/lang/String;

    return-object v0
.end method

.method public getFullPackSize()J
    .locals 2

    .line 320
    iget-wide v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullPackSize:J

    return-wide v0
.end method

.method public getFullUnpackSize()J
    .locals 2

    .line 324
    iget-wide v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fullUnpackSize:J

    return-wide v0
.end method

.method public getHighPackSize()I
    .locals 1

    .line 268
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highPackSize:I

    return v0
.end method

.method public getHighUnpackSize()I
    .locals 1

    .line 272
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->highUnpackSize:I

    return v0
.end method

.method public getHostOS()Lir/mahdi/mzip/rar/rarfile/HostSystem;
    .locals 1

    .line 276
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hostOS:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object v0
.end method

.method public getMTime()Ljava/util/Date;
    .locals 1

    .line 280
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->mTime:Ljava/util/Date;

    return-object v0
.end method

.method public getNameSize()S
    .locals 1

    .line 288
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->nameSize:S

    return v0
.end method

.method public getRecoverySectors()I
    .locals 1

    .line 292
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->recoverySectors:I

    return v0
.end method

.method public getSalt()[B
    .locals 1

    .line 296
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->salt:[B

    return-object v0
.end method

.method public getSubData()[B
    .locals 1

    .line 300
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->subData:[B

    return-object v0
.end method

.method public getSubFlags()I
    .locals 1

    .line 304
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->subFlags:I

    return v0
.end method

.method public getUnpMethod()B
    .locals 1

    .line 308
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpMethod:B

    return v0
.end method

.method public getUnpSize()J
    .locals 2

    .line 312
    iget-wide v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpSize:J

    return-wide v0
.end method

.method public getUnpVersion()B
    .locals 1

    .line 316
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->unpVersion:B

    return v0
.end method

.method public hasSalt()Z
    .locals 1

    .line 357
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    and-int/lit16 v0, v0, 0x400

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isDirectory()Z
    .locals 2

    .line 365
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    const/16 v1, 0xe0

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isEncrypted()Z
    .locals 1

    .line 345
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isFileHeader()Z
    .locals 2

    .line 353
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    iget-byte v1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->headerType:B

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    return v0
.end method

.method public isLargeBlock()Z
    .locals 1

    .line 361
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isSolid()Z
    .locals 1

    .line 341
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isSplitAfter()Z
    .locals 1

    .line 333
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isSplitBefore()Z
    .locals 2

    .line 337
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public isUnicode()Z
    .locals 1

    .line 349
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->flags:S

    and-int/lit16 v0, v0, 0x200

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public print()V
    .locals 4

    .line 175
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->print()V

    .line 176
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 177
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "unpSize: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpSize()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 178
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nHostOS: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hostOS:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v2}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->name()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 179
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nMDate: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->mTime:Ljava/util/Date;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 180
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nFileName: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFileNameString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nunpMethod: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpMethod()B

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nunpVersion: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpVersion()B

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nfullpackedsize: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFullPackSize()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 184
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nfullunpackedsize: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getFullUnpackSize()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 185
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisEncrypted: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isEncrypted()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisfileHeader: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isFileHeader()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 187
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisSolid: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSolid()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisSplitafter: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSplitAfter()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 189
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisSplitBefore:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSplitBefore()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 190
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nunpSize: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getUnpSize()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\ndataSize: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->getDataSize()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisUnicode: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isUnicode()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 193
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nhasVolumeNumber: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hasVolumeNumber()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 194
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nhasArchiveDataCRC: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hasArchiveDataCRC()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 195
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nhasSalt: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hasSalt()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 196
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nhasEncryptVersions: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->hasEncryptVersion()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nisSubBlock: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/FileHeader;->isSubBlock()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public setATime(Ljava/util/Date;)V
    .locals 0

    .line 224
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->aTime:Ljava/util/Date;

    return-void
.end method

.method public setArcTime(Ljava/util/Date;)V
    .locals 0

    .line 216
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->arcTime:Ljava/util/Date;

    return-void
.end method

.method public setCTime(Ljava/util/Date;)V
    .locals 0

    .line 232
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->cTime:Ljava/util/Date;

    return-void
.end method

.method public setFileAttr(I)V
    .locals 0

    .line 240
    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileAttr:I

    return-void
.end method

.method public setFileName(Ljava/lang/String;)V
    .locals 0

    .line 256
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileName:Ljava/lang/String;

    return-void
.end method

.method public setFileNameW(Ljava/lang/String;)V
    .locals 0

    .line 264
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->fileNameW:Ljava/lang/String;

    return-void
.end method

.method public setMTime(Ljava/util/Date;)V
    .locals 0

    .line 284
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/FileHeader;->mTime:Ljava/util/Date;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .line 329
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
