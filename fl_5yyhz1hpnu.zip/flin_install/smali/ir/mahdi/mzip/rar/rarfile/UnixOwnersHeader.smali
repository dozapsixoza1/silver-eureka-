.class public Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;
.super Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;
.source "UnixOwnersHeader.java"


# instance fields
.field private group:Ljava/lang/String;

.field private groupNameSize:I

.field private owner:Ljava/lang/String;

.field private ownerNameSize:I


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;[B)V
    .locals 4

    .line 15
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;)V

    const/4 p1, 0x0

    .line 17
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    const v1, 0xffff

    and-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->ownerNameSize:I

    const/4 v0, 0x2

    .line 19
    invoke-static {p2, v0}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    and-int/2addr v0, v1

    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->groupNameSize:I

    .line 21
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->ownerNameSize:I

    const/4 v1, 0x4

    add-int v2, v1, v0

    array-length v3, p2

    if-ge v2, v3, :cond_0

    .line 22
    new-array v2, v0, [B

    .line 23
    invoke-static {p2, v1, v2, p1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 24
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v2}, Ljava/lang/String;-><init>([B)V

    iput-object v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->owner:Ljava/lang/String;

    .line 26
    :cond_0
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->ownerNameSize:I

    add-int/2addr v1, v0

    .line 27
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->groupNameSize:I

    add-int v2, v1, v0

    array-length v3, p2

    if-ge v2, v3, :cond_1

    .line 28
    new-array v2, v0, [B

    .line 29
    invoke-static {p2, v1, v2, p1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 30
    new-instance p1, Ljava/lang/String;

    invoke-direct {p1, v2}, Ljava/lang/String;-><init>([B)V

    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->group:Ljava/lang/String;

    :cond_1
    return-void
.end method


# virtual methods
.method public getGroup()Ljava/lang/String;
    .locals 1

    .line 35
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->group:Ljava/lang/String;

    return-object v0
.end method

.method public getGroupNameSize()I
    .locals 1

    .line 43
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->groupNameSize:I

    return v0
.end method

.method public getOwner()Ljava/lang/String;
    .locals 1

    .line 51
    iget-object v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->owner:Ljava/lang/String;

    return-object v0
.end method

.method public getOwnerNameSize()I
    .locals 1

    .line 59
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->ownerNameSize:I

    return v0
.end method

.method public print()V
    .locals 0

    .line 70
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->print()V

    return-void
.end method

.method public setGroup(Ljava/lang/String;)V
    .locals 0

    .line 39
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->group:Ljava/lang/String;

    return-void
.end method

.method public setGroupNameSize(I)V
    .locals 0

    .line 47
    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->groupNameSize:I

    return-void
.end method

.method public setOwner(Ljava/lang/String;)V
    .locals 0

    .line 55
    iput-object p1, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->owner:Ljava/lang/String;

    return-void
.end method

.method public setOwnerNameSize(I)V
    .locals 0

    .line 63
    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/UnixOwnersHeader;->ownerNameSize:I

    return-void
.end method
