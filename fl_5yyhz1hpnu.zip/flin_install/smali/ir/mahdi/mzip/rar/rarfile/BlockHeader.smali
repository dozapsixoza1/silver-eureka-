.class public Lir/mahdi/mzip/rar/rarfile/BlockHeader;
.super Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.source "BlockHeader.java"


# static fields
.field public static final blockHeaderSize:S = 0x4s


# instance fields
.field private dataSize:I

.field private packSize:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>()V

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V
    .locals 0

    .line 44
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    const/4 p1, 0x0

    .line 46
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->packSize:I

    .line 47
    iget p1, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->packSize:I

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->dataSize:I

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;)V
    .locals 2

    .line 37
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    .line 38
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getDataSize()I

    move-result v0

    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->packSize:I

    .line 39
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->packSize:I

    iput v0, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->dataSize:I

    .line 40
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getPositionInFile()J

    move-result-wide v0

    iput-wide v0, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->positionInFile:J

    return-void
.end method


# virtual methods
.method public getDataSize()I
    .locals 1

    .line 51
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->dataSize:I

    return v0
.end method

.method public getPackSize()I
    .locals 1

    .line 55
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->packSize:I

    return v0
.end method

.method public print()V
    .locals 2

    .line 59
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->print()V

    .line 60
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "DataSize: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getDataSize()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " packSize: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->getPackSize()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    return-void
.end method
