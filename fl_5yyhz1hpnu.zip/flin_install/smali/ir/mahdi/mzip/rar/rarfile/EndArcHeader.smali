.class public Lir/mahdi/mzip/rar/rarfile/EndArcHeader;
.super Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.source "EndArcHeader.java"


# static fields
.field private static final EARC_DATACRC:S = 0x2s

.field private static final EARC_NEXT_VOLUME:S = 0x1s

.field private static final EARC_REVSPACE:S = 0x4s

.field private static final EARC_VOLNUMBER:S = 0x8s

.field public static final endArcArchiveDataCrcSize:S = 0x4s

.field private static final endArcHeaderSize:S = 0x6s

.field public static final endArcVolumeNumberSize:S = 0x2s


# instance fields
.field private archiveDataCRC:I

.field private volumeNumber:S


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V
    .locals 1

    .line 37
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    .line 40
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;->hasArchiveDataCRC()Z

    move-result p1

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    .line 41
    invoke-static {p2, v0}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;->archiveDataCRC:I

    const/4 v0, 0x4

    .line 44
    :cond_0
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;->hasVolumeNumber()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 45
    invoke-static {p2, v0}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;->volumeNumber:S

    :cond_1
    return-void
.end method


# virtual methods
.method public getArchiveDataCRC()I
    .locals 1

    .line 50
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;->archiveDataCRC:I

    return v0
.end method

.method public getVolumeNumber()S
    .locals 1

    .line 54
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/EndArcHeader;->volumeNumber:S

    return v0
.end method
