.class public Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.super Ljava/lang/Object;
.source "BaseBlock.java"


# static fields
.field public static final BaseBlockSize:S = 0x7s

.field public static final EARC_DATACRC:S = 0x2s

.field public static final EARC_NEXT_VOLUME:S = 0x1s

.field public static final EARC_REVSPACE:S = 0x4s

.field public static final EARC_VOLNUMBER:S = 0x8s

.field public static final LHD_COMMENT:S = 0x8s

.field public static final LHD_DIRECTORY:S = 0xe0s

.field public static final LHD_EXTFLAGS:S = 0x2000s

.field public static final LHD_EXTTIME:S = 0x1000s

.field public static final LHD_LARGE:S = 0x100s

.field public static final LHD_PASSWORD:S = 0x4s

.field public static final LHD_SALT:S = 0x400s

.field public static final LHD_SOLID:S = 0x10s

.field public static final LHD_SPLIT_AFTER:S = 0x2s

.field public static final LHD_SPLIT_BEFORE:S = 0x1s

.field public static final LHD_UNICODE:S = 0x200s

.field public static final LHD_VERSION:S = 0x800s

.field public static final LHD_WINDOW1024:S = 0x80s

.field public static final LHD_WINDOW128:S = 0x20s

.field public static final LHD_WINDOW2048:S = 0xa0s

.field public static final LHD_WINDOW256:S = 0x40s

.field public static final LHD_WINDOW4096:S = 0xc0s

.field public static final LHD_WINDOW512:S = 0x60s

.field public static final LHD_WINDOW64:S = 0x0s

.field public static final LHD_WINDOWMASK:S = 0xe0s

.field public static final LONG_BLOCK:S = -0x8000s

.field public static final MHD_AV:S = 0x20s

.field public static final MHD_COMMENT:S = 0x2s

.field public static final MHD_ENCRYPTVER:S = 0x200s

.field public static final MHD_FIRSTVOLUME:S = 0x100s

.field public static final MHD_LOCK:S = 0x4s

.field public static final MHD_NEWNUMBERING:S = 0x10s

.field public static final MHD_PACK_COMMENT:S = 0x10s

.field public static final MHD_PASSWORD:S = 0x80s

.field public static final MHD_PROTECT:S = 0x40s

.field public static final MHD_SOLID:S = 0x8s

.field public static final MHD_VOLUME:S = 0x1s

.field public static final SKIP_IF_UNKNOWN:S = 0x4000s


# instance fields
.field protected flags:S

.field protected headCRC:S

.field protected headerSize:S

.field protected headerType:B

.field protected positionInFile:J


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 83
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 78
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headCRC:S

    .line 79
    iput-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    .line 80
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    .line 81
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerSize:S

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V
    .locals 2

    .line 87
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 78
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headCRC:S

    .line 79
    iput-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    .line 80
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    .line 81
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerSize:S

    .line 88
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getFlags()S

    move-result v0

    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    .line 89
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeadCRC()S

    move-result v0

    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headCRC:S

    .line 90
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->getHeaderByte()B

    move-result v0

    iput-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    .line 91
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderSize()S

    move-result v0

    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerSize:S

    .line 92
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getPositionInFile()J

    move-result-wide v0

    iput-wide v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->positionInFile:J

    return-void
.end method

.method public constructor <init>([B)V
    .locals 2

    .line 95
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 78
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headCRC:S

    .line 79
    iput-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    .line 80
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    .line 81
    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerSize:S

    .line 98
    invoke-static {p1, v0}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headCRC:S

    .line 100
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    const/4 v1, 0x2

    aget-byte v1, p1, v1

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    int-to-byte v0, v0

    iput-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    const/4 v0, 0x3

    .line 102
    invoke-static {p1, v0}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result v0

    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    const/4 v0, 0x5

    .line 104
    invoke-static {p1, v0}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerSize:S

    return-void
.end method


# virtual methods
.method public getFlags()S
    .locals 1

    .line 137
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    return v0
.end method

.method public getHeadCRC()S
    .locals 1

    .line 141
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headCRC:S

    return v0
.end method

.method public getHeaderSize()S
    .locals 1

    .line 145
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerSize:S

    return v0
.end method

.method public getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;
    .locals 1

    .line 149
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    invoke-static {v0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->findType(B)Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v0

    return-object v0
.end method

.method public getPositionInFile()J
    .locals 2

    .line 129
    iget-wide v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->positionInFile:J

    return-wide v0
.end method

.method public hasArchiveDataCRC()Z
    .locals 1

    .line 109
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public hasEncryptVersion()Z
    .locals 1

    .line 117
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    and-int/lit16 v0, v0, 0x200

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public hasVolumeNumber()Z
    .locals 1

    .line 113
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isSubBlock()Z
    .locals 3

    .line 121
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    iget-byte v1, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    invoke-virtual {v0, v1}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 124
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    iget-byte v2, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->headerType:B

    invoke-virtual {v0, v2}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->flags:S

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public print()V
    .locals 4

    .line 153
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 154
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HeaderType: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nHeadCRC: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeadCRC()S

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nFlags: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getFlags()S

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 157
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nHeaderSize: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getHeaderSize()S

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\nPosition in file: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->getPositionInFile()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public setPositionInFile(J)V
    .locals 0

    .line 133
    iput-wide p1, p0, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->positionInFile:J

    return-void
.end method
