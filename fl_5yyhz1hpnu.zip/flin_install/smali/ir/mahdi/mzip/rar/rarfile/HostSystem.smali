.class public final enum Lir/mahdi/mzip/rar/rarfile/HostSystem;
.super Ljava/lang/Enum;
.source "HostSystem.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/rarfile/HostSystem;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field public static final enum beos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field public static final enum macos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field public static final enum msdos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field public static final enum os2:Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field public static final enum unix:Lir/mahdi/mzip/rar/rarfile/HostSystem;

.field public static final enum win32:Lir/mahdi/mzip/rar/rarfile/HostSystem;


# instance fields
.field private hostByte:B


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .line 22
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v1, 0x0

    const-string v2, "msdos"

    invoke-direct {v0, v2, v1, v1}, Lir/mahdi/mzip/rar/rarfile/HostSystem;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->msdos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v2, 0x1

    const-string v3, "os2"

    invoke-direct {v0, v3, v2, v2}, Lir/mahdi/mzip/rar/rarfile/HostSystem;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->os2:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v3, 0x2

    const-string v4, "win32"

    invoke-direct {v0, v4, v3, v3}, Lir/mahdi/mzip/rar/rarfile/HostSystem;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->win32:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    .line 25
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v4, 0x3

    const-string v5, "unix"

    invoke-direct {v0, v5, v4, v4}, Lir/mahdi/mzip/rar/rarfile/HostSystem;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->unix:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    .line 26
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v5, 0x4

    const-string v6, "macos"

    invoke-direct {v0, v6, v5, v5}, Lir/mahdi/mzip/rar/rarfile/HostSystem;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->macos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    .line 27
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v6, 0x5

    const-string v7, "beos"

    invoke-direct {v0, v7, v6, v6}, Lir/mahdi/mzip/rar/rarfile/HostSystem;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->beos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    const/4 v0, 0x6

    .line 21
    new-array v0, v0, [Lir/mahdi/mzip/rar/rarfile/HostSystem;

    sget-object v7, Lir/mahdi/mzip/rar/rarfile/HostSystem;->msdos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    aput-object v7, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/HostSystem;->os2:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/HostSystem;->win32:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/HostSystem;->unix:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/HostSystem;->macos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/HostSystem;->beos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    aput-object v1, v0, v6

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->$VALUES:[Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IB)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(B)V"
        }
    .end annotation

    .line 31
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 32
    iput-byte p3, p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->hostByte:B

    return-void
.end method

.method public static findHostSystem(B)Lir/mahdi/mzip/rar/rarfile/HostSystem;
    .locals 1

    .line 36
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->msdos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 37
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->msdos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0

    .line 39
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->os2:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 40
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->os2:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0

    .line 42
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->win32:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 43
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->win32:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0

    .line 45
    :cond_2
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->unix:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 46
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->unix:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0

    .line 48
    :cond_3
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->macos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 49
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->macos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0

    .line 51
    :cond_4
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->beos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/HostSystem;->equals(B)Z

    move-result p0

    if-eqz p0, :cond_5

    .line 52
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->beos:Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0

    :cond_5
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/rarfile/HostSystem;
    .locals 1

    .line 21
    const-class v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/rarfile/HostSystem;
    .locals 1

    .line 21
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->$VALUES:[Lir/mahdi/mzip/rar/rarfile/HostSystem;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/rarfile/HostSystem;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/rarfile/HostSystem;

    return-object v0
.end method


# virtual methods
.method public equals(B)Z
    .locals 1

    .line 58
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->hostByte:B

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getHostByte()B
    .locals 1

    .line 62
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/HostSystem;->hostByte:B

    return v0
.end method
