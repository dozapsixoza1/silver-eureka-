.class public final enum Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;
.super Ljava/lang/Enum;
.source "UnrarHeadertype.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum AvHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum CommHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum ProtectHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum SignHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

.field public static final enum SubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;


# instance fields
.field private headerByte:B


# direct methods
.method static constructor <clinit>()V
    .locals 13

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v1, 0x0

    const-string v2, "MainHeader"

    const/16 v3, 0x73

    invoke-direct {v0, v2, v1, v3}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 26
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v2, 0x1

    const-string v3, "MarkHeader"

    const/16 v4, 0x72

    invoke-direct {v0, v3, v2, v4}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 28
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v3, 0x2

    const-string v4, "FileHeader"

    const/16 v5, 0x74

    invoke-direct {v0, v4, v3, v5}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 30
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v4, 0x3

    const-string v5, "CommHeader"

    const/16 v6, 0x75

    invoke-direct {v0, v5, v4, v6}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->CommHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 32
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v5, 0x4

    const-string v6, "AvHeader"

    const/16 v7, 0x76

    invoke-direct {v0, v6, v5, v7}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->AvHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 34
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v6, 0x5

    const-string v7, "SubHeader"

    const/16 v8, 0x77

    invoke-direct {v0, v7, v6, v8}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 36
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v7, 0x6

    const-string v8, "ProtectHeader"

    const/16 v9, 0x78

    invoke-direct {v0, v8, v7, v9}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->ProtectHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 38
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/4 v8, 0x7

    const-string v9, "SignHeader"

    const/16 v10, 0x79

    invoke-direct {v0, v9, v8, v10}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SignHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 40
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/16 v9, 0x8

    const-string v10, "NewSubHeader"

    const/16 v11, 0x7a

    invoke-direct {v0, v10, v9, v11}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    .line 42
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/16 v10, 0x9

    const-string v11, "EndArcHeader"

    const/16 v12, 0x7b

    invoke-direct {v0, v11, v10, v12}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;-><init>(Ljava/lang/String;IB)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    const/16 v0, 0xa

    .line 21
    new-array v0, v0, [Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    sget-object v11, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v11, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->CommHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->AvHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v6

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->ProtectHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v7

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SignHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v8

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v9

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    aput-object v1, v0, v10

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->$VALUES:[Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IB)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(B)V"
        }
    .end annotation

    .line 47
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 48
    iput-byte p3, p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->headerByte:B

    return-void
.end method

.method public static findType(B)Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;
    .locals 1

    .line 52
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 53
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 55
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 56
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 58
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 59
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 61
    :cond_2
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 62
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 64
    :cond_3
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 65
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->NewSubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 67
    :cond_4
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 68
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SubHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 70
    :cond_5
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SignHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 71
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->SignHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 73
    :cond_6
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->ProtectHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_7

    .line 74
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->ProtectHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 76
    :cond_7
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 77
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 79
    :cond_8
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_9

    .line 80
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MainHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 82
    :cond_9
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 83
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->FileHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 85
    :cond_a
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 86
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->EndArcHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 88
    :cond_b
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->CommHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 89
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->CommHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    .line 91
    :cond_c
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->AvHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->equals(B)Z

    move-result p0

    if-eqz p0, :cond_d

    .line 92
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->AvHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0

    :cond_d
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;
    .locals 1

    .line 21
    const-class v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;
    .locals 1

    .line 21
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->$VALUES:[Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    return-object v0
.end method


# virtual methods
.method public equals(B)Z
    .locals 1

    .line 98
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->headerByte:B

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getHeaderByte()B
    .locals 1

    .line 103
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->headerByte:B

    return v0
.end method
