.class public Lir/mahdi/mzip/rar/rarfile/EAHeader;
.super Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;
.source "EAHeader.java"


# static fields
.field public static final EAHeaderSize:S = 0xas


# instance fields
.field private EACRC:I

.field private method:B

.field private unpSize:I

.field private unpVer:B


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;[B)V
    .locals 1

    .line 36
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;)V

    const/4 p1, 0x0

    .line 38
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->unpSize:I

    .line 40
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->unpVer:B

    const/4 v0, 0x4

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->unpVer:B

    .line 42
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->method:B

    const/4 v0, 0x5

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->method:B

    const/4 p1, 0x6

    .line 44
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->EACRC:I

    return-void
.end method


# virtual methods
.method public getEACRC()I
    .locals 1

    .line 48
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->EACRC:I

    return v0
.end method

.method public getMethod()B
    .locals 1

    .line 52
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->method:B

    return v0
.end method

.method public getUnpSize()I
    .locals 1

    .line 56
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->unpSize:I

    return v0
.end method

.method public getUnpVer()B
    .locals 1

    .line 60
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/EAHeader;->unpVer:B

    return v0
.end method

.method public print()V
    .locals 0

    .line 64
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->print()V

    return-void
.end method
