.class public Lir/mahdi/mzip/rar/rarfile/CommentHeader;
.super Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.source "CommentHeader.java"


# static fields
.field public static final commentHeaderSize:S = 0x6s


# instance fields
.field private commCRC:S

.field private unpMethod:B

.field private unpSize:S

.field private unpVersion:B


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V
    .locals 1

    .line 35
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    const/4 p1, 0x0

    .line 38
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpSize:S

    .line 40
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpVersion:B

    const/4 v0, 0x2

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpVersion:B

    .line 43
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpMethod:B

    const/4 v0, 0x3

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpMethod:B

    const/4 p1, 0x4

    .line 45
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->commCRC:S

    return-void
.end method


# virtual methods
.method public getCommCRC()S
    .locals 1

    .line 50
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->commCRC:S

    return v0
.end method

.method public getUnpMethod()B
    .locals 1

    .line 54
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpMethod:B

    return v0
.end method

.method public getUnpSize()S
    .locals 1

    .line 58
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpSize:S

    return v0
.end method

.method public getUnpVersion()B
    .locals 1

    .line 62
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/CommentHeader;->unpVersion:B

    return v0
.end method
