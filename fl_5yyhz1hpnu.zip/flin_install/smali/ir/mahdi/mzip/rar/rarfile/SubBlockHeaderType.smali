.class public final enum Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;
.super Ljava/lang/Enum;
.source "SubBlockHeaderType.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

.field public static final enum BEEA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

.field public static final enum EA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

.field public static final enum MAC_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

.field public static final enum NTACL_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

.field public static final enum STREAM_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

.field public static final enum UO_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;


# instance fields
.field private subblocktype:S


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .line 23
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v1, 0x0

    const-string v2, "EA_HEAD"

    const/16 v3, 0x100

    invoke-direct {v0, v2, v1, v3}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;-><init>(Ljava/lang/String;IS)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->EA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    .line 24
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v2, 0x1

    const-string v3, "UO_HEAD"

    const/16 v4, 0x101

    invoke-direct {v0, v3, v2, v4}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;-><init>(Ljava/lang/String;IS)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->UO_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    .line 25
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v3, 0x2

    const-string v4, "MAC_HEAD"

    const/16 v5, 0x102

    invoke-direct {v0, v4, v3, v5}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;-><init>(Ljava/lang/String;IS)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->MAC_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    .line 26
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v4, 0x3

    const-string v5, "BEEA_HEAD"

    const/16 v6, 0x103

    invoke-direct {v0, v5, v4, v6}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;-><init>(Ljava/lang/String;IS)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->BEEA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    .line 27
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v5, 0x4

    const-string v6, "NTACL_HEAD"

    const/16 v7, 0x104

    invoke-direct {v0, v6, v5, v7}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;-><init>(Ljava/lang/String;IS)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->NTACL_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    .line 28
    new-instance v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v6, 0x5

    const-string v7, "STREAM_HEAD"

    const/16 v8, 0x105

    invoke-direct {v0, v7, v6, v8}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;-><init>(Ljava/lang/String;IS)V

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->STREAM_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    const/4 v0, 0x6

    .line 22
    new-array v0, v0, [Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    sget-object v7, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->EA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    aput-object v7, v0, v1

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->UO_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    aput-object v1, v0, v2

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->MAC_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    aput-object v1, v0, v3

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->BEEA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    aput-object v1, v0, v4

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->NTACL_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    aput-object v1, v0, v5

    sget-object v1, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->STREAM_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    aput-object v1, v0, v6

    sput-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->$VALUES:[Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IS)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(S)V"
        }
    .end annotation

    .line 32
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 33
    iput-short p3, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->subblocktype:S

    return-void
.end method

.method public static findSubblockHeaderType(S)Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;
    .locals 1

    .line 37
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->EA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->equals(S)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 38
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->EA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0

    .line 39
    :cond_0
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->UO_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->equals(S)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 40
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->UO_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0

    .line 41
    :cond_1
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->MAC_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->equals(S)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 42
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->MAC_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0

    .line 43
    :cond_2
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->BEEA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->equals(S)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 44
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->BEEA_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0

    .line 45
    :cond_3
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->NTACL_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->equals(S)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 46
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->NTACL_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0

    .line 47
    :cond_4
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->STREAM_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0, p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->equals(S)Z

    move-result p0

    if-eqz p0, :cond_5

    .line 48
    sget-object p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->STREAM_HEAD:Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0

    :cond_5
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;
    .locals 1

    .line 22
    const-class v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object p0
.end method

.method public static values()[Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;
    .locals 1

    .line 22
    sget-object v0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->$VALUES:[Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    invoke-virtual {v0}, [Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    return-object v0
.end method


# virtual methods
.method public equals(S)Z
    .locals 1

    .line 54
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->subblocktype:S

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getSubblocktype()S
    .locals 1

    .line 58
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->subblocktype:S

    return v0
.end method
