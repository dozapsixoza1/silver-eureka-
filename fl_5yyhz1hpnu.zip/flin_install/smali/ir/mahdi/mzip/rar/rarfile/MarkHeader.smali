.class public Lir/mahdi/mzip/rar/rarfile/MarkHeader;
.super Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.source "MarkHeader.java"


# instance fields
.field private oldFormat:Z


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V
    .locals 0

    .line 29
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    const/4 p1, 0x0

    .line 26
    iput-boolean p1, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->oldFormat:Z

    return-void
.end method


# virtual methods
.method public isOldFormat()Z
    .locals 1

    .line 67
    iget-boolean v0, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->oldFormat:Z

    return v0
.end method

.method public isSignature()Z
    .locals 9

    const/4 v0, 0x7

    .line 47
    new-array v1, v0, [B

    .line 48
    iget-short v2, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->headCRC:S

    const/4 v3, 0x0

    invoke-static {v1, v3, v2}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    .line 49
    iget-byte v2, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->headerType:B

    const/4 v4, 0x2

    aput-byte v2, v1, v4

    .line 50
    iget-short v2, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->flags:S

    const/4 v5, 0x3

    invoke-static {v1, v5, v2}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    .line 51
    iget-short v2, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->headerSize:S

    const/4 v6, 0x5

    invoke-static {v1, v6, v2}, Lir/mahdi/mzip/rar/io/Raw;->writeShortLittleEndian([BIS)V

    .line 53
    aget-byte v2, v1, v3

    const/4 v7, 0x1

    const/16 v8, 0x52

    if-ne v2, v8, :cond_1

    .line 54
    aget-byte v2, v1, v7

    const/16 v8, 0x45

    if-ne v2, v8, :cond_0

    aget-byte v2, v1, v4

    const/16 v8, 0x7e

    if-ne v2, v8, :cond_0

    aget-byte v2, v1, v5

    const/16 v8, 0x5e

    if-ne v2, v8, :cond_0

    .line 55
    iput-boolean v7, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->oldFormat:Z

    goto :goto_0

    .line 57
    :cond_0
    aget-byte v2, v1, v7

    const/16 v8, 0x61

    if-ne v2, v8, :cond_1

    aget-byte v2, v1, v4

    const/16 v4, 0x72

    if-ne v2, v4, :cond_1

    aget-byte v2, v1, v5

    const/16 v4, 0x21

    if-ne v2, v4, :cond_1

    const/4 v2, 0x4

    aget-byte v2, v1, v2

    const/16 v4, 0x1a

    if-ne v2, v4, :cond_1

    aget-byte v2, v1, v6

    if-ne v2, v0, :cond_1

    const/4 v0, 0x6

    aget-byte v0, v1, v0

    if-nez v0, :cond_1

    .line 59
    iput-boolean v3, p0, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->oldFormat:Z

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    :goto_0
    return v7
.end method

.method public isValid()Z
    .locals 3

    .line 33
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->getHeadCRC()S

    move-result v0

    const/4 v1, 0x0

    const/16 v2, 0x6152

    if-eq v0, v2, :cond_0

    return v1

    .line 36
    :cond_0
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->getHeaderType()Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    move-result-object v0

    sget-object v2, Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;->MarkHeader:Lir/mahdi/mzip/rar/rarfile/UnrarHeadertype;

    if-eq v0, v2, :cond_1

    return v1

    .line 39
    :cond_1
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->getFlags()S

    move-result v0

    const/16 v2, 0x1a21

    if-eq v0, v2, :cond_2

    return v1

    .line 42
    :cond_2
    invoke-virtual {p0}, Lir/mahdi/mzip/rar/rarfile/MarkHeader;->getHeaderSize()S

    move-result v0

    const/4 v2, 0x7

    if-ne v0, v2, :cond_3

    const/4 v1, 0x1

    :cond_3
    return v1
.end method

.method public print()V
    .locals 0

    .line 71
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;->print()V

    return-void
.end method
