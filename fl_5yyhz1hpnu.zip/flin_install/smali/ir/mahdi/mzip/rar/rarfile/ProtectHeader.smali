.class public Lir/mahdi/mzip/rar/rarfile/ProtectHeader;
.super Lir/mahdi/mzip/rar/rarfile/BlockHeader;
.source "ProtectHeader.java"


# static fields
.field public static final protectHeaderSize:I = 0x8


# instance fields
.field private mark:B

.field private recSectors:S

.field private totalBlocks:I

.field private version:B


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;[B)V
    .locals 2

    .line 34
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;)V

    .line 37
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->version:B

    const/4 v0, 0x0

    aget-byte v1, p2, v0

    and-int/lit16 v1, v1, 0xff

    or-int/2addr p1, v1

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->version:B

    .line 39
    invoke-static {p2, v0}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->recSectors:S

    const/4 p1, 0x2

    .line 41
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->totalBlocks:I

    .line 43
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->mark:B

    const/4 v0, 0x6

    aget-byte p2, p2, v0

    and-int/lit16 p2, p2, 0xff

    or-int/2addr p1, p2

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->mark:B

    return-void
.end method


# virtual methods
.method public getMark()B
    .locals 1

    .line 48
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->mark:B

    return v0
.end method

.method public getRecSectors()S
    .locals 1

    .line 52
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->recSectors:S

    return v0
.end method

.method public getTotalBlocks()I
    .locals 1

    .line 56
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->totalBlocks:I

    return v0
.end method

.method public getVersion()B
    .locals 1

    .line 60
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/ProtectHeader;->version:B

    return v0
.end method
