.class public Lir/mahdi/mzip/rar/rarfile/AVHeader;
.super Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.source "AVHeader.java"


# static fields
.field public static final avHeaderSize:I = 0x7


# instance fields
.field private avInfoCRC:I

.field private avVersion:B

.field private method:B

.field private unpackVersion:B


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V
    .locals 1

    .line 33
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    .line 36
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->unpackVersion:B

    const/4 v0, 0x0

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->unpackVersion:B

    .line 38
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->method:B

    const/4 v0, 0x1

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->method:B

    .line 40
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->avVersion:B

    const/4 v0, 0x2

    aget-byte v0, p2, v0

    and-int/lit16 v0, v0, 0xff

    or-int/2addr p1, v0

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->avVersion:B

    const/4 p1, 0x3

    .line 42
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->avInfoCRC:I

    return-void
.end method


# virtual methods
.method public getAvInfoCRC()I
    .locals 1

    .line 46
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->avInfoCRC:I

    return v0
.end method

.method public getAvVersion()B
    .locals 1

    .line 50
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->avVersion:B

    return v0
.end method

.method public getMethod()B
    .locals 1

    .line 54
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->method:B

    return v0
.end method

.method public getUnpackVersion()B
    .locals 1

    .line 58
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/AVHeader;->unpackVersion:B

    return v0
.end method
