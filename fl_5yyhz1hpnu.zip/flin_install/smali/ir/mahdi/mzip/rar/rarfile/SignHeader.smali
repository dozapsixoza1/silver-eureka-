.class public Lir/mahdi/mzip/rar/rarfile/SignHeader;
.super Lir/mahdi/mzip/rar/rarfile/BaseBlock;
.source "SignHeader.java"


# static fields
.field public static final signHeaderSize:S = 0x8s


# instance fields
.field private arcNameSize:S

.field private creationTime:I

.field private userNameSize:S


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;[B)V
    .locals 0

    .line 33
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BaseBlock;-><init>(Lir/mahdi/mzip/rar/rarfile/BaseBlock;)V

    const/4 p1, 0x0

    .line 27
    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->creationTime:I

    .line 28
    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->arcNameSize:S

    .line 29
    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->userNameSize:S

    .line 36
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->creationTime:I

    const/4 p1, 0x4

    .line 38
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->arcNameSize:S

    const/4 p1, 0x6

    .line 40
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->userNameSize:S

    return-void
.end method


# virtual methods
.method public getArcNameSize()S
    .locals 1

    .line 44
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->arcNameSize:S

    return v0
.end method

.method public getCreationTime()I
    .locals 1

    .line 48
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->creationTime:I

    return v0
.end method

.method public getUserNameSize()S
    .locals 1

    .line 52
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/SignHeader;->userNameSize:S

    return v0
.end method
