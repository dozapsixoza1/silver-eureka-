.class public Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;
.super Lir/mahdi/mzip/rar/rarfile/BlockHeader;
.source "SubBlockHeader.java"


# static fields
.field public static final SubBlockHeaderSize:S = 0x3s


# instance fields
.field private level:B

.field private subType:S


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;[B)V
    .locals 1

    .line 40
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;)V

    const/4 p1, 0x0

    .line 42
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readShortLittleEndian([BI)S

    move-result p1

    iput-short p1, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->subType:S

    .line 44
    iget-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->level:B

    const/4 v0, 0x2

    aget-byte p2, p2, v0

    and-int/lit16 p2, p2, 0xff

    or-int/2addr p1, p2

    int-to-byte p1, p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->level:B

    return-void
.end method

.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;)V
    .locals 1

    .line 34
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/BlockHeader;)V

    .line 35
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->getSubType()Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    move-result-object v0

    invoke-virtual {v0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->getSubblocktype()S

    move-result v0

    iput-short v0, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->subType:S

    .line 36
    invoke-virtual {p1}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->getLevel()B

    move-result p1

    iput-byte p1, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->level:B

    return-void
.end method


# virtual methods
.method public getLevel()B
    .locals 1

    .line 48
    iget-byte v0, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->level:B

    return v0
.end method

.method public getSubType()Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;
    .locals 1

    .line 52
    iget-short v0, p0, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->subType:S

    invoke-static {v0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;->findSubblockHeaderType(S)Lir/mahdi/mzip/rar/rarfile/SubBlockHeaderType;

    move-result-object v0

    return-object v0
.end method

.method public print()V
    .locals 0

    .line 56
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/BlockHeader;->print()V

    return-void
.end method
