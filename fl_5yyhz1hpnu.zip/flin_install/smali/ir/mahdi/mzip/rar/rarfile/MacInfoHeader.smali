.class public Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;
.super Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;
.source "MacInfoHeader.java"


# static fields
.field public static final MacInfoHeaderSize:S = 0x8s


# instance fields
.field private fileCreator:I

.field private fileType:I


# direct methods
.method public constructor <init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;[B)V
    .locals 0

    .line 33
    invoke-direct {p0, p1}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;-><init>(Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;)V

    const/4 p1, 0x0

    .line 35
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->fileType:I

    const/4 p1, 0x4

    .line 37
    invoke-static {p2, p1}, Lir/mahdi/mzip/rar/io/Raw;->readIntLittleEndian([BI)I

    move-result p1

    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->fileCreator:I

    return-void
.end method


# virtual methods
.method public getFileCreator()I
    .locals 1

    .line 41
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->fileCreator:I

    return v0
.end method

.method public getFileType()I
    .locals 1

    .line 49
    iget v0, p0, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->fileType:I

    return v0
.end method

.method public print()V
    .locals 0

    .line 57
    invoke-super {p0}, Lir/mahdi/mzip/rar/rarfile/SubBlockHeader;->print()V

    return-void
.end method

.method public setFileCreator(I)V
    .locals 0

    .line 45
    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->fileCreator:I

    return-void
.end method

.method public setFileType(I)V
    .locals 0

    .line 53
    iput p1, p0, Lir/mahdi/mzip/rar/rarfile/MacInfoHeader;->fileType:I

    return-void
.end method
