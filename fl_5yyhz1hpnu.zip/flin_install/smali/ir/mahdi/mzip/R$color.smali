.class public final Lir/mahdi/mzip/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lir/mahdi/mzip/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final abc_background_cache_hint_selector_material_dark:I = 0x7f050000

.field public static final abc_background_cache_hint_selector_material_light:I = 0x7f050001

.field public static final abc_btn_colored_borderless_text_material:I = 0x7f050002

.field public static final abc_btn_colored_text_material:I = 0x7f050003

.field public static final abc_color_highlight_material:I = 0x7f050004

.field public static final abc_hint_foreground_material_dark:I = 0x7f050005

.field public static final abc_hint_foreground_material_light:I = 0x7f050006

.field public static final abc_input_method_navigation_guard:I = 0x7f050007

.field public static final abc_primary_text_disable_only_material_dark:I = 0x7f050008

.field public static final abc_primary_text_disable_only_material_light:I = 0x7f050009

.field public static final abc_primary_text_material_dark:I = 0x7f05000a

.field public static final abc_primary_text_material_light:I = 0x7f05000b

.field public static final abc_search_url_text:I = 0x7f05000c

.field public static final abc_search_url_text_normal:I = 0x7f05000d

.field public static final abc_search_url_text_pressed:I = 0x7f05000e

.field public static final abc_search_url_text_selected:I = 0x7f05000f

.field public static final abc_secondary_text_material_dark:I = 0x7f050010

.field public static final abc_secondary_text_material_light:I = 0x7f050011

.field public static final abc_tint_btn_checkable:I = 0x7f050012

.field public static final abc_tint_default:I = 0x7f050013

.field public static final abc_tint_edittext:I = 0x7f050014

.field public static final abc_tint_seek_thumb:I = 0x7f050015

.field public static final abc_tint_spinner:I = 0x7f050016

.field public static final abc_tint_switch_track:I = 0x7f050017

.field public static final accent_material_dark:I = 0x7f050018

.field public static final accent_material_light:I = 0x7f050019

.field public static final background_floating_material_dark:I = 0x7f05001b

.field public static final background_floating_material_light:I = 0x7f05001c

.field public static final background_material_dark:I = 0x7f05001d

.field public static final background_material_light:I = 0x7f05001e

.field public static final bright_foreground_disabled_material_dark:I = 0x7f050020

.field public static final bright_foreground_disabled_material_light:I = 0x7f050021

.field public static final bright_foreground_inverse_material_dark:I = 0x7f050022

.field public static final bright_foreground_inverse_material_light:I = 0x7f050023

.field public static final bright_foreground_material_dark:I = 0x7f050024

.field public static final bright_foreground_material_light:I = 0x7f050025

.field public static final button_material_dark:I = 0x7f050026

.field public static final button_material_light:I = 0x7f050027

.field public static final dim_foreground_disabled_material_dark:I = 0x7f05002f

.field public static final dim_foreground_disabled_material_light:I = 0x7f050030

.field public static final dim_foreground_material_dark:I = 0x7f050031

.field public static final dim_foreground_material_light:I = 0x7f050032

.field public static final foreground_material_dark:I = 0x7f050036

.field public static final foreground_material_light:I = 0x7f050037

.field public static final highlighted_text_material_dark:I = 0x7f050039

.field public static final highlighted_text_material_light:I = 0x7f05003a

.field public static final material_blue_grey_800:I = 0x7f05003c

.field public static final material_blue_grey_900:I = 0x7f05003d

.field public static final material_blue_grey_950:I = 0x7f05003e

.field public static final material_deep_teal_200:I = 0x7f05003f

.field public static final material_deep_teal_500:I = 0x7f050040

.field public static final material_grey_100:I = 0x7f050041

.field public static final material_grey_300:I = 0x7f050042

.field public static final material_grey_50:I = 0x7f050043

.field public static final material_grey_600:I = 0x7f050044

.field public static final material_grey_800:I = 0x7f050045

.field public static final material_grey_850:I = 0x7f050046

.field public static final material_grey_900:I = 0x7f050047

.field public static final notification_action_color_filter:I = 0x7f050048

.field public static final notification_icon_bg_color:I = 0x7f050049

.field public static final primary_dark_material_dark:I = 0x7f05004a

.field public static final primary_dark_material_light:I = 0x7f05004b

.field public static final primary_material_dark:I = 0x7f05004c

.field public static final primary_material_light:I = 0x7f05004d

.field public static final primary_text_default_material_dark:I = 0x7f05004e

.field public static final primary_text_default_material_light:I = 0x7f05004f

.field public static final primary_text_disabled_material_dark:I = 0x7f050050

.field public static final primary_text_disabled_material_light:I = 0x7f050051

.field public static final ripple_material_dark:I = 0x7f050052

.field public static final ripple_material_light:I = 0x7f050053

.field public static final secondary_text_default_material_dark:I = 0x7f050054

.field public static final secondary_text_default_material_light:I = 0x7f050055

.field public static final secondary_text_disabled_material_dark:I = 0x7f050056

.field public static final secondary_text_disabled_material_light:I = 0x7f050057

.field public static final switch_thumb_disabled_material_dark:I = 0x7f050058

.field public static final switch_thumb_disabled_material_light:I = 0x7f050059

.field public static final switch_thumb_material_dark:I = 0x7f05005a

.field public static final switch_thumb_material_light:I = 0x7f05005b

.field public static final switch_thumb_normal_material_dark:I = 0x7f05005c

.field public static final switch_thumb_normal_material_light:I = 0x7f05005d


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 268
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
