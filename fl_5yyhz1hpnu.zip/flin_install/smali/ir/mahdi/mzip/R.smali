.class public final Lir/mahdi/mzip/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lir/mahdi/mzip/R$styleable;,
        Lir/mahdi/mzip/R$style;,
        Lir/mahdi/mzip/R$string;,
        Lir/mahdi/mzip/R$layout;,
        Lir/mahdi/mzip/R$integer;,
        Lir/mahdi/mzip/R$id;,
        Lir/mahdi/mzip/R$drawable;,
        Lir/mahdi/mzip/R$dimen;,
        Lir/mahdi/mzip/R$color;,
        Lir/mahdi/mzip/R$bool;,
        Lir/mahdi/mzip/R$attr;,
        Lir/mahdi/mzip/R$anim;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
