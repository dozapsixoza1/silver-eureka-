.class public final Lir/mahdi/mzip/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lir/mahdi/mzip/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_bar:I = 0x7f080006

.field public static final action_bar_activity_content:I = 0x7f080007

.field public static final action_bar_container:I = 0x7f080008

.field public static final action_bar_root:I = 0x7f080009

.field public static final action_bar_spinner:I = 0x7f08000a

.field public static final action_bar_subtitle:I = 0x7f08000b

.field public static final action_bar_title:I = 0x7f08000c

.field public static final action_container:I = 0x7f08000d

.field public static final action_context_bar:I = 0x7f08000e

.field public static final action_divider:I = 0x7f08000f

.field public static final action_image:I = 0x7f080010

.field public static final action_menu_divider:I = 0x7f080011

.field public static final action_menu_presenter:I = 0x7f080012

.field public static final action_mode_bar:I = 0x7f080013

.field public static final action_mode_bar_stub:I = 0x7f080014

.field public static final action_mode_close_button:I = 0x7f080015

.field public static final action_text:I = 0x7f080016

.field public static final actions:I = 0x7f080017

.field public static final activity_chooser_view_content:I = 0x7f080018

.field public static final add:I = 0x7f080019

.field public static final alertTitle:I = 0x7f08001a

.field public static final always:I = 0x7f08001c

.field public static final beginning:I = 0x7f08001f

.field public static final bottom:I = 0x7f080021

.field public static final buttonPanel:I = 0x7f080027

.field public static final checkbox:I = 0x7f080034

.field public static final chronometer:I = 0x7f080035

.field public static final collapseActionView:I = 0x7f080038

.field public static final contentPanel:I = 0x7f08003a

.field public static final custom:I = 0x7f08003b

.field public static final customPanel:I = 0x7f08003c

.field public static final decor_content_parent:I = 0x7f08003d

.field public static final default_activity_button:I = 0x7f08003e

.field public static final disableHome:I = 0x7f080043

.field public static final edit_query:I = 0x7f080045

.field public static final end:I = 0x7f080046

.field public static final expand_activities_button:I = 0x7f080047

.field public static final expanded_menu:I = 0x7f080048

.field public static final home:I = 0x7f080052

.field public static final homeAsUp:I = 0x7f080053

.field public static final icon:I = 0x7f080054

.field public static final icon_group:I = 0x7f080055

.field public static final ifRoom:I = 0x7f080056

.field public static final image:I = 0x7f080057

.field public static final info:I = 0x7f08005f

.field public static final line1:I = 0x7f080063

.field public static final line3:I = 0x7f080064

.field public static final listMode:I = 0x7f080065

.field public static final list_item:I = 0x7f080066

.field public static final middle:I = 0x7f080068

.field public static final multiply:I = 0x7f080069

.field public static final never:I = 0x7f08006a

.field public static final none:I = 0x7f08006b

.field public static final normal:I = 0x7f08006c

.field public static final notification_background:I = 0x7f08006d

.field public static final notification_main_column:I = 0x7f08006e

.field public static final notification_main_column_container:I = 0x7f08006f

.field public static final parentPanel:I = 0x7f080073

.field public static final progress_circular:I = 0x7f080077

.field public static final progress_horizontal:I = 0x7f080078

.field public static final radio:I = 0x7f080079

.field public static final right_icon:I = 0x7f08007b

.field public static final right_side:I = 0x7f08007c

.field public static final screen:I = 0x7f08007e

.field public static final scrollIndicatorDown:I = 0x7f08007f

.field public static final scrollIndicatorUp:I = 0x7f080080

.field public static final scrollView:I = 0x7f080081

.field public static final search_badge:I = 0x7f080082

.field public static final search_bar:I = 0x7f080083

.field public static final search_button:I = 0x7f080084

.field public static final search_close_btn:I = 0x7f080085

.field public static final search_edit_frame:I = 0x7f080086

.field public static final search_go_btn:I = 0x7f080087

.field public static final search_mag_icon:I = 0x7f080088

.field public static final search_plate:I = 0x7f080089

.field public static final search_src_text:I = 0x7f08008a

.field public static final search_voice_btn:I = 0x7f08008b

.field public static final select_dialog_listview:I = 0x7f08008c

.field public static final shortcut:I = 0x7f08008d

.field public static final showCustom:I = 0x7f08008e

.field public static final showHome:I = 0x7f08008f

.field public static final showTitle:I = 0x7f080090

.field public static final spacer:I = 0x7f080091

.field public static final split_action_bar:I = 0x7f080092

.field public static final src_atop:I = 0x7f080095

.field public static final src_in:I = 0x7f080096

.field public static final src_over:I = 0x7f080097

.field public static final submenuarrow:I = 0x7f08009c

.field public static final submit_area:I = 0x7f08009d

.field public static final tabMode:I = 0x7f08009e

.field public static final text:I = 0x7f0800a2

.field public static final text2:I = 0x7f0800a3

.field public static final textSpacerNoButtons:I = 0x7f0800a4

.field public static final textSpacerNoTitle:I = 0x7f0800a5

.field public static final time:I = 0x7f0800b5

.field public static final title:I = 0x7f0800b6

.field public static final titleDividerNoCustom:I = 0x7f0800b7

.field public static final title_template:I = 0x7f0800b8

.field public static final top:I = 0x7f0800b9

.field public static final topPanel:I = 0x7f0800ba

.field public static final up:I = 0x7f0800bd

.field public static final useLogo:I = 0x7f0800be

.field public static final withText:I = 0x7f0800c0

.field public static final wrap_content:I = 0x7f0800c2


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 552
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
